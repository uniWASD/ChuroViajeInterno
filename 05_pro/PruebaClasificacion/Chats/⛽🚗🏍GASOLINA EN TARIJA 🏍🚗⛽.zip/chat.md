# Exportación de chat de WhatsApp: ⛽🚗🏍️GASOLINA EN TARIJA 🏍️🚗⛽
Fecha de exportación: 17 de septiembre de 2026 a las 11:27

---

## 28 de mayo de 2026

[9:11] **+591 71875639:** Wen dia

[9:11] **+591 71875639:** Alguien cargo gasolina blanquita hoy?

[9:30] **+591 69307503:** [Mensaje de voz]

[9:31] **+591 71875639:** Gracias rey

[9:31] **+591 71875639:** Habra cuere ahi

[20:44] **+591 75143839:** https://vt.tiktok.com/ZS92eDnJhvrqa-W4jQ5/

---

## 29 de mayo de 2026

[6:32] **+591 67376165:** Etanol en agrupa

[7:46] **+591 68731773:** _Se eliminó este mensaje_

[9:03] **+591 72944424:**
> _+591 67376165: Etanol en agrupa_
También en El Portillo

[10:25] **+591 69312879:** 👍

[14:56] **+591 74515367:** Buenas tardes, alguien sabe en qué surtidor están cargando gasolina clarita

[14:59] **+591 69304176:**
> _+591 74515367: Buenas tardes, alguien sabe en qué surtidor están cargando gasolina clarita_
En la vegas

[14:59] **+591 69304176:** Cargue ase media hora

[14:59] **+591 69304176:** Clarita la gasolina especial

[14:59] **+591 74515367:** Gracias

[14:59] **+591 74515367:** [Sticker]

[15:01] **+591 71875639:** [Reenviado] [Imagen]

[15:01] **+591 71875639:** [Reenviado] Se robaron la.moto de mi hermano
Por favor si alguien vio o tuviera algún dato

---

## 30 de mayo de 2026

[9:21] **+591 72042913:** Algún compañero q haya cargado gasolina clarita por favor...

[10:21] **+591 70227368:** Buenos días disculpe alguien Sabe donde Hay etanol???

[13:24] **+591 62858652:** Alguien sabe dónde hay buena gasolina?

[13:25] **+591 72903627:** [Mensaje de voz]

[13:32] **+591 75127881:** Buenas tardes

[13:32] **+591 75127881:** Alguien sabe donde hay gasolina etanol?

[13:53] **+591 72042913:** En el tacuarandi compañeros..

[14:27] **+591 72999358:** ¡Echa un vistazo a este TikTok que encontré!  https://vt.tiktok.com/ZSxtggoV1/

[15:50] **+591 71199691:** En el surtidor moto mendez hay gasolina especial

[17:15] **+591 72944424:** _Se eliminó este mensaje_

[20:25] **+591 79252300:** Alguien sabe si la gasolina de la ex terminal es clarita?

[21:29] **+591 67384303:** Buenas noches alguien sabe si estan vendiendo gasolina

---

## 31 de mayo de 2026

[8:01] **+591 69312879:** Buen día

[8:01] **+591 69312879:** Alguien sabe donde están vendiendo gasolina especial o etanol

[11:06] __+591 75175156 se unieron mediante el enlace de invitación__

[11:06] __Alguien añadió a +591 75175156__

[11:18] **+591 63797053:** Alguien me puede pasar el enlace xf

[11:18] **+591 63797053:** de este grupo

[11:18] **+591 63797053:** Buen día

[11:18] **+591 63797053:** [Sticker]

[12:00] **+591 68731773:** _Se eliminó este mensaje_

[13:11] **+591 75132500:** [Imagen] Ala venta d ocasión cargador portátil a 95 bs ...en perfecto estado d función..

[15:21] **+591 73499985:** Donde hay gasolina especial o etanol?

[16:01] **+591 75127881:** Si por favor alguien sabe?

[16:04] **+591 73457507:** https://chat.whatsapp.com/IMo6ZG44UjNKjk9w3H2KUE?mode=hqrt3

[16:16] **+591 65841415:** Buenas tardes alguien sabe en que surtidor están  vendiendo gasolina especial  por  favor

[16:20] **+591 71197917:** En el Portillo había etanol

[16:38] **+591 75127881:**
> _+591 71197917: En el Portillo había etanol_
Disculpe hoy cargo??

[18:22] **+591 62498564:** Alguien sabe donde hay gasolina?

[21:22] **+591 78249688:** https://chat.whatsapp.com/GU8CqX0YTgB0utIYJupGrh


Ropita femenina

[21:22] **+591 78249688:** https://chat.whatsapp.com/GU8CqX0YTgB0utIYJupGrh

[22:43] __+591 74531909 se unieron mediante el enlace de invitación__

[22:43] __Alguien añadió a +591 74531909__

---

## 1 de junio de 2026

[7:14] **+591 70227368:** Buen día alguien sabe donde ay etanol agradezco el. Dato

[7:52] **+591 70227368:** ?

[9:06] **+591 69329302:** Buen dia alguien sabe que tal esta la gasolina en las vegas?

[9:10] **+591 74670785:** Alguien save si hay gasolina  especial en  surtidor   el  molle  en el  Rancho

[9:23] **+591 67960504:** Buenos dias donde ay gasolina limpia

[14:23] **+591 72955920:** Una consulta amigos...saben en q horas y q días se pueden mandar comestibles a La Paz

[14:34] **+591 70227368:** Todos los días antes de las 11 am

[14:34] **+591 72990143:**
> _+591 72955920: Una consulta amigos...saben en q horas y q días se pueden mandar comestibles a La Paz_
Consulte en la terminal de buses ellos saben

[14:37] **+591 72955920:**
> _+591 70227368: Todos los días antes de las 11 am_
Muchas gracias

[14:37] **+591 72955920:**
> _+591 72990143: Consulte en la terminal de buses ellos saben_
Hay bloqueos..

[14:38] **+591 70227368:**
> _+591 70227368: Todos los días antes de las 11 am_
En avión

[14:39] **+591 72955920:** Exacto... muchas gracias

[14:39] **+591 72982234:** Disculpen saben dónde hay gasolina limpia?

[14:45] **+591 69304176:** Gasolina especial en q surtidor hay no saben

[14:46] **+591 69304176:** ?

[14:49] **+591 75127881:** Surtidor moto Méndez

[16:08] **+591 67384303:** Buenas tardes alguien sabe enque surtidor estan vendiendo gasolina Etanol oh clarita por favor

[16:51] **+591 71866559:** Alguien sabe si está limpia la gasolina de las Vegas?

[16:55] **+591 75140034:**
> _+591 71866559: Alguien sabe si está limpia la gasolina de las Vegas?_
A las 2 fui a ver estaba café la plus estaban cargando

[16:55] **+591 75140034:** Donde don Daniel había etanol

[19:43] **+591 72999358:** Buenas noches Alguien sabe si en Sointa están vendiendo gasolina especial?

[19:56] **+591 68697122:** Buenas noches alguien sabe dónde hay etanol?

---

## 2 de junio de 2026

[7:27] **+591 75119208:** Buenos días

[7:28] **+591 75119208:** Disculpe alguien sabe donde están repartiendo gasolina limpia la blanquita

[7:28] **+591 75119208:** Me pueden pasar el dato

[7:28] **+591 75119208:** Por favor

[9:35] **+591 74670785:** Buenos dias   avisen por favor  donde hay  gasolina  especial  clarita

[9:52] **+591 77175043:** Yofb

[9:53] **+591 77175043:** Morros blancos

[9:56] **+591 71192881:** Yo compre el otro dia gasolina clarita y fue cambiando x los dias q pasaba y tambien me dijo otro señor a alguien le pasó ahora lo vendi la gaso esta pasando raro

[9:56] **+591 75119208:**
> _+591 77175043: Yofb_
La fila esta reee largaa

[10:03] **+591 73483881:** Que tal está las Vegas ?? Alguien cargo ?

[10:03] **+591 74515367:** Alguien sabe cómo está el del surtidor Tarija

[10:09] **+591 67913312:** [Mensaje de voz]

[10:16] **+591 71866559:**
> _+591 73483881: Que tal está las Vegas ?? Alguien cargo ?_
Mas Vegas tiene la plus

[10:16] **+591 71866559:** La de bajando senac igual

[10:55] **+591 71875639:** Donde hay gasolina chura

[11:02] **+591 72999358:** Dónde hay gasolina especial por fa?

[11:51] **+591 75175156:**
> _+591 71192881: Yo compre el otro dia gasolina clarita y fue cambiando x los dias q pasaba y tambien me dijo otro señor a alguien le pasó ahora lo vendi la gaso esta pasando raro_
Si eso es cierto.
Yo compre también clarita. 
Luego a los días se volvió igual que las demás asi que creo qie debe ser lo mismo solo con un aclarante nada mas.
Y mejor rendimiento del motor vi con la amarilla.

[11:55] **+591 78700826:** Buen día, busco soldador con arco para domicilio

[11:55] **+591 78700826:** Si alguien tuviera una referencia

[12:05] **+591 71866559:**
> _+591 78700826: Si alguien tuviera una referencia_
[Contacto: BEGIN:VCARD
VERSION:3.0
N:;Cristian Alfaro;;;
FN:Cristian Alfaro
item1.TEL;waid=59164336014:+591 64336014
item1.X-ABLabel:Celular
item2.TEL:+591 78234329
item2.X-ABLabel:Celular
END:VCARD]

[13:08] **+591 71866332:** Buenas tardes me lo agrega al compañero por favor 71173625

[13:51] **+591 65800835:** Buenas tardes, alguien sabe si ya están vendiendo etanol en la exterminal? u otro lugar

[14:41] **+591 69327934:** Dónde hay etanol

[14:41] **+591 69327934:** Alguien sabe

[15:04] **+591 77871884:** Buenas tardes 
 añadan a este número 64702510 porfa

[15:04] **+591 73457507:** https://chat.whatsapp.com/IMo6ZG44UjNKjk9w3H2KUE?mode=hqrt3

[15:16] **+591 72964737:** yo cargue en la ex terminal y esta amarilla la gasolina.

[15:16] **+591 72999358:** La especial o la plus?

[15:22] **+591 71875639:** Dnd hay gasolina

[15:22] **+591 71875639:** Blanquita

[15:28] **+591 69327934:**
> _+591 69327934: Dónde hay etanol_
Etanol

[15:28] **+591 69327934:** Dónde hay

[15:28] **+591 69327934:** Alguien sabe

[15:28] **+591 69327934:** Por favor

[15:28] **+591 69327934:** Etanol

[17:36] **+591 71875639:** Donde hay gasolina wena

---

## 3 de junio de 2026

[0:04] **+591 63809912:** Dónde hay d
Gasolina

[7:05] **+591 71894444:** Buen día
Por favor avisan si saben donde hay gasolina especial o clarita 👍

[7:28] **+591 71875639:** Avisen

[7:49] **+591 75119208:** Buen día algún  surtidor que este repartiendo gasolina claritaa la especial

[7:49] **+591 75119208:** Por favor pasen el datoo

[8:13] **+591 70227368:** Buen día alguien sabe donde hay etanol por favor

[8:25] **+591 71894444:** Don Daniel clarita 👍

[8:26] **+591 71875639:** Cuando cargaste

[8:35] **+591 73499985:** Anoche cargue en don Daniel dijieron que es la especial

[8:36] **+591 75119208:** Hoy en la mañana estaba descargando una sisternaa

[8:37] **+591 75119208:** Alguien fue a cargar

[8:37] **+591 75119208:** ???

[8:37] **+591 75119208:** Si es la especial o plus

[8:46] **+591 78707745:** Gasolina especial y Etanol en surtidor Moto Mendez

[8:53] **+591 71894444:** cargue donde don Daniel
Hace 30 min

[8:53] **+591 71875639:**
> _+591 71894444: cargue donde don Daniel
Hace 30 min_
Barbaro

[8:54] **+591 71894444:** En las Vegas pase a preguntar por que había una sisterna descargando pero me dijeron que tenía la plus....

[8:54] **+591 75119208:** Gracias por el dato👍🏼

[8:59] **+591 70227368:**
> _+591 78707745: Gasolina especial y Etanol en surtidor Moto Mendez_
Gracias

[9:00] **+591 63780494:**
> _+591 71894444: cargue donde don Daniel
Hace 30 min_
Ahí piden la tarjeta de bsisa???

[9:03] **+591 71875639:**
> _+591 63780494: Ahí piden la tarjeta de bsisa???_
Nop

[9:12] **+591 63780494:** Gracias

[9:34] **+591 70227368:** Por favor pueden incluir este número 72967111

[12:30] **+591 75127881:** Buenas tardes alguien sabe donde hay gasolina etanol?

[12:30] **+591 71875639:** [Mensaje de voz]

[12:37] **+591 69307503:**
> _+591 75127881: Buenas tardes alguien sabe donde hay gasolina etanol?_
[Mensaje de voz]

[12:41] **+591 75127881:**
> _+591 69307503: Mensaje de voz_
Gracias

[12:45] **+591 71875639:**
> _+591 69307503: Mensaje de voz_
Gracias bb

[12:48] **+591 63780494:**
> _+591 71875639: Gracias bb_
[Sticker]

[12:52] **+591 63797053:** [Sticker]

[13:03] **+591 78434896:** alguien sabe dónde puedo conseguir bidón de 20litros???

[13:03] **+591 78434896:** quiero el bidón

[13:03] **+591 78434896:** porfavor

[13:23] **+591 72426015:** Campesino

[13:23] **+591 72426015:** U circunvalacion y gral trigo

[13:24] **+591 72426015:**
> _+591 72426015: Campesino_
Sobre la froilan

[13:24] **+591 78434896:** gracias

[13:34] **+591 65838310:** Alguien sabe donde hay gasolina especial

[13:34] **+591 65838310:** Por favor pasen el.dato

[13:34] **+591 75119208:**
> _+591 65838310: Alguien sabe donde hay gasolina especial_
Don Daniel

[13:35] **+591 65838310:** Gracias por el dato

[14:07] **+591 76836904:**
> _+591 65838310: Alguien sabe donde hay gasolina especial_
[Sticker]

[14:17] **+591 68719052:** Portillo hay especial

[16:05] **+591 69312879:** _Se eliminó este mensaje_

[19:19] **+591 68697122:** Alguien sabe dónde hay etanol perdón

[19:28] **+591 75146448:** Buenas noches

[19:29] **+591 75146448:** No saben donde hay gasolina

[20:43] **+591 68697122:** Hay etanol en don Daniel

---

## 4 de junio de 2026

[8:24] **+591 71875639:** Wen dia a todos

[8:24] **+591 71875639:** Alguien cargo gasolina

[8:24] **+591 71875639:** Hoy

[8:27] **+591 72903627:** [Mensaje de voz]

[8:28] **+591 71875639:**
> _+591 72903627: Mensaje de voz_
Hay fila en ypfb?

[8:29] **+591 73140648:** Dónde queda ypfb

[8:29] **+591 71875639:**
> _+591 73140648: Dónde queda ypfb_
Depende cual

[8:29] **+591 71875639:** Morros blancos da entender

[8:31] **+591 72903627:** [Mensaje de voz]

[10:17] **+591 74525861:** Buen dia

[10:17] **+591 74525861:** Alguien sabe como esta la gasolina donde don Daniel o las vegas

[10:18] **+591 76945645:** En Agrupa hay etanol

[10:31] **+591 75175156:** Gracias por el dato

[11:06] **+591 71875639:** Dnd hay blanca

[11:39] **+591 69327934:** Dónde hay etanol

[11:39] **+591 69327934:** Ahorita ?

[13:42] **+591 73499985:**
> _+591 69327934: Dónde hay etanol_
Sointa

[15:08] **+591 74525861:** Alguien sabe que gasolina tiene don daniel

[15:10] **+591 75127881:**
> _+591 73499985: Sointa_
Disculpe cargó hoy?

---

## 5 de junio de 2026

[9:36] **+591 78235592:** Buen día alguien sabe dónde hay gasolina clarita?

[9:37] **+591 75131234:**
> _+591 78235592: Buen día alguien sabe dónde hay gasolina clarita?_
En el campesino

[9:48] **+591 67384303:** Buen dia alguien sabe donde hay Gasolina  Etanol

[9:49] **+591 75127881:** Buenos días  alguien sabe donde hay gasolina etanol?

[9:53] **+591 78221711:** [Mensaje de voz]

[13:17] **+591 75127881:** Saben si hay etanol en el surtidor de la ex terminal o don Daniel?

[13:24] **+591 72426015:**
> _+591 75127881: Buenos días  alguien sabe donde hay gasolina etanol?_
❓️❓️❓️❓️

[16:47] **+591 67384303:** Buenos tardes  alguien sabe donde hay gasolina etanol? Oh Clarita

[17:40] **+591 75127881:** Alguien sabe donde puedo encontrar gasolina especial??

[18:35] **+591 74543626:** Don Daniel  dicen que está con la especial

---

## 6 de junio de 2026

[9:29] **+591 72982234:** Buenos días alguien sabe dónde hay gasolina limpia???

[10:25] **+591 70227368:** Buena día alquien sabe donde venden etanol

[10:25] **+591 69312879:**
> _+591 70227368: Buena día alquien sabe donde venden etanol_
Don Daniel

[15:38] **+591 72976766:** Alguien sabe donde hay gasolina especial???

[15:54] **+591 72985002:** _Se eliminó este mensaje_

[16:00] **+591 73483881:**
> _+591 72976766: Alguien sabe donde hay gasolina especial???_
Avisen

[16:26] **+591 68697122:** No saben dónde hay etanol

[16:37] **+591 77872412:** _Se eliminó este mensaje_

[17:27] **+591 75133504:** Buenas tardes en qué surtidor es esta bien la gasolina

[18:18] **+591 79852237:** https://chat.whatsapp.com/GqxfA8YsYak24sO8L7xDTf
Buenas tardes, se hace recarga de Entel los 15bs de crédito a 10bs, usted puede cancelar mediante qr o depósito bancario
Igual se recupera líneas bloqueadas por falta de recarga a un costó de 4bs

[18:47] **+591 69315287:** Hola colegas

[18:47] **+591 69315287:** Donde encuentro gasolina

---

## 7 de junio de 2026

[7:19] **+591 71875639:** Dnd hay gasolina linda

[9:10] **+591 79256927:** Buenos días grupo, en que surtidor están vendiendo gasolina especial? por favor alguien que me pase el dato.

[10:09] **Marco:** Donde hay gasolina clarita?

[10:13] **+591 72942824:** Don Daniel

[10:13] **+591 72942824:** Agrupa

[10:14] **+591 68680221:** En el surtidor cerca la UPDS... Venden en bidón...???

[10:15] **+591 68680221:** O en la ex terminal... Saben...???

[10:59] **+591 62858652:** Alguien sabe dónde hay gasolina clarita?

[10:59] **+591 69913636:**
> _+591 68680221: En el surtidor cerca la UPDS... Venden en bidón...???_
Si venden

[11:23] **+591 71198548:** Alguien sabe dónde están vendiendo gasolina especial

[11:52] **+591 72976766:** YPFB Morros Blancos

[12:09] **+591 71198548:** Gracias

[12:37] **+591 72976766:** [Imagen]

---

## 8 de junio de 2026

[8:19] **+591 60252340:** Alguien sabe donde hay gasolina xf

[8:33] **+591 69307503:**
> _+591 60252340: Alguien sabe donde hay gasolina xf_
Alguien pasa la info

[8:33] **+591 69307503:** Xfa

[9:56] **+591 75127881:** Alguien sabe donde hay gasolina etanol

[10:47] **+591 70227368:** Buen día alguien sabe donde ay etanol por favor

[11:00] **+591 78434896:** [Reenviado] [Imagen] Surtido tacuarandi

[11:01] **+591 78434896:** ahí hay gasolina clarita

[16:01] **+591 72963020:** https://www.facebook.com/share/v/1BKnqAD5iF/

[16:54] **+591 72426015:** Q surtidor hay especial

[17:29] **+591 75143839:**
> _+591 72426015: Q surtidor hay especial_
Avisen x favor

[17:29] **+591 75143839:** Donde mas hay gasolina especial?

[17:30] **+591 78221711:** [Imagen]

[17:30] **+591 78221711:** [Mensaje de voz]

[17:30] **+591 78221711:** [Mensaje de voz]

[17:30] **+591 78434896:** 🫡 gracias por la información

[17:30] **+591 75143839:** 👍👍👍

[17:35] **+591 72982234:** En el tacuarandi también hay la especial

[17:36] **+591 72426015:** Se acabo en tacuarandi

[17:55] **+591 71875639:** [Mensaje de voz]

[17:56] **+591 75113568:** Alguien sabe si hay gasolina en las Vegas

[17:56] **+591 71875639:** Sointa

[17:57] **+591 63780494:**
> _+591 71875639: Sointa_
Ahí piden Bsisa

[17:57] **+591 63780494:** No sabes

[17:57] **+591 63780494:** ??

[18:03] **+591 75143839:** [Imagen] En el campesino

[18:06] **+591 79852237:** https://chat.whatsapp.com/GqxfA8YsYak24sO8L7xDTf
Buenas tardes, se hace recarga de Entel los 15bs de crédito a 10bs, usted puede cancelar mediante qr o depósito bancario
Igual se recupera líneas bloqueadas por falta de recarga a un costó de 4bs

---

## 9 de junio de 2026

[9:57] **+591 72999400:** Alguien sabe donde hay gasolina clarita??

[10:51] **+591 75146448:** Hola buen dia

[10:51] **+591 75146448:** No sabe donde hay gasoli a

[10:52] **+591 69304176:** [Reenviado] [Imagen]

[10:52] **+591 69304176:** [Reenviado] [Imagen]

[10:52] **+591 69304176:** [Reenviado] Calarita

[10:52] **+591 69304176:** [Reenviado] No ay file

[10:52] **+591 69304176:** [Reenviado] Asta este momento

[10:54] **+591 75146448:** Donde queda

[10:54] **+591 75146448:** Ese surtidor

[10:55] **+591 63780494:**
> _+591 69304176: Asta este momento_
No saben si piden trajera bsisa

[10:55] **+591 63780494:** ??

[10:55] **+591 63780494:** [Sticker]

[10:55] **+591 71875639:**
> _+591 75146448: Donde queda_
Antes de llegar ala carcel

[10:55] **+591 71875639:**
> _+591 63780494: No saben si piden trajera bsisa_
Nop

[10:57] **+591 62858652:** En el surtidor tarija ay buena gasolina

[10:59] **+591 63780494:**
> _+591 71875639: Nop_
Gracias

[11:40] **+591 75127881:** Gasolina etanol  alguien sabe en que surtidor hay?

[11:48] **+591 67384291:** Gasolina especial hay también en Villanueva san Geronimo

---

## 10 de junio de 2026

[8:11] **+591 72943744:** Buenos días alguien sabe donde hay etanol? Se los agradecería el dato por favor

[8:33] **+591 75127881:** Buenos días  por favor si alguien sabe donde hay gasolina  etanol

[8:40] **+591 71192881:** Buen dia alguien sabe dnde venden gasolina clarita xfa me avisan

[8:47] **+591 73499985:** Aquí en morros blancos pero con fila

[10:32] **+591 68616631:** agrupa y el Tarija gasolina especial

[10:32] **+591 71894444:** En sointa están con fila saben si es la especial?

[10:41] **+591 71192881:** En las vegas no saben q es la gasolina clarita ?

[11:27] **+591 61862568:** [Imagen] Compro estas tapitas son de coca cola dicen PANINI...

[12:09] **+591 74670785:** Alguien  dabe  como esta  la gasolina  de Agrupa

[12:10] **+591 74670785:** Estara  limpia

[12:10] **+591 74670785:** Avisen  por  favor

[13:03] **+591 71192881:** Gasolina especial en villa nueva pasando universidad cargué hace un rato

[15:03] **+591 72977660:**
> _+591 61862568: Imagen: Compro estas tapitas son de coca cola dicen PANINI..._
Cuanto pagas

[15:32] **+591 72964737:** [Mensaje de voz]

[15:40] **+591 74670785:** Hay  filao nada

[15:48] **+591 72964737:** sin fila

[15:54] **+591 78236766:** Buenas tardes alguien sabe dónde hay etanol

[15:58] **+591 71894444:** Positivo, clarita en tacuarandi sin fila

[16:56] **+591 61862568:**
> _+591 72977660: Cuanto pagas_
1 bs. Por tapa

---

## 11 de junio de 2026

[7:34] **+591 71875639:** Wen dia

[7:34] **+591 71875639:** Dnd hay gasolina clarita cumpas

[7:35] **+591 72943744:** Buenos días alguien sabe en que surtidor están cargando etanol por favor se los agradecería por el dato

[7:37] **+591 71875639:** Alguien cargo ya?

[7:40] **+591 75127881:**
> _+591 72943744: Buenos días alguien sabe en que surtidor están cargando etanol por favor se los agradecería por el dato_
ayer en la noche había en el sointa y el agrupa

[8:01] **+591 72943744:** Gracias por el dato

[8:51] **+591 61862568:** En el agrupa hay etanol

[9:26] **+591 71875639:** Reporten

[11:15] **+591 63780494:** En el surtidor pasando el coliseo universitario zona san Geronimo hay la plus estaban descargando la especial me indicaron que a partir de las 3 de la tarde ya estarán vendiendo la especial tomar en cuenta

[12:30] **+591 75146448:** En la agrupa hay gasolina alguien sabe?

[15:14] **+591 74670785:** Donde  hay  gasolina   clarita alguien  sabe comunique por  favor

[15:46] **+591 67376165:** Hay Etanol en  agrupa

[16:21] **+591 73499985:**
> _+591 74670785: Donde  hay  gasolina   clarita alguien  sabe comunique por  favor_
Especial hay en el surtidor del coliseo univ

[18:16] **+591 79852237:** https://chat.whatsapp.com/GqxfA8YsYak24sO8L7xDTf
Buenas tardes, se hace recarga de Entel los 15bs de crédito a 10bs, usted puede cancelar mediante qr o depósito bancario
Igual se recupera líneas bloqueadas por falta de recarga a un costó de 4bs

[19:48] **+591 67968836:** Buenas noches

[19:48] **+591 67968836:** Saben dónde hay gasolina?

[19:55] **+591 72976766:** A lado del Coliseo Universitario

---

## 12 de junio de 2026

[9:21] **+591 68719052:** Buenos días en que surtidor están repartiendo gasolina especial

[11:58] **+591 71875639:** Buenos dias

[11:58] **+591 71875639:** Donde hay gasolina clarita

[11:58] **+591 71875639:** Reporten cumpas

[12:10] **+591 71875639:** Avisen

[12:10] **+591 68719052:**
> _+591 71875639: Reporten cumpas_
Tacuarandi sin fila

[12:12] **+591 71875639:** [Mensaje de voz]

[12:51] **+591 69327934:** Dónde hay etanol

[12:52] **+591 69327934:** Ahorita

[12:52] **+591 69327934:** Alguien sabe ???

[12:53] **+591 71866332:** EN ESTOS MOENTOS DONDE HAY GASOLINA ESPECIAL

[12:53] **+591 71866332:** BUENAS TARDES PUEDE AGREGAR AL COLEGA 71173625

[13:00] **+591 69327934:** Etanol alguien sabe

[13:03] **+591 78235592:** Buenas donde hay gasolina clarita? Porfvor

[15:11] **+591 76185088:**
> _+591 78235592: Buenas donde hay gasolina clarita? Porfvor_
Tacuarandi

[15:21] **+591 74525861:** Buenas tardes

[15:21] **+591 74525861:** Alguien cargo en las vegas

[15:21] **+591 74525861:** ???

[15:22] **+591 69312879:**
> _+591 69327934: Etanol alguien sabe_
En el agrupa

[15:23] **+591 78434896:**
> _+591 74525861: Alguien cargo en las vegas_
las Vegas la plus

[15:24] **+591 74525861:**
> _+591 78434896: las Vegas la plus_
Gracias

[15:37] **+591 71875639:** Dnd hay blanquita

[15:37] **+591 71875639:** Tacuarandi

[15:37] **+591 71875639:** De acabo

[15:38] **+591 78707745:** Hay etanol en Don Daniel

[15:38] **+591 78707745:** Allí cargue

[15:38] **+591 71875639:**
> _+591 78707745: Hay etanol en Don Daniel_
Hay blanquita

[15:45] **+591 71875639:** Dnd hay blanquita

[15:48] **+591 78707745:**
> _+591 71875639: Hay blanquita_
A mí me dijeron que hay plus ( la amarilla a las 12 del medio día)

[15:49] **+591 78707745:** Pero si hay etanol

[16:03] **+591 71875639:** [Mensaje de voz]

[17:45] **+591 79852237:** https://chat.whatsapp.com/GqxfA8YsYak24sO8L7xDTf
Buenas tardes, se hace recarga de Entel los 15bs de crédito a 10bs, usted puede cancelar mediante qr o depósito bancario
Igual se recupera líneas bloqueadas por falta de recarga a un costó de 4bs

---

## 13 de junio de 2026

[8:08] **+591 69312879:** Buen día alguien sabe donde están vendiendo gasolina especial

[8:28] **+591 75143839:**
> _+591 69312879: Buen día alguien sabe donde están vendiendo gasolina especial_
Buen dia....
Comuniquen xfavor

[8:49] **+591 71875639:** Wen dia

[8:51] **+591 71875639:** Esos surtidores dijeron q habra clara hoy tacurandi sointa panamericano y ypfb

[9:06] **+591 71875639:** Alguien cargo ya

[10:07] **+591 75119208:** Alguien sabe donde hay gasolina claritaa

[10:07] **+591 75119208:** Especial

[10:07] **+591 75119208:** Me puede pasar el dato

[10:07] **+591 75119208:** Por favor

[10:08] **+591 60272671:** Pasen el dato por favor

[10:35] **+591 71875639:** [Imagen]

[10:35] **+591 71875639:** Tacuarandi hay

[10:35] **+591 71875639:** Fila 20 autos nomas

[10:47] **+591 71875639:** [Imagen]

[11:07] **+591 71875639:** [Mensaje de voz]

[11:51] **+591 60272671:**
> _+591 71875639: Imagen_
Aceptan qr pa pagar ..?

[11:52] **+591 71875639:** Yes

[12:11] **+591 63780494:** Don Daniel no saben si esta bien la gasolina??

[12:11] **+591 63780494:** O campesino??

[12:34] **+591 72426015:** Buenos días aquí en el campesino en ypfb Acabo de llegar la Plus especial otro lado no sé en dónde hay

[12:35] **+591 71875639:** [Mensaje de voz]

[17:15] **+591 72963325:** Buenas tardes amigos donde hay gasolina blanca por favor

[18:14] **+591 75175156:** [Reenviado] [Imagen] 🚨 MOTO ROBADA 🚨

📍 Barrio Morros Blancos, Av. Fray Quebracho y calle Alejandrino Pérez 

Al promediar las 20:30 horas, delincuentes robaron esta motocicleta que se encontraba estacionada en la puerta de mi domicilio.

🏍️ Marca: Montero Deportiva
📌 Modelo: 2018

💰 SE OFRECE EXCELENTE GRATIFICACIÓN

🙏 Por favor, compartan esta publicación. Cualquier información puede ser de gran ayuda para recuperarla.

📞 Contacto: 73497075

---

## 14 de junio de 2026

[12:33] **+591 65841415:** [Mensaje de voz]

[20:04] **+591 78235592:** Alguien sabe dónde hay gasolina ahorita?

[20:08] **+591 78434896:** exterminal

[20:08] **+591 78434896:** la plus acabo cargar

---

## 15 de junio de 2026

[6:52] **+591 65841415:** [Mensaje de voz]

[8:29] **+591 68710005:**
> _+591 65841415: Mensaje de voz_
En el surtidor YPFB en morros blancos están dando blanquita

[8:30] **+591 74549616:** Alguien  sabe donde venden etanol??

[9:02] **+591 75127881:** Si por favor

[9:30] **+591 75119208:** Buenos días donde están repartiendo gasolina especial

[9:30] **+591 75119208:** Alguien sabe

[9:30] **+591 75119208:** Que surtidores por favor

[9:36] **+591 72962359:** Avisen dond hay la especial porfaaa

[12:33] **+591 63780494:** Nadie cargo en las vegas??? No saben si hay buena gasolina??

[12:34] **+591 70227368:** Buenas tardes alguien sabe donde están vendiendo etanol?

[12:48] **+591 71868154:**
> _+591 63780494: Nadie cargo en las vegas??? No saben si hay buena gasolina??_
Las Vegas gasolina plus

[12:48] **+591 78434896:** agrupa igual la plus

[12:50] **+591 76836092:** En el molle cargue la especial hace unos 20 min

[13:10] **+591 78240922:**
> _+591 76836092: En el molle cargue la especial hace unos 20 min_
Pase rápido x allí no me dio tiempo de preguntar x allí después diésel hay x allí i también x el moto mendes

[14:17] **+591 72955920:** Cuando vuelvas te pasas como yendo a San Lorenzo a mano derecha antes de llegar

[14:17] **+591 72955920:** A San Lorenzo..no la primera

[14:40] **+591 78240922:** [Imagen] Gasolina especial surtidor panamericano no mucha fila

[14:42] **+591 72955920:** Gracias

[15:12] **+591 65800835:** [Imagen]

[15:12] **+591 71875639:**
> _+591 65800835: Imagen_
Dnd

[15:14] **+591 63780494:** Tiene pinta de tacuarandi

[15:17] **+591 71875639:** Eso mismo decia

[15:18] **+591 71875639:** Ta demas de blanca no vamos tener q mesclar con la plus un pokito

[15:21] **+591 65800835:** Panamericano es

[15:21] **+591 65800835:** San geronimo

[15:29] **+591 63780494:** 👍🏻👍🏻

[15:30] **+591 71875639:** _Se eliminó este mensaje_

[15:31] **+591 71875639:**
> _+591 65800835: Imagen_
San geronimo

[17:37] **+591 79852237:** https://chat.whatsapp.com/GqxfA8YsYak24sO8L7xDTf
Buenas tardes, se hace recarga de Entel los 15bs de crédito a 10bs, usted puede cancelar mediante qr o depósito bancario
Igual se recupera líneas bloqueadas por falta de recarga a un costó de 4bs

[19:27] **+591 72944424:** Buenas noches, sabe alguién donde estan vendiendo diesel

---

## 16 de junio de 2026

[8:05] **+591 77870087:** Buen día ...no saben donde estan vendiendo gasolina especial ?

[8:12] **+591 72962359:** Morros blancos

[8:21] **+591 77870087:** Gracias

[8:52] **+591 68686988:** Buenos dias si alguien tuviera la cuenta del bsisa para pagar al banco

[9:01] **+591 76945645:** Buen día, alguien sabe dónde hay Etanol

[9:01] **+591 76945645:** ?

[9:04] **+591 72999400:** Buen día alguien sabe donde hay gasolina clarita??

[9:10] **+591 72962359:** Morros blancos están pidiendo besisa

[12:23] **+591 79256927:** Buenos días, porfa alguien q me informe en q surtidor está vendiendo etanol.?

[12:25] **+591 75127881:** Sii por favor alguien sabe

[12:37] **+591 76945645:** En Agrupa NO HAY

[12:44] **+591 63780494:** Alguien sabe de la vegas hay fila seguro debe haber la especial alguien puede confirmar por favor

[12:44] **+591 75119208:** Las vegas gasolina clara

[13:06] **+591 72974985:** Agrupa fila larga debe haber gasolina blanca

[13:15] **+591 71894444:**
> _+591 75119208: Las vegas gasolina clara_
En las Vegas???

[14:03] **+591 72999400:** Gasolina clarita en el agrupa

[14:04] **+591 71894444:** Agrupa es en el mástil verdad?
Hay fila por si acaso?

[14:38] **+591 68691228:** Las Vegas  fila corta

[14:39] **+591 77870087:** Don Daniel... Gasolina especial .. Recién estan comenzando a llenarse la fila

[15:33] **+591 69327934:** Etanol ?

[15:33] **+591 69327934:** Alguien sabe

[15:33] **+591 69327934:** Urgente

[15:33] **+591 69327934:** Por favor

[16:22] **+591 74525861:** Alguien sabe si todavía hay en las vegas

[16:22] **+591 74525861:** ????

[16:24] **+591 69307503:**
> _+591 74525861: Alguien sabe si todavía hay en las vegas_
Hace media hora cargue sin fila

[18:29] **+591 61862568:** No saben donde esta n vendiendo gasolina clarita...?

[18:31] **+591 63786945:** En la agrupa gasolina clarita

[18:32] **+591 61862568:** Gracias

[19:49] **+591 72693210:** Gasolina especial en el agrupa

[21:07] **+591 67395153:** _Se eliminó este mensaje_

---

## 17 de junio de 2026

[8:29] **+591 72943744:** Buenos días disculpa alguien sabe enque surtidor están vendiendo etanol se los agradecería el dato gracias..

[8:30] **+591 68289593:** La misma pregunta

[8:30] **+591 68289593:** Ago

[9:19] **+591 75146448:** Buen dia alguien sabe donde hay gasolina especial

[9:22] **+591 75127881:**
> _+591 72943744: Buenos días disculpa alguien sabe enque surtidor están vendiendo etanol se los agradecería el dato gracias.._
Siii por favor si alguien sabe 🥺

[11:03] __+591 75515740 se unieron mediante el enlace de invitación__

[11:42] **+591 73483881:**
> _+591 75127881: Siii por favor si alguien sabe 🥺_
Las Vegas está clara

[11:58] __Alguien añadió a +591 75515740__

[12:08] **+591 75113568:** Las Vegas gasolina clarita no hay fila

[12:25] **+591 78708725:** Hay fila en el surtido Las Vegas

[12:26] **+591 67963233:** Clarita esta

[12:26] **+591 78708725:** Siii

[12:26] **+591 75175156:** No hay etanol en ningún surtidor ⛽️,  ya fui a ver!

[12:27] **+591 75127881:**
> _+591 75175156: No hay etanol en ningún surtidor ⛽️,  ya fui a ver!_
[Sticker]

[12:27] **+591 78708725:** [Imagen]

[12:30] **+591 78708725:** [Imagen]

[12:53] **+591 74670785:** [Mensaje de voz]

[12:53] **+591 71875639:** Vegas

[12:53] **+591 78708725:** Surtidor Las Vegas

[12:55] **+591 72940266:** Hay fila?

[12:56] **+591 78708725:** Sii

[15:20] **+591 68289593:** En el portillo llego gasolina especial

[15:20] **+591 68289593:** Blankita

[15:39] **+591 68648395:** _Se eliminó este mensaje_

[15:39] **+591 68648395:** _Se eliminó este mensaje_

[15:54] **+591 68289593:** [Mensaje de voz]

[16:02] **+591 75175156:** Gracias 🙌🏼🙌🏼

[17:27] **+591 75515740:** Gracias

[18:12] **+591 72943744:** Algun surtidor con etanol?

[18:12] **+591 72943744:** Por favor

---

## 18 de junio de 2026

[6:30] **+591 68289593:** Alguien save  enqué surtidor están vendiendo Diésel

[8:09] **+591 75127881:** Etanol alguien sabe por favor

[8:17] **+591 75175156:** Etanol x favor

[8:52] **+591 67960504:** Buenos dias donde ay gasolina limpia

[8:56] **+591 60252340:** Etanol en sointa

[8:58] **+591 72940266:** Alguien sabe si en el portillo sigue habiendo gasolina especial? Hay filas?

[8:59] **+591 60252340:** N hay en el Portillo

[9:15] **+591 73483881:**
> _+591 60252340: Etanol en sointa_
Hay fila ?

[9:18] **+591 60252340:** Si

[9:23] **+591 72943744:**
> _+591 60252340: Etanol en sointa_
Solo la plus.. No hay etanol

[9:24] **+591 60252340:** Si yo cargué

[9:25] **+591 75119208:** Gasolina especial en las vegas

[9:25] **+591 75119208:** Pero con full fila

[9:26] **+591 71875639:**
> _+591 75119208: Gasolina especial en las vegas_
Gracias

[9:26] **+591 72943744:**
> _+591 60252340: Si yo cargué_
acabo de hacer fila y me dicen que no tienen solo la plus

[9:28] **+591 60252340:** Entonces ya se acabó xq yo cargué

[10:33] **+591 72943744:** Acaba de descargar la etanol en sointa

[16:11] **+591 71871854:** Hola

[16:36] **+591 68686988:** Donde hay gasolina

[17:54] **+591 71875639:** Dnd hay gasolina pibes

[17:59] **+591 79852237:** https://chat.whatsapp.com/GqxfA8YsYak24sO8L7xDTf
Buenas tardes, se hace recarga de Entel los 15bs de crédito a 10bs, usted puede cancelar mediante qr o depósito bancario
Igual se recupera líneas bloqueadas por falta de recarga a un costó de 4bs

[18:13] **+591 71875639:** Gasolina blanca

[18:13] **+591 69307503:**
> _+591 71875639: Gasolina blanca_
Vi fila en sointa

[18:13] **+591 69307503:** Imagino q ahí debe estar buena

[18:14] **+591 71875639:** Ya paso x ahi

[18:19] **+591 75127881:**
> _+591 69307503: Vi fila en sointa_
Etanol hay

[19:06] **+591 78434896:** dónde puedo cargar gasolina en bidón buenas noches

---

## 19 de junio de 2026

[7:40] **+591 78434896:** dónde hay gasolina buenos días

[7:40] **+591 78434896:** alguien sabe?

[7:42] **+591 71191508:** Buenos días en el que estuvimos al lado de la UPDS

[7:59] **+591 71875639:**
> _+591 71191508: Buenos días en el que estuvimos al lado de la UPDS_
Ahi hay?

[8:00] **+591 71191508:**
> _+591 71875639: Ahi hay?_
Si

[8:00] **+591 69315287:** Esta clarita acabo de cargar

[8:01] **+591 78434896:**
> _+591 69315287: Esta clarita acabo de cargar_
y que tal la fila?

[8:01] **+591 69315287:** Nada

[8:02] **+591 78434896:** venden en bidón en ese surtidor?

[8:02] **+591 69315287:** Entre y sali

[8:02] **+591 69315287:**
> _+591 78434896: venden en bidón en ese surtidor?_
Si

[8:02] **+591 78434896:** muchas gracias por la información

[8:02] **+591 78434896:** 🫡

[8:02] **+591 71875639:**
> _+591 69315287: Esta clarita acabo de cargar_
En el tarija

[12:46] **+591 76945645:** Alguien sabe dónde hay Etanol? Por favor pase el dato

[12:52] **+591 72903627:** [Contacto: BEGIN:VCARD
VERSION:3.0
N:Chiki;Suco;;;
FN:Suco Chiki
item1.TEL;waid=59178225036:+591 78225036
item1.X-ABLabel:Móvil
END:VCARD]

[12:53] **+591 72903627:** Ola grupo xfavor será que pueden añadir al grupo xfavor

[15:02] **+591 69312879:** Buenas tardes grupo alguien sabe donde hay etanol

[15:17] **+591 69312879:** O gasolina clarita

[15:18] **+591 72426015:** Don daniel cargue vacio

[15:18] **+591 72426015:** Sin fila

[15:18] **+591 71875639:**
> _+591 72426015: Don daniel cargue vacio_
Clarita

[15:23] **+591 69312879:** Gracias

[17:29] **+591 68697122:** Buenas tardes alguien sabe  dónde hay gasolina clarita o etanol?

[17:45] **+591 69312879:** Donde don Daniel cargué hace una hora había los dos combustible

[19:09] **+591 76185088:** Buenas noches, donde podría conseguir etanos?

---

## 20 de junio de 2026

[8:29] **+591 72955920:** Buendía..alguien sabe??

[8:29] **+591 72955920:** Donde hay gasolina Clarita???

[8:30] **+591 71875639:** Wen dia

[8:30] **+591 71875639:** Dnd hay gasolina clarita

[8:51] **+591 72945325:** [Mensaje de voz]

[8:53] **+591 71875639:** [Mensaje de voz]

[11:06] **+591 77870087:** Alguien sabe donde están cargando diesel por favor

[11:38] **+591 72955920:** Vegas

[12:32] **+591 77870087:** Gracias

[17:57] **+591 75146448:** Buenas tardes alguien sabe donde hay gasolina

[17:58] **+591 75146448:** Blanquita

[18:08] **+591 61862568:** Donde don Daniel están vendiendo...

[18:16] **+591 75146448:**
> _+591 61862568: Donde don Daniel están vendiendo..._
La especial?

---

## 21 de junio de 2026

[9:13] **+591 74525861:** Buenos días grupo

[11:01] **+591 73499985:** Buen día donde hay gasolina especial y etanol.?

[13:00] **+591 75515740:** Buenas tardes

[13:00] **+591 75515740:** En que surtidor hay gasolina ? Alguien podría informarme....
Gracias

[15:01] **+591 74541392:** Buenas tardes disculpen alguien sabe en que surtidor hay gasolina xf.

[17:25] **+591 73454786:** Buenas tardes alguien sabe  en qsurtidor hay gasolina?

[17:26] **+591 73454786:** Por favor alguien podría decir

[17:40] **+591 74515367:** En el surtidor de la ex terminal cargue hace 20 minutos

[18:06] **+591 74525861:**
> _+591 74515367: En el surtidor de la ex terminal cargue hace 20 minutos_
Hay la especial

[18:06] **+591 74525861:** ??

[18:07] **+591 79852237:** https://chat.whatsapp.com/GqxfA8YsYak24sO8L7xDTf
Buenas tardes, se hace recarga de Entel los 15bs de crédito a 10bs, usted puede cancelar mediante qr o depósito bancario
Igual se recupera líneas bloqueadas por falta de recarga a un costó de 4bs

[20:24] **+591 76836092:** Alguien sabe dond hay gasolina ahorita

---

## 22 de junio de 2026

[9:53] **+591 69327934:** Hay etanol ?

[9:57] **+591 70236796:** Buenos dias algun surtidor donde haya gasolina por favor

[9:59] **+591 74541392:** [Imagen]

[10:05] **+591 69327934:** Etanol en que gasolinería

[10:23] **+591 73499985:** Buenas. Donde hay gasolina especial o etanol?

[10:25] **+591 69913636:**
> _+591 73499985: Buenas. Donde hay gasolina especial o etanol?_
En el surtidor Tarija hay la clarita acabo de cargar pero hay fila

[15:02] **+591 67963233:** Alguien sabe si Don Daniel

[15:02] **+591 67963233:** Tiene gasolina

[15:02] **+591 67963233:** Por favor

[15:26] **+591 71894444:** Donde hay gasolina a esta hora?

[15:57] **+591 71875639:** Dnd hay

[15:57] **+591 71875639:** Gasolina clara

[16:18] **+591 75113568:** En el agrupa hay gasolina clara la fila no está muy larga

[18:24] **+591 68720262:** [Mensaje de voz]

[18:25] **+591 71875639:** Don daniel

[18:25] **+591 71875639:** Hay clarita

[18:26] **+591 68720262:** Gracias

---

## 23 de junio de 2026

[8:07] **+591 78249245:** buen día algun surtido que tenga gasolina ahorita?

[8:38] __[Llamada]__

[8:56] **+591 78235592:** Buen dia donde hay gasolina blanca porfavor

[9:33] **+591 71894444:** Tacuarandi
Cargue hace 15 min
Sin fila

[9:51] **+591 65800835:**
> _+591 71894444: Tacuarandi
Cargue hace 15 min
Sin fila_
La especial?

[9:52] **+591 71894444:** Si
Como agua 😎

[12:12] **+591 74670785:** Avicen donde  hay  gasolina  especial  por   favor

[12:12] **+591 78434896:**
> _+591 74670785: Avicen donde  hay  gasolina  especial  por   favor_
tacuarandi

[12:34] **+591 71199691:** Ubicación dell tacuarandi

[12:38] **+591 71875639:**
> _+591 71199691: Ubicación dell tacuarandi_
Antes de llegar ala carcel

[12:39] **+591 63780494:** Panamericano la especial también hace media hora había fila

[12:39] **+591 63780494:** Es pasando coliseo universitario

[13:28] **+591 74525861:** Buenas tardes

[13:28] **+591 74525861:** Por favor algún surtidor que tenga  gasolina especial

[13:28] **+591 74525861:** Por favor

[13:29] **+591 63780494:** [Sticker]

[13:30] **+591 69327934:** En qué gasolinería hay etanol ?

[13:30] **+591 69327934:** Alguien sabe

[14:21] **+591 74525861:** Amigos por favor urgente

[14:24] **+591 68686988:** Saven si hay gasolina en el agrupa o don daniel y la fila porfa

[14:24] __[Llamada]__

[15:25] **+591 76185088:** Buenas tardes pueden agregar este número por favor 75117850

[15:52] **+591 72426015:** Surtidor Tarija que Gaslina llegk alguien cargo

[16:12] **+591 78434896:** gasolina especial en surtidor las Vegas

[16:12] **+591 78434896:** no hay fila casi

[16:12] **+591 78434896:** aprovechen

[18:28] **+591 74525861:** Ahorita saben si siguen cargando??? En las vegas

[18:53] **+591 68686988:** En don daniel ase 30 minutos seguian cargando nl abia fila solo 3 a 4 autos

[23:02] **+591 71866559:** [Reenviado] 📢 AVISO DE EXTRAVÍO

Se extravió una mochilita alrededor de las 22:00 horas en el rompe muelles de SETAR, sobre la Av. Jaime Paz Zamora.

En su interior se encuentran medicamentos de uso exclusivo para una persona adulta mayor, además de algunos objetos personales que únicamente tienen valor y utilidad para sus propietarios.

Solicitamos la colaboración de quien la haya encontrado para su devolución. Se ofrecerá una gratificación a la persona que brinde información verídica o la entregue.

Cualquier dato será de gran ayuda. Agradecemos de antemano su honestidad y colaboración.
Contactos: 74502676  -  61863426

---

## 24 de junio de 2026

[8:48] **+591 71875639:** Wen dia

[8:48] **+591 71875639:** Dnd hay gasolina clarita

[8:58] **+591 68691228:** Buen día ... Por favor si alguien sabe en qué surtidor están vendiendo gasolina

[10:05] **+591 75127881:** Buenos días alguien sabe en que surtidor hay gasolina etanol

[10:19] **+591 68695886:** Buenos días donde venden en bidón gasolina

[10:20] **+591 68691228:** Porfa el precio del etanol y en qué surtidor hay

[10:22] **+591 75127881:**
> _+591 68691228: Porfa el precio del etanol y en qué surtidor hay_
8.28 bs

[10:26] **+591 68691228:**
> _+591 75127881: 8.28 bs_
Gracias

[10:42] **+591 70227368:** Buen día alguien sabe en qué surtidor están vendiendo etanol por favor

[12:10] **+591 71875639:** Q surtidor hay blanca

[12:11] **+591 68680221:**
> _+591 71875639: Q surtidor hay blanca_
Eso no venden en surtidores...!!! 😳😳😳🤣🤣🤣🤣🤣🤣

[12:12] __[Llamada]__

[12:13] **+591 71875639:** Claro

[12:13] **+591 71875639:** Gasolina blanquita dnd hay

[12:47] __+591 67995662 añadió a +591 71897189__

[12:48] **+591 67995662:** _Se eliminó este mensaje_

[12:49] **+591 71897189:** Buenas tardes gracias x incluirme

[12:50] **+591 67995662:**
> _+591 71897189: Buenas tardes gracias x incluirme_
[Sticker]

[12:50] **+591 67995662:** No sé preocupes mi estimado

[12:50] **+591 67995662:** Si para eso está el grupo

[12:51] **+591 71897189:** Alguna noticia de la venta de gasolina

[12:52] **+591 75127881:** Etanol por favor alguien sabe donde hay

[12:52] **+591 75127881:** [Sticker]

[12:53] **+591 67995662:**
> _+591 75127881: Etanol por favor alguien sabe donde hay_
[Mensaje de voz]

[12:56] **+591 75127881:**
> _+591 67995662: Mensaje de voz_
Gracias, pasaré a ver ahí

[12:56] __+591 67995662 cambió el nombre del grupo a "GASOLINA EN TARIJA 🏍️🚗⛽"__

[12:57] **+591 71897189:** Alguien puede confirmar si estan vendiendo gasolina en las Vegas

[12:57] __+591 67995662 cambió el nombre del grupo a "⛽🚗🏍️GASOLINA EN TARIJA 🏍️🚗⛽"__

[13:20] **+591 78434896:** [Mensaje de voz]

[13:59] **+591 71897189:** Es verdad confirmen x favor

[14:22] **+591 74525861:** Gracias

[14:22] **+591 74525861:** En las Vegas no saben que gasolina tienen??

[17:25] **+591 75127881:** Alguien sabe donde hay gasolina etanol?

[17:27] **+591 74525861:** Nada no saben dnd hay gasolina especial?????

[17:33] **+591 75143839:** no sean malos...avisen

[17:34] **+591 75127881:** Si por favor

[17:34] **+591 71875639:** Dnd hay gadolina especial

[17:34] **+591 78434896:** ex terminal había de la plus hace ratos pase por ahí

[17:37] **+591 63780494:**
> _+591 71875639: Dnd hay gadolina especial_
Panamericano hay

[17:37] **+591 63780494:** Sin fila

[17:37] **+591 71875639:** Gracias

[17:45] **+591 75143839:**
> _+591 63780494: Panamericano hay_
Gracias

[17:45] **+591 79852237:** https://chat.whatsapp.com/GqxfA8YsYak24sO8L7xDTf
Buenas tardes, se hace recarga de Entel los 15bs de crédito a 10bs, usted puede cancelar mediante qr o depósito bancario
Igual se recupera líneas bloqueadas por falta de recarga a un costó de 4bs

[18:29] **+591 68695886:** Buenas noches alguien me podría  decir donde venden gasolina en bidón en que surtidor

[19:05] **+591 73483881:**
> _+591 68695886: Buenas noches alguien me podría  decir donde venden gasolina en bidón en que surtidor_
En todos

---

## 25 de junio de 2026

[7:14] **+591 71897189:** Buen día disculpen ya está normal la venta de gasolina  si alguien puede informar x favor

[7:25] __+591 62853115 se unieron mediante el enlace de invitación__

[7:29] __+591 64332273 se unieron mediante el enlace de invitación__

[7:31] __+591 74543937 se unieron mediante el enlace de invitación__

[7:32] __Alguien añadió a +591 74543937__

[7:33] __+591 76195199 se unieron mediante el enlace de invitación__

[7:34] __+591 71190102 se unieron mediante el enlace de invitación__

[7:35] __Alguien añadió a +591 71190102__

[7:38] __+591 67376519 se unieron mediante el enlace de invitación__

[7:48] __+591 67187005 se unieron mediante el enlace de invitación__

[7:54] __+591 72762728 se unieron mediante el enlace de invitación__

[7:58] __+591 73488712 se unieron mediante el enlace de invitación__

[8:04] __+591 64567196 se unieron mediante el enlace de invitación__

[8:04] __Alguien añadió a +591 64567196__

[8:12] __+591 72942858 se unieron mediante el enlace de invitación__

[8:13] __Alguien añadió a +591 72942858__

[8:16] __+591 72977230 se unieron mediante el enlace de invitación__

[8:17] __Alguien añadió a +591 72977230__

[8:45] **+591 72988009:** Gasolina alguien sabe en qué surtidor están vendiendo ?

[10:15] __+591 70233833 se unieron mediante el enlace de invitación__

[10:16] __Alguien añadió a +591 70233833__

[10:19] __+591 63788008 se unieron mediante el enlace de invitación__

[10:37] **+591 68720262:** [Mensaje de voz]

[10:40] **+591 71875639:** Dnd hay gasolina clarita avisen

[10:40] **+591 71875639:** Ayer no ya no pille en el panamericano

[10:47] __+591 67378495 se unieron mediante el enlace de invitación__

[10:47] **+591 72977230:** Esto mandaron en otro grupo

[10:47] **+591 72977230:** De la buena en presidente Arce pero hay fila larga

[11:00] **+591 72943744:** Buenos días

[11:00] **+591 73483881:**
> _+591 72977230: De la buena en presidente Arce pero hay fila larga_
Dónde es

[11:00] **+591 72943744:** Algun surtidor con etanol si alguien tiene el dotó por favor

[11:05] **+591 76836092:**
> _+591 72943744: Algun surtidor con etanol si alguien tiene el dotó por favor_
Moto Mendez hay etanol cargue hace media hora

[11:06] **+591 72943744:**
> _+591 76836092: Moto Mendez hay etanol cargue hace media hora_
Millon de gracias

[11:13] **+591 72977230:**
> _+591 73483881: Dónde es_
En morros blancos lado de la cárcel

[12:01] __+591 72423305 se unieron mediante el enlace de invitación__

[12:40] **+591 75515740:** Buenas tardes algun surtidor que estén vendiendo la clarita

[12:43] **+591 62853115:** Moto mendes

[12:44] **+591 75515740:**
> _+591 62853115: Moto mendes_
Dirección por favor

[12:45] **+591 62853115:** https://maps.app.goo.gl/wbB6LTmkbT29CYDz8?g_st=aw

[12:45] **+591 75515740:** Muchas gracias

[13:28] **+591 74525861:** Alguien cargo en las vegas????

[13:55] **+591 75515740:** Si

[13:56] **+591 75515740:** Hay gasolina plus
No hay fila

[14:09] **+591 71875639:** Dnd hay gasolina clarita

[14:09] **+591 71875639:** Avisen

[14:44] **+591 72955920:** Naiden cargo la Clarita?😆🫣😖..avisense colegas!!

[15:01] **+591 70227368:** _Se eliminó este mensaje_

[15:02] **+591 71875639:** Alguien cargo?

[17:21] **+591 71875639:** Gasolina clara en el panamericano

[17:21] **+591 71875639:** San geronim9

[17:27] **+591 79852237:** https://chat.whatsapp.com/GqxfA8YsYak24sO8L7xDTf
Buenas tardes, se hace recarga de Entel los 15bs de crédito a 10bs, usted puede cancelar mediante qr o depósito bancario
Igual se recupera líneas bloqueadas por falta de recarga a un costó de 4bs

[18:20] **+591 72762728:** Acabo de cargar etanol en el portillo

[19:42] **+591 71896210:** _Se eliminó este mensaje_

[20:01] __+54 9 11 3579-5951 se unieron mediante el enlace de invitación__

[20:57] **+591 68289593:** Alguien tiene el enlase del grupo

[22:17] **+591 70227368:**
> _+591 68289593: Alguien tiene el enlase del grupo_
X2

---

## 26 de junio de 2026

[1:18] __+591 67995662 eliminó a +54 9 3886 41-3903__

[1:18] __+591 67995662 eliminó a +54 9 11 3579-5951__

[1:20] **+591 67995662:**
> _+591 68289593: Alguien tiene el enlase del grupo_
👍🏻

[8:03] **+591 78249245:** Buenos días dónde están vendiendo gasolina especial

[8:08] **+591 67376165:** En agrupa había entanol cargue a las 7

[8:23] **+591 71875639:** Wen dia dond hay gasolina clarita

[8:24] **+591 63780494:** La vegas están vendiendo la plus ni se acerquen

[8:24] **+591 63780494:** [Sticker]

[9:33] **+591 67384303:** Buenos días dónde están vendiendo gasolina especial

[9:55] __+591 76192012 se unieron mediante el enlace de invitación__

[9:57] __Alguien añadió a +591 76192012__

[10:00] **+591 69304176:** Gasolina especial

[10:00] **+591 69304176:** Blanquita

[10:00] **+591 69304176:** Dónde pillo

[10:01] **+591 71875639:** En el Surtidor panamericano habia ayer

[11:11] **+591 72903627:** Bueno días dónde pollo gasolina blanquita xfavor

[12:32] **+591 69327934:** Etanol ?!

[12:32] **+591 69327934:** Dónde hay

[12:32] **+591 69327934:** Alguien sabe por favor

[12:34] **+591 75127881:** Decían en el surtidor del portillo

[12:39] **+591 69327934:** A
Qué hora ?

[12:39] **+591 69327934:** Dijeron eso

[12:39] **+591 69327934:** Será que si voy en la tarde hay ?

[12:40] **+591 69327934:** Alguien que cargo recién ?

[12:59] **+591 71894444:** Saben que tal esta la gasolina de san jorge?

[13:01] **+591 69307503:** Agrupa y ex terminal 
Había etanol al medio día

[16:50] **+591 68697122:** Alguien sabes dónde hay etanol ahorita??

[17:44] **+591 74540793:** Alguien sabe si el surtidor las Vegas está bien la gasolina?

---

## 27 de junio de 2026

[5:52] __+591 65810094 se unieron mediante el enlace de invitación__

[7:10] **+591 69312879:** Buen día alguien sabe donde están vendiendo gasolina especial

[7:17] __+591 61864938 se unieron mediante el enlace de invitación__

[7:59] **+591 71875639:** Wen dia dnd hay gasolina clarita

[8:09] __+591 73453408 se unieron mediante el enlace de invitación__

[8:17] **+591 69312879:** [Mensaje de voz]

[8:18] **+591 78434896:**
> _+591 69312879: Mensaje de voz_
gracias por el dato

[8:18] **+591 78434896:** 👍🏽

[8:18] **+591 71875639:** Gracias

[8:19] **+591 74525861:** Venden en bidon en el campesino???

[8:22] **+591 71875639:** Creo q no che

[8:28] **+591 78434896:** no venden en bidón

[10:04] **+591 77870087:** Buen día alguien sabe donde están vendiendo gasolina especial ??

[10:06] **+591 73483881:** Había en el campesino Pero al parecer se acabó

[10:12] __+591 76947163 se unieron mediante el enlace de invitación__

[10:12] **+591 76947163:** [Imagen]

[10:13] **+591 76947163:** Ay gasolina ⛽ aki

[10:14] **+591 71875639:**
> _+591 76947163: Imagen_
Dnd aki

[10:17] **+591 73140648:**
> _+591 76947163: Ay gasolina ⛽ aki_
Ubicación papito …

[10:33] **+591 78434896:** surtidor de san Gerónimo gasolina especial

[10:33] **+591 78434896:** fila corta

[10:33] **+591 78434896:** [Sticker]

[10:41] __+591 64599385 se unieron mediante el enlace de invitación__

[10:42] __+591 69302605 se unieron mediante el enlace de invitación__

[10:42] __+591 76186608 se unieron mediante el enlace de invitación__

[10:43] __+591 67995662 añadió a +591 72996643, +591 71190879 y +591 64580937__

[10:44] __+591 72898019 se unieron mediante el enlace de invitación__

[10:44] __+591 64321893 se unieron mediante el enlace de invitación__

[10:45] __+591 68705100 se unieron mediante el enlace de invitación__

[10:45] __+591 73456683 se unieron mediante el enlace de invitación__

[10:45] __+591 67995662 añadió a +591 67967487__

[10:46] **+591 73456683:** Buenos días a todos

[10:47] __+591 75131939 se unieron mediante el enlace de invitación__

[10:47] __+591 60251131 se unieron mediante el enlace de invitación__

[10:54] __+591 68717611 se unieron mediante el enlace de invitación__

[10:56] __+591 64349094 se unieron mediante el enlace de invitación__

[11:05] __+591 67382286 se unieron mediante el enlace de invitación__

[11:35] __Alguien añadió a +591 65810094__

[11:35] __+591 67995662 añadió a +591 76186608, +591 72898019, +591 64599385, +591 64580937, +591 72996643, +591 67967487, +591 71190879, +591 60251131, +591 64349094, +591 68705100, +591 73456683, +591 67382286, +591 75131939, +591 64321893 y +591 68717611__

[11:55] __+591 68534143 se unieron mediante el enlace de invitación__

[13:05] __+591 69487668 se unieron mediante el enlace de invitación__

[14:06] **+591 71875639:**
> _+591 76947163: Imagen_
Dnd es eso y es especial

[14:08] **+591 78434896:**
> _+591 71875639: Dnd es eso y es especial_
en san Gerónimo había la especial yo cargue casi 11 de la mañana

[14:18] **+591 72693210:** Tacuarandi

[14:18] **+591 72693210:** Gasolina especial

[15:03] **+591 63780494:** En panamericano gasolina especial recién cargue

[15:54] **+591 74507185:** Buenas

---

## 28 de junio de 2026

[9:27] **+591 71866332:** Buen día donde hay gasolina clarita

[9:30] **+591 72977230:** [Reenviado] [Imagen] Morros blancos, corta fila, avanza rapido

[9:30] **+591 72977230:**
> _+591 71866332: Buen día donde hay gasolina clarita_
Acaban de mandar esa información en un grupo 👆🏼

[9:37] **+591 74525861:** Buen dia

[9:37] **+591 74525861:** Otro lugar con gasolina especial

[9:38] **+591 72962359:** Gasolina especial dond hay bros

[11:40] **+591 73453408:** _Se eliminó este mensaje_

[12:09] __+591 68702274 se unieron mediante el enlace de invitación__

[12:30] **+591 63788008:** Alguien sabe si estan vendiendo gasolina en los surtidores del rancho ?

[15:26] **+591 67963233:** Alguien sabe donde hay gasolina a esta hora?

[15:28] **+591 78434896:**
> _+591 67963233: Alguien sabe donde hay gasolina a esta hora?_
agrupa pero de la plus

[15:28] **+591 67963233:** Don Daniel?

[15:28] **+591 67963233:** Habra

[15:28] **+591 67963233:** En la agrupa te piden bsisa

[15:30] **+591 78434896:**
> _+591 67963233: En la agrupa te piden bsisa_
si o si

[15:31] **+591 67963233:** San geronimo

[15:34] **+591 78434896:** en san Gerónimo cargan sin pedir el b sisa

[15:34] **+591 78434896:** tacuarandi igual pero nose si habrá en esos surtidores aun

[17:34] **+591 79852237:** https://chat.whatsapp.com/GqxfA8YsYak24sO8L7xDTf
Buenas tardes, se hace recarga de Entel los 15bs de crédito a 10bs, usted puede cancelar mediante qr o depósito bancario
Igual se recupera líneas bloqueadas por falta de recarga a un costó de 4bs

[18:42] **+591 67697073:** Alguien tiene gasolina

[18:46] **+591 67697073:** Unos 2 litros por favor compro

[22:33] __+591 75142943 se unieron mediante el enlace de invitación__

---

## 29 de junio de 2026

[8:51] **+591 74540793:** Buen día, donde están cargando gasolina en buen estado??

[8:57] **+591 78235592:** Buen dia alguien sabe donde hay gasolina blanca porfavor

[9:51] **+591 67960504:** Buen dia donde ay gasolina limpia

[9:52] **+591 74540793:** Saben si la gasolina del surtidor Tarija es buena??

[10:29] **+591 71192881:** [Reenviado] [Imagen]

[10:29] **+591 71192881:** Esta circulando este comunicado estan vendiendo normal en bidon  ?

[10:30] **+591 71875639:** Asi es

[10:33] **+591 71875639:** Alguien ya cargo gasolina clarita

[10:37] **+591 71894444:** Gasolinita clarita?
Alguien sabe donde?
👀👀

[10:54] __[Llamada]__

[11:16] __+591 67995662 añadió a +591 71195152__

[11:17] __Alguien añadió a +591 71195152__

[11:41] **+591 71195152:** Buen dia alguien save dond estan vendiendo gasolina especial

[12:22] **+591 71199691:** Yo cargue en el molle hace 1 hora

[15:10] **+591 75146448:** Buenas tardes

[15:10] **+591 75146448:** Alguien que sepa donde hay gasolina

[15:10] **+591 75146448:** Especial

[15:11] **+591 64321893:** Surtidor del campesino

[16:59] **+591 73456683:** Buenas tardes, disculpen me podrían decir donde están vendiendo diesel?

[16:59] **+591 73456683:** Donde la fila no esté larga

[17:00] **+591 72999358:** Buenas tardes alguien sabe en qué Surtidor están vendiendo gasolina especial clarita.

Porfavor?

[17:04] **+591 73456683:** Por favor alguien se sepa en que surtidor están vendiendo diesel

[17:05] **+591 73456683:** O donde están haciendo filas para diésel para mañana

[17:40] **+591 79852237:** https://chat.whatsapp.com/GqxfA8YsYak24sO8L7xDTf
Buenas tardes, se hace recarga de Entel los 15bs de crédito a 10bs, usted puede cancelar mediante qr o depósito bancario
Igual se recupera líneas bloqueadas por falta de recarga a un costó de 4bs

[20:26] __+591 72940584 se unieron mediante el enlace de invitación__

[20:35] **+591 72945844:** Buenas noches no saben dmd esta
Vendiendo gasolina clara

---

## 30 de junio de 2026

[6:03] **+591 71195152:** Buen dia alguien save si estan bendiendo gasolina en vidones ????

[6:07] **+591 71875639:** https://www.facebook.com/share/1JBC4ihvPN/

[7:50] **+591 75119208:** Buen día algún surtidor que este repartiendo gasolina claritaa

[7:50] **+591 75119208:** Me pasa el dato por favor

[8:52] **+591 67960504:** Buen dia donde ay gasolina limpia

[8:53] **+591 71875639:** Wen dia donde hay gasolina

[8:53] **+591 71875639:** Clarita

[9:28] **+591 78235592:** Buen día saben dónde hay gasolina clarita?

[9:42] **+591 75127881:** Buenos días alguien sabe donde hay etanol?

[9:49] **+591 72999358:** Buen día dónde venden gasolina especial por favor?

[9:58] **+591 71875639:** Avisen

[9:59] **+591 78235592:**
> _+591 75127881: Buenos días alguien sabe donde hay etanol?_
En el moto Mendez

[9:59] **+591 78235592:**
> _+591 72999358: Buen día dónde venden gasolina especial por favor?_
En el de los Molles me dijeron que hay

[10:01] **+591 71195152:** Alguien save si estan bendiedo en vidon

[10:06] **+591 71198548:** Buenos días

[10:06] **+591 71198548:** Alguien sabe en qué surtidor están vendiendo gasolina especial aquí en la ciudad

[11:51] **+591 71198548:** [Imagen]

[11:51] **+591 71198548:** Hay gasolina especial

[11:51] **+591 78434896:**
> _+591 71198548: Hay gasolina especial_
dónde es?

[11:52] **+591 72977230:**
> _+591 78434896: dónde es?_
Surtidor del rancho es,si no estoy equivocado

[11:53] **+591 71198548:** Surtidor el molle de rancho

[11:55] **+591 75143839:** otro surtidor q esté vendiendo la especial???

[12:13] **+591 72999358:** Las vegas

[12:26] **+591 71875639:**
> _+591 72999358: Las vegas_
Q hay

[12:29] **+591 68697122:** Buenos días ,no saben en qué surtidor están vendiendo gasolina en bidón ?

[12:35] **+591 74540793:** Ya no venderán en bidón en ningún lado a lo que dijeron hay que sacar permiso en anh

[12:38] **+591 65800835:**
> _+591 72999358: Las vegas_
Que gasolina hay en las Vegas?

[12:53] **+591 72999358:**
> _+591 65800835: Que gasolina hay en las Vegas?_
Especial.

Y diesel igual estaban vendiendo hace 1 hora más o menos

[13:00] **+591 63788008:**
> _+591 71198548: Imagen_
En rancho es

[13:05] **+591 71875639:**
> _+591 72999358: Especial.

Y diesel igual estaban vendiendo hace 1 hora más o menos_
Q hora cargaste

[13:05] **+591 72999358:**
> _+591 72999358: Especial.

Y diesel igual estaban vendiendo hace 1 hora más o menos_
.

[13:41] **+591 65800835:** Acabo de cargar gasolina especial en las Vegas, no venden en vidon

[13:44] **+591 71875639:** Gracias

[13:46] **+591 71894444:** Hay fila en las Vegas?

[13:47] **+591 65800835:** recién se estaba haciendo fila poquito 4 autos

[16:10] **+591 71894444:** [Video] No compro en bidón pero para aquellos que si....

[21:11] **+591 78249245:** buenas noches dónde están vendíendo gasolina

[21:11] **+591 78249245:** esta hora?

[21:13] **+591 69890833:** San martín

---

## 1 de julio de 2026

[8:38] **+591 75119208:** Buenos días algún surtidor que este vendiendo gasolina especial claritaa

[8:38] **+591 75119208:** Por favor

[8:38] **+591 75119208:** Me pasa el dato

[8:49] **+591 72042913:** Si porfar

[9:06] **+591 60252340:** Alguien sabe si están vendiendo en bidón xf

[9:24] **+591 76185088:**
> _+591 60252340: Alguien sabe si están vendiendo en bidón xf_
Solo estan vendiendo si cuenta con registro aprobado

[9:24] **+591 75119208:** Que surtidor Esta dando gasolina especial

[10:02] **+591 75127881:** Alguien sabe donde hay gasolina etanol

[10:02] **+591 75127881:** Por favor

[10:02] **+591 76945645:**
> _+591 75127881: Alguien sabe donde hay gasolina etanol_
En el Moto Mendez

[10:03] **+591 71894444:** Donde es disculpa

[10:04] **+591 75127881:** Un surtidor que sea en la ciudad 🫠

[10:06] **+591 76945645:** 🤣🤣🤣🤣🤣

[10:07] **+591 76945645:**
> _+591 71894444: Donde es disculpa_
Pasando el Rancho

[10:58] **+591 72903627:** Alguien sabe dónde hay gasolina blanquita xfavor avisas

[11:03] **+591 73483881:**
> _+591 72903627: Alguien sabe dónde hay gasolina blanquita xfavor avisas_
X2

[11:05] **+591 71875639:** AYER HABIA EN LAS VEGAS PERO HOY NO CREO Q HAYA

[11:05] **+591 71875639:** DONDE HAY GASOLINA LOCOS AVISEN NO SEAN JODIUS

[12:08] **+591 73483881:** En las Vegas supuestamente la especial, Pero no sé puede ver nadie compra en bidón

[12:10] **+591 71197917:** San Jorge  no hay mucha fila

[12:17] **+591 72964737:** si esacto ya no se puede ver xq ya no se ve q compran en vidon 🤦🤦

[12:18] **+591 72999358:**
> _+591 72964737: si esacto ya no se puede ver xq ya no se ve q compran en vidon 🤦🤦_
Cuando fulean las motos ahí se puede

[12:51] **+591 75143839:** [Mensaje de voz]

[15:02] **+591 75119208:** En la vegas gasolina especial

[15:02] **+591 75119208:** Recién acabo de cargar

[17:34] **+591 79852237:** _Un admin., +591 67995662, eliminó este mensaje._

[20:23] **+591 75127881:** Buenas noches alguien  sabe si en el surtidor de don Daniel hay gasolina etanol?

[20:23] **+591 75127881:** Me pueden avisar por favor

[20:29] __+591 67995662 eliminó a +591 79852237__

---

## 2 de julio de 2026

[9:52] **+591 72903627:** Alguien sabe dónde hay gasolina clarita xfavor avisan

[9:53] **+591 75143839:** En las Vegas dijeron

[10:03] **+591 63780494:** Portillo hay especial cargue 8 y 30 am

[10:20] **+591 72943744:** Buenos días disculpa alguien que sepa enque surtidor están cargando etanol se los agradecería el dato por favor

[10:48] **+591 62858652:** Buenos días alguien sabe dónde hay gasolina buena?

[11:43] **+591 75127881:**
> _+591 72943744: Buenos días disculpa alguien que sepa enque surtidor están cargando etanol se los agradecería el dato por favor_
Si por favor alguien 🙏

[12:05] **+591 72976766:**
> _+591 75143839: En las Vegas dijeron_
Las Vegas está con la Plus

[12:55] **+591 60272671:** Alguien sabe donde hay gaso especial

[14:31] **+591 75127881:** Buenas tardes alguien  sabe  en  que surtidor  hay gasolina etanol?
 Me pueden avisar por favor

[17:32] **+591 68616631:** [Mensaje de album]

[17:32] **+591 68616631:** [Imagen] buenas tardes a todos encontré este control x el barrio libertad si talvez se los perdió al privado muchas gracias

[17:32] **+591 68616631:** [Imagen]

[18:04] **+591 76947163:** Es mío

[18:04] **+591 76947163:** 😭😭

---

## 3 de julio de 2026

[0:50] **+591 71878341:** [Imagen]

[9:05] **+591 71875639:** Dnd hay gasolina clarita

[9:05] **+591 71875639:** Wen dia

[9:15] **+591 62858652:** En san gorje hay gasolina a buena dicen? Alguien confirma?

[9:18] **+591 72042913:**
> _+591 62858652: En san gorje hay gasolina a buena dicen? Alguien confirma?_
Si

[9:18] **+591 62858652:** Dale bro gracias

[9:18] **+591 62858652:** En bidón están dejando normal?

[9:18] **+591 72042913:**
> _+591 71875639: Dnd hay gasolina clarita_
Asta mañana dijeron que estará la clarita

[9:20] **+591 71875639:**
> _+591 72042913: Asta mañana dijeron que estará la clarita_
Dnd

[9:20] **+591 71875639:** San jorge

[9:21] **+591 72955920:** 👍🏻👍🏻👍🏻

[9:25] **+591 71195152:** Buen dia alguien save si estan bendiendo en bidon

[9:34] **+591 75119208:** Don Daniel clarita

[9:58] **+591 68648395:**
> _+591 75119208: Don Daniel clarita_
No hay

[15:03] **+591 69312879:** Buenas tardes

[15:03] **+591 69312879:** Alguien sabe donde hay gasolina especial

[15:03] **+591 69312879:** O etanol

[15:04] **+591 69312879:** Por favor

[15:22] **+591 78692302:** Etanol don Daniel

[16:47] **+591 71195152:** Buenas tardes alguien save dond hay gasolina clarita por favor

[16:53] **+591 72968117:** Surtidor don Daniel cargue recién

[17:06] **+591 75140034:**
> _+591 72968117: Surtidor don Daniel cargue recién_
Hay gasolina especial

[17:06] **+591 75140034:** ?

[17:20] **+591 60252925:** Ex terminal etanol

---

## 4 de julio de 2026

[9:12] **+591 75116493:** Daniel no tiene gasolina

[9:12] **+591 75116493:** Alguien sabe donde puede haber

[9:24] **+591 73483881:** San Martin

[9:24] **+591 67384303:**
> _+591 73483881: San Martin_
Hay clarita

[9:27] **+591 73483881:** No sé, no cargue.. solo ví fila de 5-10 🚗

[9:36] **+591 75140034:** Ayer cargue en el campesino dijeron q hasta el sábado llegara gasolina especial

[9:45] **+591 72955920:** Etanol Agrupa

[10:59] **+591 60272671:** [Contacto: BEGIN:VCARD
VERSION:3.0
N:;;;;
FN:Kevin Villanueva
item1.TEL;waid=59168681783:+591 68681783
item1.X-ABLabel:Móvil
PHOTO;BASE64:/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCABgAGADASIAAhEBAxEB/8QAHAAAAgMBAQEBAAAAAAAAAAAABQYDBAcCAQAI/8QANhAAAgECBQIDBgUEAgMAAAAAAQIDBBEABRIhMQZBE1FhInGBkbHwBxQVI6EyQtHhYsEWUpL/xAAZAQADAQEBAAAAAAAAAAAAAAACAwQBAAX/xAAiEQACAgICAgIDAAAAAAAAAAAAAQIRAyESMSJBUXETFGH/2gAMAwEAAhEDEQA/AMulYPNqQLpuFOk8ni9+MR0tRozOCcq6IGGlWbYji/zviJ6hm1rLcu17Edzbb4DyxEfYQTEELfm3J8vfjYsGSNg6YqhJJUxyOqlghU+ZUk7/AE+ODaVCy5pHWRkKq3ijA2uAhJ272PHx88Y5L1PXZLmLxhUmgcBkJFiFO+xwZy3rBK1oV/NimaNmbw3734tg5JOSfsCMmotemaH0z1ZJleY5lrop6mMyoxaFlut0W3skjywz0/4k5D+u1UlTNPRI1LCiiqhZfaDy33FwP6hvfGa9F1SzV2cawApeNlF/7fat/AGDdXBT1GbzxKAmqkjI/wDqS/8A1iLLOsjRZjgnCJB13nVBn2Wyw0NdT1Hj1MKARShjvIOQMUvx4l8V8lAsSqzH5lP8HAibK4Is9yqQJGD+pU63C2Ni4v8ATFX8YM2TMOpqfLqZizU0IWWw4Zjqt8iMdj9Ubk0Zq+uViBuAcXaHKp6qZVWwueTiwsN/DgiQbDf1OGPKKVoHBkGkjzwc50tB4cPN7IJujK5rTQaJzb2k4+WJ+jq+bIuraeYBonhca0tYgA7g41HpimSdlaVbpwL98DOvsipKHqCjzSmRY2kBSRVHJtscSrK3plGXDFPxMakIfnFdhYgkkkee+OzqU2Nh7zbHDEaNWsafMDF6PNY65PBQ5hl9ItTTRTlhod5DfwlUbWHO5vfAbNOkJxPNLQmMxf1JHYre52ChiST93OJ+m3b8szwsSsTln/8AYL7JuB8LfHDMkYzjxa7U58KQKsarpuAQS3puDxyPXBy+RcNaEbJs6zTpurlSJF9qyvHKCeOO/r2w5U3WUE9bJPUoYCsaxalbWLgse29t/LFeppJPYSsoIw0rMIpJFDMpvYG3Frjg9jhVzfLny6pBRDGsg1BGOqwvYEN3BwmUIy7HKco9D2ayKprcpnjlR1GYwe0rXG2o8/DCx1dPHN1XmdUkqHxZbB0YEaQABY/DAJEWp237Fge3a/r/ALx3VKCw0AAAWwKhxGqTn2iKCXwp1MTkv8xjQ63J6vJsloKqsKCeceI6O1io5Athb6IyZcw6qoElW6CVXIAvxvvjUPxO6dmzSSkmp3JkS4MXmNsKyyXJIrwRaVkvReefmCsM1KdIHsSLuuOfxLiqA9DMu8RJsR2IxN0Pl1XlWVxQzLHMrG5uumRN/Lgj1+wf6uo4a6kpKRm0oZQ7eYUc2+mJ9XoZPrZ+YtSobWjY9mYWA+A5+OI5HBYk6m8t/p5Y5CgduMeOTj0jyWGunazwKtxobwyFLANuQGHce/8AjDnDNKjBEYgsC0Ji3Ki9zfsCOMZ7lE/gZguxOtGQgeo2/m2HKBxE8EnhLIgQSOxbYN5rffzuO3rfBPoBLYwCX8yWjleEvMQFVxp8NrAj6MfTjC3WZLUR5ZJHXSO8ninw3a5U22ABI8z/AAcEmiWKCSoE5lk0m8cakA777effne5xYSuNPLLS5hUhERV8HUQyKV3V/v0wIXRn8UUkEzo40sPZI+/dj6eRQdHFvTDJXNSS01RI6rJIV1/mlJI294BtwO/xwvIgkkBXfUcAyjG7Gf8AD8xQZsJGYamGhg9wNJ8iN74c+sTWZdFlslPVSyU0LFULuWNm3tqO5474pdEZPI00btCj0wNnBFx8Rgt1hkVRUZlQ0NDNKtPUS62jO6xgckeXuxHOScz0orjFJDv04VnyWGdgAzLc4TesupqWmzOaGWQRGAEKGcfuWFzYee4998H5s8yzpfLFfMapaenUeHHcEl2AJNgPv54/O+f5y2e51U10tx4rkop/tW+w9/n643Fj5/QjPkUE/kFnjb3Y4b05xPUwSUdQYZkIcWPp/vEY1HYLz6YuR5z0fUzGKshctpKup9ecNaUcoiAhJ8cXARr6XN+R8DxgFQZBmGYMvhQNoJ/rOw+/dhnrqWoo2jincKSLs6tse9xf5fDG+qA6dlapziGCmqqmPWHI0rGxutybGw7bH68YXJ6yWVbM7HYC5a+w4A9Bf6YvZsQiERqAC4DNvZhzx5jb5nAdmstl3PpjKDR1V1sstMsBI0hixsN2P/I8t8eO2LtNJIdLxXubXXAkowHtCx2NvTBGhqTSgSixK7gHg4yQePT2a70LnVVl1LpmpHKnv5/PDbmPUtNDCKqsCQC1lufab0Ud8YTJ1tm6m0dQkVtrIg/7vgcc0rK+oLPPJLIdy7EsecSvA27Zb+xHqO2NPVOenqbPfDkVVp4xohtuUNr2Pvsd+d+9hhUmpQ0jADwnH9uDlVBDkKUSeMKkTosk7ICGW5NxuOeOLjDFF0dH1DlM9bl1aryRxkwRgDXcf2OFJsT2tf104OMuP0TTXLfsXTBDMI6TMgUkQnTIBum97HzB3+o7gnaejyjKER2Cu44L+2R3BUY8kyKr6icPQLG8cd1MrEAaubeZ7YG0k1NTZqKfNKZ2hico6FiGFtiL/wA4YnTAatB39dknkMdDStLK3BK3J+A3xY/8ezat8OozOaGjhG6mdgtvcv8Am2PZerDTEwZJQQ0kC7A+GC7e/wCzhbzjMKuo1y1Esk9S4Ogdh6+QG/GDtvoU4q6YJ6rlozmngUc5qEgXS81gA797W7DYfPAKGxnAvv2FsXKqGKOgVWhcVDPdzIewHYDtuP5wOgilkn/bI1A8k23xvYSTTpIlrvYZU06SvYm5N7HnyxXVXlU2dduxa2O6hJwbzKfZshNuD5e/FiWFPyQ3vZQ23n9nHHRg5X/CqkQcEXOrt5fHF6hjSGdNblTzexPHe2Iow0qKqophXcqr2J95tiOoJgqWTwjGoBAUm/I5v3xj2dGSiaHXZ3l0hgp86pR4bRft10P7gP8Ay0sTax5Ub+R4OEr9RrhWQSM0iIu8S8ADzA7cdsU4p5GgEJJaIAkqTcKT3A+A+WD0NS5pGpJ0VqTTcm/fkWPvt8/XCuKiU4oflvdUWMvqqkU0qwVbx0ztdkDkDy4HpbHs8I3aFtTFbXtihSTeJGXYKmo3YLte3fFtcxpoWUFwL823w5RRI5NPR5SVjKRHKTpH8ff3twVskiWtfYi5+mKL0wrKeSooWEjqt5AvIHnb4Y4oK90jMdg/GnUbD3X7f6+WLx0+jWuflHsmlp46uJ6dxZ02BP1wtyQtQ1LJKNIJ3v8AXDOS1UBUJE8Mo2ZW5uMRZpQCvojZf3VFx/jAp0yhN1fsVa+R3dLsCmm4IPJ74gaolaIRlvZG3wxGyspKNcEHjHmGE7k7bLFDb84lxcb7YhmcvK12JANgT5Y8VijBlNiDcHHN98cCWoEj8BpJP6VNvefLF95l/IIkMieGZNRRSdS272vuPXAqFPEYgsBbex74tOrQ0fsBVVti97Fvd3tgWgoya6P/2Q==
END:VCARD]

[10:59] **+591 60272671:** Podrían añadirlo al grupo por fa

[11:00] **+591 60272671:** Y no saben en que surtidor no hay gaso especial

[11:00] **+591 60272671:** .?

[11:12] **+591 71198548:** Alguien ya cargo gasolina especial clarita

[11:37] **+591 74534560:** En San jorge ay gasolina especial

[11:37] **+591 74534560:** [Imagen]

[11:49] **+591 74543937:** Aparte del carnet  piden registro o venden nomas por fa

[12:09] **+591 60272671:** Hay qr

[12:09] **+591 60272671:** Para pagar ahi en le san jorge ..?

[12:12] **+591 75146971:**
> _+591 74534560: En San jorge ay gasolina especial_
Cuál surtidor disculpe ?

[12:21] **+591 74534560:**
> _+591 74543937: Aparte del carnet  piden registro o venden nomas por fa_
Solo con carnet te cargan 20 litros

[12:59] **+591 72985002:** Hay etanol dónde don Daniel, estoy cargando

[13:41] **+591 78249924:** [Imagen] Amigos tomen en cuenta el etanol no se puede usar el.  100%  solo es un porcentaje lo demás si o si tiene q ser gasolina

[13:54] **+591 60251131:** Igual que la especial y la Plus hay que saber para que tipos de vehículo son

[13:54] **+591 78249924:** 👍👍

[13:58] **+591 68705100:** _Se eliminó este mensaje_

[13:58] **+591 74543937:** [Imagen] Chusflai

[15:44] **+591 65811053:** Buenas tardes

[15:44] **+591 65811053:** Alguien sabe donde hay gasolina clarita??

[15:50] **+591 76185088:** Buenas tardes
En que surtidor cargan gasolina solo con fotocopia de carnet

[15:50] **+591 76185088:** Algún dato por favor

[15:51] **+591 72999358:** Arriba ya dijeron

[15:52] **+591 74670785:** En el Molle

[18:22] **+591 71195152:** Buenas alguien save dond estan bendiendo gasolina espesial por favor ???

[20:09] **+591 71875639:** Dnd hay gasolina clara

[21:05] **+591 63795999:**
> _+591 71875639: Dnd hay gasolina clara_
Síi por favor

[21:05] **+591 63795999:** Donde ?

[21:49] **+591 68289593:** Compro 200 litros de gasolina especial pago 9.5bs

---

## 5 de julio de 2026

[11:57] **+591 62858652:** Alguien que tenga un gato bebé machito para regalar?

[15:00] **+591 75139390:** Buenas tardes alguien tuviera gasolina

[15:00] **+591 75139390:** Para vender

---

## 6 de julio de 2026

[8:22] **+591 71195152:** Buen dia aguien save donde estan vendiendo gasolina especial

[8:43] **+591 69312879:** Buen día compas alguien sabe donde están vendiendo etanol

[8:44] **+591 63788008:**
> _+591 69312879: Buen día compas alguien sabe donde están vendiendo etanol_
Si te sirve el dato Ayer en la tarde estaban vendiendo en el surtidor del rancho

[8:45] **+591 69312879:** Gracias

[9:39] **+591 72426015:** [Reenviado] https://docs.google.com/forms/d/e/1FAIpQLSfoikNlqarHuhdg_XkRORutZA0noHH63Q0S5tvTJ3HagUvNAw/viewform?usp=preview

[9:56] **+591 72426015:**
> _+591 72426015: https://docs.google.com/forms/d/e/1FAIpQLSfoikNlqarHuhdg_XkRORutZA0noHH63Q0S5tvTJ3HagUvNAw/viewform?usp=preview_
Buenos dias' me podrian ayudar a llenar esta encuesta por favor se les agradece...

[10:10] **+591 71878341:** [Imagen]

[10:45] **+591 67384303:** Buen dia donde hay gasolina clara

[11:09] **+591 75515740:** Buen dia alguien sabe donde están vendiendo 
Gasolina especial?

[11:09] **+591 75515740:** Por favor

[11:39] **+591 75119208:** Buen día donde están vendiendo gasolina especial clarita

[11:39] **+591 75119208:** Por favor

[12:07] **+591 72999358:** Buen día Alguien sabe si hay gasolina especial en la Ex terminal?

[12:07] **+591 72999358:** O San Gerónimo?

[12:33] **+591 72903627:** Alguien sabe dónde hay gasolina blanquita

[12:37] **+591 75110015:** Surtidor moto Mendez hay especial pero hay fila

[14:42] **+591 68710005:** Surtidor Don Daniel hay especial

[14:42] **+591 77175043:** Clarita en don Daniel???

[14:44] **+591 68710005:**
> _+591 77175043: Clarita en don Daniel???_
[Video]

[14:44] **+591 68710005:** [Mensaje de unknown]

[14:44] **+591 77175043:** Gracias

[14:46] __+591 76837768 se unieron mediante el enlace de invitación__

[14:47] __Alguien añadió a +591 76837768__

[14:59] **+591 71875639:**
> _+591 68710005: Video_
Daniel?

[15:00] **+591 62858652:** Alguien que tenga una motito en venta?

[15:43] **+591 77178786:** Buenas, saben si siguen vendiendo en morros blancos ?

[17:33] **+591 75119208:** Confirmado gasolina especial en don daniel

[18:44] **+591 71862952:** Podrian agregar al grupo a este numero porfavor

[18:44] **+591 71862952:** 71872723

[19:17] **+591 63794816:** Podrían agregar a este número al grupo por favor

[19:17] **+591 63794816:** 68698136

[19:32] **+591 67995662:**
> _+591 71862952: Podrian agregar al grupo a este numero porfavor_
Dale en seguida lo meto

[19:32] **+591 67995662:**
> _+591 63794816: Podrían agregar a este número al grupo por favor_
Ok

[19:33] __+591 67995662 añadió a +591 71872723 y +591 68698136__

[21:01] **+591 71872723:** Muchas gracias por agregarme al grupo

[21:30] **+591 60252340:** Gasolina especial en Camargo

---

## 7 de julio de 2026

[6:51] **+591 68616631:** [2 contactos]

[6:52] **+591 68616631:** a esos números será q puedes agregar xfa

[8:39] **+591 71894444:** En que parte están con gasolina especial?

[8:44] **+591 71875639:** Wen dia dond hay gasolina clarita

[8:47] **+591 78235592:** Buen día don hay gasolina blanquia por favor

[9:13] **+591 72949826:** Hay gasolina especial en ypfb morros blancos y en tacuarandi

[9:15] **+591 71875639:**
> _+591 72949826: Hay gasolina especial en ypfb morros blancos y en tacuarandi_
Confirmado es?

[9:26] **+591 73140648:** Buenos días

[9:27] **+591 73140648:** En el
Surtidor San Martín ay la especial…??

[15:15] **+591 69913636:**
> _+591 73140648: En el
Surtidor San Martín ay la especial…??_
En el tarija esta la gasolina especial clarita acabo de cargar no hay fila

[15:38] **+591 71872723:**
> _+591 69913636: En el tarija esta la gasolina especial clarita acabo de cargar no hay fila_
Donde queda?

[15:40] **+591 63780494:**
> _+591 69913636: En el tarija esta la gasolina especial clarita acabo de cargar no hay fila_
Ahí están pidiendo tarjeta bsisa??? Yo estoy registrado solo no tengo la tarjeta

[15:49] **+591 71872723:** Tacuarandi 100 puntos y sin cola

[16:06] **+591 78434896:**
> _+591 63780494: Ahí están pidiendo tarjeta bsisa??? Yo estoy registrado solo no tengo la tarjeta_
en san Gerónimo no hay mucha fila y no piden b sisa

[16:06] **+591 71875639:**
> _+591 78434896: en san Gerónimo no hay mucha fila y no piden b sisa_
Gasolina clarita?

[16:07] **+591 78434896:**
> _+591 71875639: Gasolina clarita?_
si la especial

[16:16] **+591 63780494:** Gracias

[17:01] **+591 75127881:** Buenas tardes alguien sabe donde hay gasolina etanol?

[17:06] **+591 71872723:** Mañana en la estación La Terminal

[17:07] **+591 75515740:** Buenas tardes alguien que me avise donde están vendiendo gasolina clarita por favor

[17:07] **+591 71872723:**
> _+591 75515740: Buenas tardes alguien que me avise donde están vendiendo gasolina clarita por favor_
En la estación Tacuarandi

[17:24] **+591 75515740:**
> _+591 71872723: En la estación Tacuarandi_
Gracias

[17:24] **+591 78235592:** Buenas saben si el surtidor de la domingo Savio está vendiendo gasolina blanca?

[17:42] **+591 75515740:** En Tacuarandi hay gasolina 
Clarita  acabo de cargar

[17:42] **+591 75515740:** Pueden ir no hay fila

[17:44] **+591 78235592:**
> _+591 75515740: Pueden ir no hay fila_
Gracias

[17:45] **+591 75515740:**
> _+591 78235592: Gracias_
👍🏻

---

## 8 de julio de 2026

[5:47] __+591 73897790 se unieron mediante el enlace de invitación__

[5:48] __Alguien añadió a +591 73897790__

[5:57] __+591 72973019 se unieron mediante el enlace de invitación__

[5:58] __Alguien añadió a +591 72973019__

[6:08] __+591 72983513 se unieron mediante el enlace de invitación__

[6:09] __Alguien añadió a +591 72983513__

[6:25] __+591 75138091 se unieron mediante el enlace de invitación__

[6:26] __Alguien añadió a +591 75138091__

[6:35] __+591 78707646 se unieron mediante el enlace de invitación__

[6:38] __+591 73451554 se unieron mediante el enlace de invitación__

[6:39] __+591 73497611 se unieron mediante el enlace de invitación__

[6:40] __Alguien añadió a +591 73497611__

[6:54] __+591 73497634 se unieron mediante el enlace de invitación__

[6:58] __Alguien añadió a +591 73497634__

[6:58] __+591 67378876 se unieron mediante el enlace de invitación__

[6:59] __+591 61870190 se unieron mediante el enlace de invitación__

[7:10] __+591 72978591 se unieron mediante el enlace de invitación__

[7:18] __+591 63780962 se unieron mediante el enlace de invitación__

[7:20] __+591 79265497 se unieron mediante el enlace de invitación__

[7:21] __Alguien añadió a +591 79265497__

[7:30] __+591 73456067 se unieron mediante el enlace de invitación__

[7:30] __+591 72944707 se unieron mediante el enlace de invitación__

[7:30] __Alguien añadió a +591 72944707__

[7:33] __+591 67962583 se unieron mediante el enlace de invitación__

[7:35] __Alguien añadió a +591 67962583__

[7:54] __+591 65805455 se unieron mediante el enlace de invitación__

[7:54] __Alguien añadió a +591 65805455__

[7:58] __+591 72985708 se unieron mediante el enlace de invitación__

[7:59] __Alguien añadió a +591 72985708__

[8:00] __+591 72985708 se unieron mediante el enlace de invitación__

[8:01] __+591 72985708 se unieron mediante el enlace de invitación__

[8:05] __+591 63682630 se unieron mediante el enlace de invitación__

[8:08] __+591 79278315 se unieron mediante el enlace de invitación__

[8:22] __+591 72940669 se unieron mediante el enlace de invitación__

[8:23] __Alguien añadió a +591 72940669__

[8:35] **+591 75175156:** Buenos días. 
Alguien puede indicar donde hay Gasolina/ETANOL, por favor!

[8:44] __+591 75152237 se unieron mediante el enlace de invitación__

[8:44] __+591 72981055 se unieron mediante el enlace de invitación__

[8:58] __+591 68405155 se unieron mediante el enlace de invitación__

[9:00] __+591 72975761 se unieron mediante el enlace de invitación__

[9:17] __+591 78230364 se unieron mediante el enlace de invitación__

[9:18] __+591 74529446 se unieron mediante el enlace de invitación__

[9:18] __Alguien añadió a +591 74529446__

[9:50] __+591 78250221 se unieron mediante el enlace de invitación__

[9:59] __+591 75117850 se unieron mediante el enlace de invitación__

[10:07] **+591 71866559:** Buenos días , dónde hay gasolina clarita porfavor?

[10:08] **+591 68705100:**
> _+591 75175156: Buenos días. 
Alguien puede indicar donde hay Gasolina/ETANOL, por favor!_
En el mástil

[10:08] **+591 68705100:**
> _+591 71866559: Buenos días , dónde hay gasolina clarita porfavor?_
Las Vegas y puente San Martin

[10:09] __+591 76153500 se unieron mediante el enlace de invitación__

[10:10] **+591 75175156:** Gracias

[10:18] **+591 71866559:**
> _+591 68705100: Las Vegas y puente San Martin_
Gracias

[10:19] **+591 68698136:** Gracias

[10:40] __+591 74505077 se unieron mediante el enlace de invitación__

[10:42] **+591 71866559:** Las Vegas plus, alguien sabe dónde hay especial?

[10:49] **+591 75175156:** Etanol??
Por favor

[10:50] **+591 75175156:** No hay en Daniel ni mastil

[10:51] __+591 68690369 se unieron mediante el enlace de invitación__

[11:57] __+591 64704563 se unieron mediante el enlace de invitación__

[11:58] __Alguien añadió a +591 64704563__

[12:14] __+591 64333071 se unieron mediante el enlace de invitación__

[12:36] __+591 74537707 se unieron mediante el enlace de invitación__

[13:13] __+591 78556198 se unieron mediante el enlace de invitación__

[14:10] **+591 68680221:** Buenas tardes... Disculpen alguien sabe dónde son las oficinas de la ciudadanía digital...???

[14:41] **+591 70217778:**
> _+591 68680221: Buenas tardes... Disculpen alguien sabe dónde son las oficinas de la ciudadanía digital...???_
En el tribunal departamental de justicia

[15:57] __+591 64301527 se unieron mediante el enlace de invitación__

[16:08] __+591 67392004 se unieron mediante el enlace de invitación__

[17:11] **+591 78226427:** https://vt.tiktok.com/ZS9MSf9xTpBTV-yh7wJ/

[17:30] **+591 79256927:** Por favor alguien que me pueda avisar en que surtidor están vendiendo gasolina especial o etanol??

[17:33] **+591 68698136:** Ayer habia en la tacuarandi y en el puente san martin pero hoy dudo que haya

[17:33] **+591 68698136:**
> _+591 71872723: Mañana en la estación La Terminal_
Ayer dijeron esooo

[17:34] **+591 74543937:** Sointa

[17:34] **+591 74543937:** Recién cargue

[17:34] **+591 74543937:** Vacio

[17:34] **+591 71875639:** AYER HABIA EN SAN GERONIMO

[17:37] **+591 79256927:** Muchas gracias amigos.

[18:20] **+591 68680221:** Saben si están vendiendo gasolina en Tacuarandi...??? Y saben hasta cuántos litros te venden en bidón...???

[18:48] **+591 76947163:** [Imagen]

[19:23] **+591 68289593:** Alguien save asta cuantos litros están vendiendo en vidon

[19:27] **+591 71894444:** No controlan eso

[19:42] **+591 76947163:** [Imagen]

[19:42] **+591 76947163:** Asiendo fila

[19:55] __+591 72946929 se unieron mediante el enlace de invitación__

[19:55] __Alguien añadió a +591 72946929__

---

## 9 de julio de 2026

[2:51] __+591 73451069 se unieron mediante el enlace de invitación__

[5:38] __+591 72902043 se unieron mediante el enlace de invitación__

[5:38] __Alguien añadió a +591 72902043__

[8:26] **+591 71875639:** Dnd hay gasolina

[8:26] **+591 71875639:** Clarita

[9:55] **+591 71875639:** Wen dia reporten

[9:56] **+591 75127881:** Buen día  alguien sabe donde hay gasolina etanol ?

[9:56] **+591 71872723:** Tacuarandi tendra gasolina especial toda la semana

[9:56] **+591 71872723:**
> _+591 75127881: Buen día  alguien sabe donde hay gasolina etanol ?_
En la estación de servicio de la Terminal

[9:58] **+591 75127881:**
> _+591 71872723: En la estación de servicio de la Terminal_
Gracias

[10:29] **+591 75175156:**
> _+591 71872723: En la estación de servicio de la Terminal_
Confirmado para hoy???
🙏🙏

[10:55] **+591 72984463:** _Se eliminó este mensaje_

[10:55] **+591 72984463:** _Se eliminó este mensaje_

[10:55] **+591 71872723:** Todos los miércoles trae me indico el dueño

[11:31] **+591 75119208:** Alguien sabe donde hay gasolina clarita especial por favor

[11:39] **+591 71875639:** Tacuarandi

[11:40] **+591 75119208:** Buenoo

[11:40] **+591 75119208:** Gracias

[11:49] **+591 78703080:**
> _+591 75119208: Alguien sabe donde hay gasolina clarita especial por favor_
Tacuarandi

[11:49] **+591 78703080:** Ahorita compre

[11:53] **+591 72984463:** -

[12:33] **+591 78708725:** _Se eliminó este mensaje_

[12:33] **+591 72999358:** San Gerónimo igual

[12:36] **+591 78708725:** Quién sabe si en el surtidor Las Vegas, si hay gasolina clarita

[12:48] **+591 67963233:**
> _+591 78708725: Quién sabe si en el surtidor Las Vegas, si hay gasolina clarita_
Hay pero no para vos

[13:23] **+591 72903627:** [Contacto: BEGIN:VCARD
VERSION:3.0
N:Chiki;Suco;;;
FN:Suco Chiki
item1.TEL;waid=59178225036:+591 78225036
item1.X-ABLabel:Móvil
END:VCARD]

[13:23] **+591 72903627:** Xfavor pueden agregar a este número

[13:23] **+591 72903627:** Xfavor

[14:02] **+591 74525861:** En las Vegas pueden confirmar si hay especial???

[14:02] **+591 74525861:** Por favor

[14:02] **+591 74525861:** 🙏🏻🙏🏻🙏🏻🙏🏻

[14:02] **+591 78708725:** No hay gasolina especial en Las Vegas

[14:03] **+591 78708725:** Ay en San Gerónimo acabo de cargar

[14:09] **+591 67376165:** Etanol en la surtidor de  la ex terminal

[14:55] **+591 74525861:** San geronimo queda al lado del coliseo universitario??????

[15:54] **+591 75119208:** Gasolina clarita en tacuarandi

[15:54] **+591 75119208:** Están vendiendo en bidón

[15:54] **+591 75119208:** Con fotocopia de carnet nomas

[18:08] **+591 63786945:** En la agrupa hay gasolina especial

[18:26] **+591 74537707:** Tacuarandi hay hay la especial

[18:27] **+591 72998577:** [Sticker]

---

## 10 de julio de 2026

[7:28] **+591 74543937:** Buenos días donde venderán hoy gasolina especial por favor alguien sabe

[8:18] **+591 71866559:** Alguien sabe dónde están vendiendo gasolina especial porfavor

[8:20] **+591 74543937:** [Mensaje de voz]

[8:20] **+591 74543937:** [Mensaje de voz]

[8:23] **+591 64580937:** [Mensaje de voz]

[8:24] **+591 74543937:** [Mensaje de voz]

[8:25] **+591 64580937:** [Mensaje de voz]

[8:25] **+591 71875639:** No estan pidiendo bsisa ya

[8:27] **+591 74543937:** [Mensaje de voz]

[8:28] **+591 75127881:** Buenos días  alguien sabe donde hay gasolina etanol?

[9:08] **+591 72944424:** Anoche cargué en El Portillo etanol

[9:14] **+591 72999358:**
> _+591 71875639: No estan pidiendo bsisa ya_
Algunos si piden, rara vez

[9:27] **+591 77178786:** YPFB morros blancos casi sin fila

[9:29] **+591 71866559:** Tacuarandi hay especial

[9:29] **+591 71866559:** Acabo de cargar

[9:34] **+591 75175156:** Alguien sabe donde estan vendiendo Etanol hoy???

[10:15] **+591 74525861:** Alguien debe si en moto mendez o el molle hay especial

[11:41] **+591 78707745:** Buenas alguien sabe si hay especial en moto mendez

[12:33] **+591 63809912:** Buenas tardes dónde hay gasolina

[12:34] **+591 78707745:** Moto mendez hay especial pero hay fila

[12:42] **+591 75143839:** Alguien sabe si en la ex terminal hay especial???

[12:46] **+591 75143839:** Avisen....no sean malos...

[12:53] **+591 74525861:** En molle me dijeron que hay especial pero no se la verdad alguien cargo ahí???

[13:37] **+591 71897189:** Buenas tardes dónde están vendiendo gasolina

[14:24] __+591 72961139 se unieron mediante el enlace de invitación__

[17:41] __+591 79251139 se unieron mediante el enlace de invitación__

[17:41] __+591 60263311 se unieron mediante el enlace de invitación__

[17:42] __+591 67963248 se unieron mediante el enlace de invitación__

[19:06] **+591 68698136:** No saben donde hay gasolina

[19:06] **+591 68698136:** Buenas noches

[19:07] **+591 62853115:** En el Moto mendez había

[20:59] **+591 74525861:**
> _+591 62853115: En el Moto mendez había_
Hay especial

[20:59] **+591 74525861:** ???

---

## 11 de julio de 2026

[7:42] __+591 74556784 se unieron mediante el enlace de invitación__

[7:45] **+591 74556784:** H

[7:49] **+591 74556784:** _Se eliminó este mensaje_

[7:50] **+591 74556784:** Abre este enlace para unirte a mi grupo de WhatsApp: https://chat.whatsapp.com/JwGTkmQmJtk2e2V7BHMKKy?s=sw&p=a&mlu=4&amv=2

[8:23] **+591 64333071:** Buenos días  alguien  sabe donde están bendiendo gasolina  especial?

[10:04] **+591 78230364:** Alguien sabe donde hay especial o etanol?

[10:23] **+591 75127881:**
> _+591 78230364: Alguien sabe donde hay especial o etanol?_
Sointa

[10:23] **+591 75127881:** Había ayer en la tarde

[10:25] **+591 67378876:**
> _+591 75127881: Sointa_
Sointa ! Dónde queda ese surtidor ...

[10:25] **+591 75127881:** Final circunvalación

[10:25] **+591 75127881:** Cargue etanol ahí

[10:26] **+591 68698136:**
> _+591 75127881: Cargue etanol ahí_
Recien nomas?

[10:27] **+591 75127881:** Ayer,  pero dijo que habría hasta hoy

[10:31] **+591 71875639:** Dnd hay etanol?

[10:31] **+591 72999358:** Batida en la circunvalación casi colon.

[10:33] **+591 75146448:**
> _+591 67378876: Sointa ! Dónde queda ese surtidor ..._
Gasolina especial?

[10:34] **+591 75127881:** Gasolina la plus tenían ayer

[10:34] **+591 72962359:** Don hay gasolina especial amigos

[10:34] **+591 72962359:** ?

[10:50] **+591 71197917:** Portillo va ver alas 11 la especial

[10:50] **+591 71197917:** Hay etanol igual

[11:19] **+591 72860656:** Dónde están vendiendo en bidon?

[11:19] **+591 72860656:** Y alguien que sepa los requisitos

[12:12] **+591 71198548:** Alguien sabe en qué surtidor están vendiendo gasolina especial clarita

[13:21] **+591 77175043:** Acabo de cargar en San Gerónimo clarita y sin fila

[13:32] **+591 71868154:**
> _+591 77175043: Acabo de cargar en San Gerónimo clarita y sin fila_
Gracias.....no sabe si venden en bidón?

[13:32] **+591 71868154:** Buenas tardes

[13:34] **+591 77175043:**
> _+591 71868154: Gracias.....no sabe si venden en bidón?_
Si están vendiendo en bidón

[13:34] **+591 77175043:** Normal en san Gerónimo

[13:47] **+591 78708725:** Creo que hasta el 15 se puede cargar con bidón y carnet. Después hay que estar registrados con ese digital ciudadano creo

[14:19] **+591 73497611:** Bueno

[16:46] **+591 72973019:** Buenas, saben si están cargando gasolina Clarita, en q surtidor?

[16:50] **+591 65800835:** En san geronimo cargué especial sin fila hace 45 minutos

[17:16] **+591 72973019:** 👍🏻👍🏻 Gracias

[17:17] **+591 72973019:** Ya cargue

---

## 12 de julio de 2026

[8:43] **+591 76195199:** Buenos días no saben dónde hay gasolina especial ?

[8:44] **+591 72426015:** Etnol alguien cargo..

[11:41] **+591 63795999:** Hola

[11:41] **+591 63795999:** Hola

[11:41] **+591 63795999:** Algui

[11:41] **+591 63795999:** Sabe

[11:41] **+591 63795999:** Donde

[11:41] **+591 63795999:** Estan

[11:41] **+591 63795999:** Cargando

[11:41] **+591 63795999:** Gasolina

[11:41] **+591 63795999:** Especial

[11:41] **+591 63795999:** ?

[12:02] **+591 62853115:** Moto mendez

[12:47] **+591 74505077:** Buenos tardes alguien sabe donde ay gasolina especial

[13:04] **+591 73483881:** A las 11:30 cargue en la entrada de san Gerónimo

---

## 13 de julio de 2026

[7:01] **+591 69312095:** Alguien sabe donde hay gasolina limpia?

[7:01] **+591 68686988:** En el agrupa

[7:44] **+591 74525861:** Agrupa tiene la plus

[7:46] **+591 76195199:** Alguien sabe dónde hay la especial ?

[8:09] **+591 76195199:** ?

[8:33] **+591 74505077:** _Se eliminó este mensaje_

[8:34] **+591 74505077:** El encargado del surtidor el molle dijo que ba llegar gasolina especial a partir de las 9  AM

[8:43] **+591 71875639:** Dnd hay gasolina clarita

[8:43] **+591 71875639:** Wen dia a todos

[9:49] **+591 71875639:** Confirmen

[10:54] **+591 74505077:** En el molle hay especial

[10:59] **+591 75119208:** Buenos días alguien sabe donde hay gasolina especial clarita por favor

[11:15] **+591 72945844:** Buen dia, Donde mas se puede encontrar gasolina especial

[11:23] **+591 72999358:** San Gerónimo

[11:31] **+591 71875639:** San geronimo

[11:31] **+591 71875639:** Toy haciendo fila

[11:31] **+591 76195199:**
> _+591 71875639: San geronimo_
Gasolina especial ?

[11:33] **+591 71875639:** Si hay fila

[11:33] **+591 76195199:** Mucha o que ?

[11:34] **+591 71875639:** Una cuadra

[11:40] **+591 71875639:** [Mensaje de voz]

[11:46] **+591 76837290:** Dónde hay gasolina especial?

[11:47] **+591 71875639:**
> _+591 71875639: San geronimo_
??

[12:07] **+591 75119208:** Gracias

[14:11] **+591 63780494:** No saben si hay gasolina en san Geronimo todavía

[14:11] **+591 63780494:** ??

[18:02] **+591 74543937:** Por favor gasolina especial  donde habrá

[18:08] **+591 77870087:**
> _+591 74543937: Por favor gasolina especial  donde habrá_
Don daniel acabo d cargar

[18:09] **+591 74543937:** [Sticker]

[19:17] **+591 63809912:** Buenas noches

[19:17] **+591 63809912:** Dónde puedo pillar gasolina

[19:27] **+591 72042913:** En san jorge están cargando

[20:25] **+591 71878341:** [Reenviado] https://www.facebook.com/share/p/1GTzRUS32R/

---

## 14 de julio de 2026

[8:58] **+591 67960504:** Buen dia donde ay gasolina limpia

[9:26] **+591 73483881:**
> _+591 67960504: Buen dia donde ay gasolina limpia_
X2

[10:20] **+591 71875639:**
> _+591 67960504: Buen dia donde ay gasolina limpia_
X3

[10:45] **+591 63780494:** En el portillo solo hay la plus y etanol no hay

[11:06] **+591 65800835:** Donde es X2   X3?

[11:37] **+591 65800835:** Buenos dias avisen donde hay gasolina especial

[11:45] **+591 78235592:** Dónde hay gasolina blanquita porfa

[12:09] **+591 72945325:** En el panamericano fila corta

[13:28] **+591 67677932:** Disculpen alguien sabe en qué surtidor están cargando gasolina en bidón

[13:32] **+591 71875639:**
> _+591 67677932: Disculpen alguien sabe en qué surtidor están cargando gasolina en bidón_
San geronimo

[18:43] **+591 75127881:** Buenas tardes alguien sabe donde hay gasolina etanol o especial?

[19:33] **+591 65821266:** Buenas noches, alguien sabe dónde hay etanol o la especial .??

[19:51] **+591 73451069:** Buenas alguien que sepa
Si el el Molle hay gasolina

[19:52] **+591 73451069:** O en el moto Mendez avisen porfa

[19:52] **+591 75127881:** Moto Méndez no hay

[21:51] __+591 63365964 se unieron mediante el enlace de invitación__

[23:12] **+591 60273704:** En el tacuarandi saben si hay?

---

## 15 de julio de 2026

[7:00] **+591 68702274:** Buenos dias alguien sabe  donde hay la especial xf

[11:26] **+591 71199691:** Buenos días done hay gasolina especial xf

[11:41] **+591 65811053:** Alguien sabe?

[12:02] **+591 75143839:** Avisen....donde hay la especial..
No sean malos.

[12:02] **+591 71894444:** Que a pasado qué no están avisando che?
No sean así pues

[12:04] **+591 70213268:** No quiere que lo vayamos a cargar gasolina más?

[12:05] **+591 63795999:**
> _+591 70213268: No quiere que lo vayamos a cargar gasolina más?_
[Sticker]

[12:06] **+591 63798372:** Buenas tardes.. San Geronimo están cargando gasolina especial

[12:09] **+591 68702274:** N l sertidor las americas tan descargando la sisterna de una media hora ba empesar a cargar no hay fila todavia

[12:12] **+591 68702274:** Es gasolina espesial

[12:13] **+591 75143839:**
> _+591 68702274: N l sertidor las americas tan descargando la sisterna de una media hora ba empesar a cargar no hay fila todavia_
Donde es?

[12:13] **+591 68702274:** Si

[12:14] **+591 68702274:** En la pasrela mas arriba

[12:26] **+591 68702274:** N l campesino

[12:36] **+591 75127881:** Buenas tardes

[12:36] **+591 75127881:** Alguien sabe donde hay gasolina etanol?

[12:58] **+591 62858652:** Alguien sabe dónde hay gasolina blanquita?

[16:49] **+591 71602101:** Buenas stardes disculpen alguien sabe donde hay gasolina especial? San jerónimo ya no tiene

[17:06] **+591 68697122:** Buenas tardes alguien sabe dónde hay etanol

[17:21] **+591 76195276:** [Imagen]

[21:38] **+591 75116516:** Buenas noches 
Alguien me puede decir dónde hay gasolina especial

[21:39] **+591 75116516:** Ó dónde hay gasolina blanquita por favor

[23:31] **+591 67995662:** Hola buenas noches

[23:34] **+591 67995662:** A todos soy el adm

[23:35] **+591 67995662:** Disculpen

[23:35] **+591 67995662:** Dónde puedo conseguir especial

[23:36] **+591 67995662:** ⛽🏍️

[23:37] **+591 67995662:** 🙄

---

## 16 de julio de 2026

[2:33] **+591 73495449:** _Se eliminó este mensaje_

[7:24] **+591 71866559:** Buen día alguien sabe dónde hay gasolina clarita?

[7:54] **+591 71875639:**
> _+591 71866559: Buen día alguien sabe dónde hay gasolina clarita?_
X2

[8:17] **+591 75140604:** Nadie quiere avisar

[8:18] **+591 75140604:** _Se eliminó este mensaje_

[8:39] **+591 73140648:** Nadie sabe ?

[8:40] **+591 71894444:** Aun no debe estar descargando
Ayer decían en Villanueva que había especial y en el campesino ypfb

[9:03] **+591 78235592:** Buen día sabes dónde hay gasolina blanca?

[9:36] **+591 68697122:** Alguien sabe dónde hay etanol

[9:39] **+591 73140648:** Llego gasolina especial al
Surtidor san Jorge

[10:43] **+591 79256927:** Buenos días a todos, por favor alguien q me informe de q surtidor consigo gasolina especial o etanol.

[10:44] **+591 75127881:** Alguien sabe donde hay gasolina etanol por favor 🙏😭😩

[10:44] **+591 75143839:**
> _+591 73140648: Llego gasolina especial al
Surtidor san Jorge_
👆👆👆

[12:29] **+591 79252300:** Gasolina especial 
Surtidor las Américas del campesino 
Acabo de cargar ahi

[13:05] **+591 79256927:** _Se eliminó este mensaje_

[13:06] **+591 79256927:** Etanol en la ex terminal recién cargue

[15:16] **+591 75127881:** Alguien sabe si sigue habiendo  gasolina etanol en el surtidor  de la ex terminal?

[16:16] **+591 62858652:** Alguien que sepa dónde hay gasolina blanca????

[16:16] **+591 71875639:** Taba x descargar en san jeronimo alas 10

[16:17] **+591 62858652:** A estás horas será que hay?

[16:17] **+591 71875639:** Si alas 10 tdavia no llegaba la cisterna

[16:17] **+591 68686988:** En las vegas hay la plus

[16:17] **+591 68686988:** Sin fila

[16:22] **+591 75131234:**
> _+591 62858652: Alguien que sepa dónde hay gasolina blanca????_
Surtidor don Daniel

[16:22] **+591 74544944:** Etanol en sointa

[16:23] **+591 62858652:**
> _+591 75131234: Surtidor don Daniel_
Listo ahorita voy gracias

[16:23] **+591 72996643:**
> _+591 75131234: Surtidor don Daniel_
Diju

[16:26] **+591 68717611:**
> _+591 62858652: Listo ahorita voy gracias_
Puedo confirmar por

[16:26] **+591 68717611:** Favor

[16:30] **+591 62858652:**
> _+591 68717611: Puedo confirmar por_
En 10mnt llegó y le aviso

[16:36] **+591 68717611:** Gracias

[16:38] **+591 62858652:**
> _+591 68717611: Puedo confirmar por_
Ya no hay me comentan

[17:02] **+591 74549616:** Buenas disculpen algún electricista?

---

## 17 de julio de 2026

[8:09] **+591 72973019:** Buen día donde hay gasolina buena

[8:12] **+591 63780494:** En las vegas y tacuarandi solo hay la plus... Ojooo

[8:17] **+591 71894444:** Gracias.

[8:36] **+591 73483881:** En el Tarija está amarillo café 🥴

[10:09] **+591 73453408:** Ay etanol en el surtidor ay Serca de la entrada de aeropuerto donde acaba la circunvalación

[10:39] **+591 75119208:** Alguien sabe donde hay gasolina especial

[10:39] **+591 75119208:** Por favor

[10:39] **+591 75119208:** Me pasa el dato

[10:47] **+591 63682630:**
> _+591 75119208: Alguien sabe donde hay gasolina especial_
En belen tres cruces

[11:41] **+591 69329302:**
> _+591 75119208: Alguien sabe donde hay gasolina especial_
?

[13:19] **+591 67376165:** Hay Etanol donde don Daniel

[13:23] **+591 75119208:** Alguien sabe como esta la gasolina en el surtidor del campesino

[13:23] **+591 75119208:** Puede informar por favor

[14:33] **+591 75119208:** Gasolina especial surtidor del campesino

[14:33] **+591 75119208:** [Imagen]

[15:10] **+591 73483881:**
> _+591 75119208: Imagen_
Que yo sepa siempre ponen gasolina especial en la factura 🤔

[15:13] **+591 60252925:** Hay gasolina especial y gasolina especial plus o especial +

[17:20] **+591 76947163:** [Imagen] Potrito de 4 meses a la venta

[19:36] **+591 67384303:**
> _+591 76947163: Imagen: Potrito de 4 meses a la venta_
Precio

[20:02] **+591 76947163:** 2000

[20:06] **+591 72973019:**
> _+591 76947163: Imagen: Potrito de 4 meses a la venta_
Precio

[20:06] **+591 72973019:** Sigue disponible

[20:07] **+591 76947163:**
> _+591 72973019: Sigue disponible_
Sii

[20:08] **+591 76947163:**
> _+591 76947163: 2000_
👆

---

## 18 de julio de 2026

[5:57] **+591 78702088:** https://www.facebook.com/reel/1057824377242556?sfnsn=wa&mibextid=6AJuK9

[8:53] **+591 72974985:** [Mensaje de voz]

[8:53] **+591 71875639:** ,?

[8:54] **+591 63780494:** En las vegas solo hay la plus ojoooo

[8:54] **+591 63780494:**
> _+591 72974985: Mensaje de voz_
[Sticker]

[9:04] **+591 69312879:** Buen dia

[9:05] **+591 69312879:** Alguien sabe donde hay gasolina clarita en qe surtidor

[11:14] **+591 74556784:** [Reenviado] https://chat.whatsapp.com/JwGTkmQmJtk2e2V7BHMKKy?s=sw&p=a&ilr=1&amv=2

[11:20] **+591 72426015:** Daniel

[13:09] **+591 77172588:** _Se eliminó este mensaje_

[13:09] **+591 77172588:** _Se eliminó este mensaje_

[13:09] **+591 77172588:** _Se eliminó este mensaje_

[13:09] **+591 77172588:** _Se eliminó este mensaje_

[13:10] **+591 74504811:** Ufff

[13:10] **+591 74504811:** El 119 me parece que es

[13:11] **+591 71190409:** Pobres bomberos como fueran lo qe ellos asen y tienen qe ir a es poner su vida

[13:12] **+591 74537707:** Y no tienen sueldos son voluntarios

[13:12] **+591 74537707:** Son algunos que si perciben pero la mayoría no

[13:12] **+591 71190409:** Es una pena

[13:39] **+591 78703080:**
> _+591 74537707: Y no tienen sueldos son voluntarios_
Eso no  son renumerdos

[15:40] **+591 75146448:** Hola buenas tardes

[15:40] **+591 75146448:** Alguien sabe donde hay gasolina

[15:45] **+591 72981853:** Surtidor del molle y moto mendez

[22:41] **+591 76181373:** Buenas noches disculpen alguien sabe dond hay gasolina a esta hora

---

## 19 de julio de 2026

[0:38] **+591 74556784:** [Reenviado] https://chat.whatsapp.com/JwGTkmQmJtk2e2V7BHMKKy?s=sh&p=a&ilr=1&amv=2

[6:44] **+591 72945844:** https://www.facebook.com/share/v/19KpjKgpX7/

[9:02] **+591 72693210:** Buenos días

[9:03] **+591 72693210:** Alguien sabe dónde hay gasolina especial o estanol?

[9:18] **+591 71862952:** Buenoa dias alguien podria agregar este numero al grupo porfavor

[9:18] **+591 71862952:** 72998730

[13:15] **+591 74537707:** Abre este enlace para unirte a mi grupo de WhatsApp: https://chat.whatsapp.com/D1imlgo3Icb4UsZgFoGZP5?s=sw&p=a&ilr=4

[13:30] **+591 72999358:** https://chat.whatsapp.com/Dq2gGfeiSAs19cjmoAAKBp

[14:45] **+591 73495449:** _Se eliminó este mensaje_

[15:05] **+591 73495449:** _Se eliminó este mensaje_

---

## 20 de julio de 2026

[2:14] **+591 73495449:** _Se eliminó este mensaje_

[9:37] **+591 72975873:** [Reenviado] https://chat.whatsapp.com/Dq2gGfeiSAs19cjmoAAKBp?s=cl&p=a&ilr=4&amv=3

[9:37] **+591 72975873:** Para los que deseen unirse al grupo y colaborar con. Algo

[9:46] **+591 74670785:** [Mensaje de voz]

[10:46] **+591 69327934:** Etanol

[10:46] **+591 69327934:** Donde hay

[10:46] **+591 69327934:** Alguien sabe

[10:48] **+591 75119208:** Alguien sabe donde hay gasolina especial

[10:48] **+591 75119208:** Por favor

[11:09] **+591 79251139:** [Contacto: BEGIN:VCARD
VERSION:3.0
N:;Ovandito😎💪🏻;;;
FN:Ovandito😎💪🏻
item1.TEL;waid=59163784602:+591 63784602
item1.X-ABLabel:Celular
END:VCARD]

[11:09] **+591 79251139:** Buen día Pueden agregar a este número por favor

[13:02] **+591 70227368:** buen dia alguien sabe donde estan vendiendo gasolina especial

[13:07] **+591 73483881:** San Martin está la plus 💩

[20:03] **+591 73495449:** _Se eliminó este mensaje_

---

## 21 de julio de 2026

[7:54] **+591 71875639:** Wen dia dnd hay gasolina esepcial

[8:42] **+591 71894444:** [Reenviado] Estaciones de Servicio con Gasolina Especial
Moto Mendez
Agrupa
Tarija
Tacuarandi
Portillo
Presidente A. Arce
Las Americas

[8:42] **+591 71894444:** [Reenviado] Para esta semana.

[8:42] **+591 71894444:** Esto enviaron al otro grupo.

[9:15] **+591 69327934:** Etanol

[9:15] **+591 69327934:** En qué gasolinería

[9:17] **+591 72973135:** [Imagen]

[9:22] **+591 68731773:** _Se eliminó este mensaje_

[9:40] **+591 75128182:**
> _+591 69327934: En qué gasolinería_
X2

[9:51] **+591 62858652:** Buenos días alguien sabe dónde hay gasolina blanca?

[10:14] **+591 68698136:**
> _+591 71894444: Estaciones de Servicio con Gasolina Especial
Moto Mendez
Agrupa
Tarija
Tacuarandi
Portillo
Presidente A. Arce
Las Americas_
?????

[10:15] **+591 68698136:**
> _+591 62858652: Buenos días alguien sabe dónde hay gasolina blanca?_
Ahi dijeron pero lean los sms

[10:15] **+591 78230012:** [Mensaje de voz]

[10:20] **+591 68695886:** [Reenviado] [Imagen]

[10:20] **+591 68695886:** [Reenviado] ​🚨 COMUNICADO URGENTE - APOYO EN EL INCENDIO EN TARIJA 🚨
​Estimado equipo de voluntarios,
​Como es de conocimiento de todos, se está registrando un incendio en diferentes zonas de nuestra ciudad. Nuestros bomberos y equipos de rescate están trabajando arduamente para sofocar las llamas y necesitan de nuestro apoyo urgente.
​Estaré pasando por sus casas o puntos de encuentro para recolectar cualquier insumo que puedan aportar. Toda ayuda cuenta.
​¿Qué podemos recolectar?
​💧 Hidratación: Agua embotellada, rehidratantes, sueros o bebidas con electrolitos.
​🍎 Alimentos: Enlatados, barras energéticas, chocolates, frutos secos y alimentos no perecederos.
​🩹 Insumos de primeros auxilios: Gotas/colirio para los ojos, gasas, crema para quemaduras, vendas, barbijo/mascarilla.
​🧤 Equipo de protección: Guantes de cuero o de trabajo, linternas, pilas.
​Por favor, confirmen por este medio si tienen donaciones listas y su dirección/ubicación para coordinar el recojo lo antes posible.
​¡Unidos podemos hacer la diferencia! Muchas gracias por su solidaridad y compromiso.
UNIDOS COMO UNI POR EL BIEN DE TODOS

[10:35] **+591 78230364:** Alguien sabe donde hay etanol?

[10:35] **+591 78230364:** O especial?

[12:10] **+591 72955920:** [Reenviado] [Imagen] Compartan

[12:11] **+591 71875639:**
> _+591 72955920: Imagen: Compartan_
No es richar rocha

[12:13] **+591 72955920:** ???..eso compartieron en otro grupo..

[12:30] **+591 71866332:** Pe se q era matute

[12:55] **+591 67995662:** Abre este enlace para unirte a mi grupo de WhatsApp: https://chat.whatsapp.com/GwRFIJpLplK2vhX9FeDfD1?s=sw&p=a&ilr=4&amv=0

[13:55] **+591 78434896:** [Reenviado] [Sticker]

[13:55] **+591 78434896:** Ji uuuuuu de la ujbj by de HB hy JJ bb bgvc de

[14:53] **+591 73495449:** _Se eliminó este mensaje_

[15:45] **+591 73495449:** _Se eliminó este mensaje_

[18:15] **+591 67995662:** Abre este enlace para unirte a mi grupo de WhatsApp: https://chat.whatsapp.com/GwRFIJpLplK2vhX9FeDfD1?s=sw&p=a&ilr=4&amv=0

[19:28] **+591 75119208:** [Reenviado] https://chat.whatsapp.com/GejNnH4TEA9LlIK7Uzph4S?s=cl&p=i&ilr=4&amv=0

[20:08] **+591 73495449:** _Se eliminó este mensaje_

[20:13] **+591 72693210:**
> _+591 73495449: Sexo grupos WhatsApp amigas o primas_
[Sticker]

[20:14] **+591 60251131:** Saquen a ese enfermo del grupo

[20:15] **+591 72990143:** [Sticker]

[20:28] **+591 73495449:** Manda el sexo gratis grupos WhatsApp

[20:32] **+591 72998577:**
> _+591 60251131: Saquen a ese enfermo del grupo_
[Sticker]

[20:32] **+591 72998577:** Pasen grupos de batidas

---

## 22 de julio de 2026

[8:19] **+591 74534560:** Buenos días por favor alguien sabe donde ay gasolina especial

[8:19] **+591 74534560:** Por favor gracias

[8:21] **+591 67378876:** Buen día, pasen el dato! Dónde pillo gasolina especial!

[8:54] **+591 73483881:**
> _+591 71894444: Estaciones de Servicio con Gasolina Especial
Moto Mendez
Agrupa
Tarija
Tacuarandi
Portillo
Presidente A. Arce
Las Americas_
Ya fueron está semana ? Confirmaron ? Porque yo fui el lunes al Tarija y era té 🧋

[8:55] **+591 74525861:** Buen dia amigos de este grupo

[8:55] **+591 74525861:** Y con el permiso del administrador

[8:58] **+591 74525861:** Creo que de un tiempo hasta hacemos muchos que no participamos las razones pueden ser varias. Pero a lo que me voy es que si alguien pide información y aunke alguien sepa donde hay gasolina especial no lo dice. No nos cuesta mucho mandar un mensajito un audio informando donde podemos conseguir buena gasolina espero no se molesten pero es una opinión tratemos de ser solidarios en este tema

[8:59] **+591 74525861:** Por mi parte en cuanto tenga alguna información se los haré saber

[9:59] **+591 71894444:** Así es, el grupo es para compartir y no solo exigir o molestarse.

Seamos más empaticos.

[10:00] **+591 71894444:** [Reenviado] Acabo de cargar en el surtidor Tarija el que está en la domingo sabio la especial

[10:42] **+591 76945645:** Ya no hay etanol en la ex terminal

[10:42] **+591 76945645:** Ni en Sointa

[10:42] **+591 76945645:** AS si hay en otra parte

[10:42] **+591 76945645:** ?

[11:27] **+591 67378876:**
> _+591 71894444: Acabo de cargar en el surtidor Tarija el que está en la domingo sabio la especial_
Confirmado!! Habrá todo el día me dijeron acabo de cargar ahí!!

[12:03] **+591 68698136:**
> _+591 67378876: Confirmado!! Habrá todo el día me dijeron acabo de cargar ahí!!_
No saben si estan cargando en bidón

[12:03] **+591 68698136:** ?

[12:14] **+591 68702274:** Si lo q uno quiera

[12:14] **+591 68702274:** Resien cargue yo

[12:52] **+591 67378876:**
> _+591 68698136: ?_
Si, normal!

[13:11] **+591 72973019:** Buenas favor agregar a este número porfa

[13:11] **+591 72973019:** [2 contactos]

[13:11] **+591 72973019:** Gracias

[13:29] **+591 68698136:**
> _+591 68702274: Si lo q uno quiera_
Muchas gracias

[14:10] **+591 74525861:** Alguien cargo en las vegas?????

[14:37] **+591 73483881:**
> _+591 74525861: Alguien cargo en las vegas?????_
Nop

[18:45] **+591 67995662:** [Reenviado] [Imagen] Buenas tardes. 
Se coordinó con el señor Alberto una visita a su domicilio para el día de mañana a las 4:00 p. m., con el fin de brindar atención y ayuda, para realizar el seguimiento correspondiente debido a la afectación que sufrió su vivienda a causa del incendio ocurrido ubicado en la Victoria.

Les comparto el link del grupo para quienes estén interesados en ayudar y quieran compartir con sus familiares. 

https://chat.whatsapp.com/GKMyqJSroRw6q2aFPpQbtR?mode=gi_t

[21:29] **+591 74537707:** https://vt.tiktok.com/ZS9rarPX4XCkn-uItdP/

---

## 23 de julio de 2026

[6:39] **+591 76822959:** _Se eliminó este mensaje_

[8:43] **+591 71872723:** Buen día, en que estación de servicio estan vendiendo buena gasolina  ⛽️ ???????

[8:44] **+591 72964737:** en el campesino hay la clarita.

[8:44] **+591 74525861:** Muchas gracias

[8:44] **+591 74525861:** Buen dia

[8:45] **+591 72964737:** ok

[8:49] **+591 71872723:** Muchas gracias

[9:02] **+591 72973019:** Buendia pasen enlace del grupo

[9:04] **+591 67376165:** [Reenviado] Abre este enlace para unirte a mi grupo de WhatsApp: https://chat.whatsapp.com/Kaaw4UZwAcNAuM3RQUFpEv

[9:18] __+591 68749557 se unieron mediante el enlace de invitación__

[9:18] __Alguien añadió a +591 68749557__

[9:40] __+591 60270063 se unieron mediante el enlace de invitación__

[11:02] __+591 71166519 se unieron mediante el enlace de invitación__

[11:02] __Alguien añadió a +591 71166519__

[11:22] **+591 75117850:** Buenas! Etanol saben si hay en la Ex terminal?

O otro surtidor que tenga?

[11:40] **+591 73483881:**
> _+591 71872723: Buen día, en que estación de servicio estan vendiendo buena gasolina  ⛽️ ???????_
Me dijeron Tarija en otro grupo

[14:19] **+591 71872723:** Graciasssssss

[14:38] **+591 65821266:** Alguien vende diesel.??

[14:39] **+591 63786945:** El la agrupa gasolina blanquita

[14:42] __+591 72967111 se unieron mediante el enlace de invitación__

[15:49] **+591 61862568:** [Mensaje de album]

[15:49] **+591 61862568:** [Imagen]

[15:49] **+591 61862568:** [Imagen]

[15:49] **+591 61862568:** [Imagen]

[15:49] **+591 61862568:** [Imagen]

[15:51] **+591 61862568:** [Mensaje de album]

[15:51] **+591 61862568:** [Imagen]

[15:51] **+591 61862568:** [Imagen]

[15:51] **+591 61862568:** [Imagen]

[15:55] **+591 61862568:**
> _+591 61862568: [album]_
Y este otro más pequeño a 110 bs de 46 piezas estuche color rojo

[15:56] **+591 61862568:**
> _+591 61862568: [album]_
Juego de llaves de 53 piezas a la venta a tan solo 160 bs marca New tols... estuche color naranja

[15:57] **+591 61862568:** Información imbox

[17:32] **+591 75127881:** Buenas tardes  alguien sabe donde hay gasolina etanol?

[18:01] __+591 69331405 se unieron mediante el enlace de invitación__

[21:03] __+591 73897953 se unieron mediante el enlace de invitación__

---

## 24 de julio de 2026

[9:41] **+591 63780494:** En el portillo hay gasolina especial por si acaso

[9:41] **+591 71875639:** Gracias

[9:41] **+591 71875639:** Otro surtidor cerca

[9:42] **+591 75127881:** Etanol alguien sabe donde hay?

[9:48] **+591 63780494:** Me acaban de avisar que en las vegas hay especial

[9:49] **+591 63780494:** [Reenviado] Surtidor presidente arce

[9:49] **+591 63780494:** [Reenviado] Las vegas

[9:49] **+591 71875639:** Gracias hno dios te bendiga

[10:57] **+591 71875639:** Gasolina blanca vegas

[12:34] **+591 74525861:** Amigos comprobado gasolina especial en las vegas

[12:39] **+591 76837290:** Positivo, no hay nadie, carguen a full, después no habrá

[12:43] **+591 72974985:** Gasolina blanquita en el agrupa acabo de cargar

[12:44] **+591 65821266:**
> _+591 76837290: Positivo, no hay nadie, carguen a full, después no habrá_
Por qué no

[12:49] **+591 71875639:** [Mensaje de voz]

[13:26] __+591 60256352 se unieron mediante el enlace de invitación__

[13:27] **+591 60256352:** Buenas tardes dónde están vendiendo gasolina especial por favor

[13:32] **+591 71875639:**
> _+591 71875639: Gasolina blanca vegas_
??

[13:32] **+591 60256352:** Ok

[13:37] **+591 60256352:** Gracias

[16:20] __+591 76194043 se unieron mediante el enlace de invitación__

[16:20] __+591 74553068 se unieron mediante el enlace de invitación__

[16:20] __+591 60251309 se unieron mediante el enlace de invitación__

[16:21] __+591 67651990 se unieron mediante el enlace de invitación__

[16:21] __Alguien añadió a +591 76194043__

[16:21] __+591 64588188 se unieron mediante el enlace de invitación__

[16:21] __+591 74954905 se unieron mediante el enlace de invitación__

[16:21] __+591 73453128 se unieron mediante el enlace de invitación__

[16:21] __+591 62630610 se unieron mediante el enlace de invitación__

[16:21] __+591 69694946 se unieron mediante el enlace de invitación__

[16:22] __+591 67698582 se unieron mediante el enlace de invitación__

[16:22] __+591 74233949 se unieron mediante el enlace de invitación__

[16:22] __+591 71873983 se unieron mediante el enlace de invitación__

[16:26] __+591 75131173 se unieron mediante el enlace de invitación__

[16:26] __+591 75117885 se unieron mediante el enlace de invitación__

[16:26] __+591 72949929 se unieron mediante el enlace de invitación__

[16:26] __+591 75118116 se unieron mediante el enlace de invitación__

[16:27] __+591 65808736 se unieron mediante el enlace de invitación__

[16:27] __+591 67184573 se unieron mediante el enlace de invitación__

[16:27] __+591 63718659 se unieron mediante el enlace de invitación__

[16:27] __+591 64318534 se unieron mediante el enlace de invitación__

[16:27] __+591 63791971 se unieron mediante el enlace de invitación__

[16:28] __+591 67995662 añadió a +54 9 3886 41-3903__

[16:28] __+591 72950929 se unieron mediante el enlace de invitación__

[16:28] __+591 79250114 se unieron mediante el enlace de invitación__

[16:31] __+591 67995662 añadió a +591 72960822__

[16:37] __+591 67374158 se unieron mediante el enlace de invitación__

[16:37] __+591 67743312 se unieron mediante el enlace de invitación__

[16:39] __+591 75186906 se unieron mediante el enlace de invitación__

[16:47] __+591 71866488 se unieron mediante el enlace de invitación__

[16:50] __+591 69303808 se unieron mediante el enlace de invitación__

[16:52] __+591 63504498 se unieron mediante el enlace de invitación__

[16:52] __+591 76803106 se unieron mediante el enlace de invitación__

[16:53] __+591 68700198 se unieron mediante el enlace de invitación__

[16:58] __+591 77877825 se unieron mediante el enlace de invitación__

[17:00] __+591 63794699 se unieron mediante el enlace de invitación__

[17:00] __+591 72867582 se unieron mediante el enlace de invitación__

[17:02] __+591 75132621 se unieron mediante el enlace de invitación__

[17:05] __+591 73485727 se unieron mediante el enlace de invitación__

[17:08] __Alguien añadió a +591 73485727__

[18:00] __+591 68699801 se unieron mediante el enlace de invitación__

[18:01] __+591 71872024 se unieron mediante el enlace de invitación__

[18:14] __+591 67385845 se unieron mediante el enlace de invitación__

[18:31] __+591 68743602 se unieron mediante el enlace de invitación__

[18:31] __Alguien añadió a +591 68743602__

[18:38] __+591 68746056 se unieron mediante el enlace de invitación__

[18:40] __+591 75118556 se unieron mediante el enlace de invitación__

[18:49] __+591 72951337 se unieron mediante el enlace de invitación__

[18:57] __+591 63786023 se unieron mediante el enlace de invitación__

[19:22] __+591 73451735 se unieron mediante el enlace de invitación__

[19:44] **+591 72426015:** Donde hay gasolina

[19:44] **+591 72426015:** Wena

[20:06] __+591 74418754 se unieron mediante el enlace de invitación__

[20:56] __+591 73875036 se unieron mediante el enlace de invitación__

[21:14] __+591 64584464 se unieron mediante el enlace de invitación__

[22:02] __+591 72983385 se unieron mediante el enlace de invitación__

[22:15] **+591 72762728:**
> _+591 72426015: Donde hay gasolina_
Acabo de cargar tacuarandi

[23:09] __+591 72959886 se unieron mediante el enlace de invitación__

---

## 25 de julio de 2026

[0:37] __+591 74510016 se unieron mediante el enlace de invitación__

[4:41] __+591 76547557 se unieron mediante el enlace de invitación__

[4:42] __Alguien añadió a +591 76547557__

[6:14] __+591 64309230 se unieron mediante el enlace de invitación__

[6:15] __Alguien añadió a +591 64309230__

[7:30] **+591 75515740:** Buen día

[7:31] **+591 75515740:** Alguien sabe donde están vendiendo gasolina clarita ? Especial

[7:31] **+591 75515740:** Por favor  me avisa 
Gracias

[7:34] __+591 77178401 se unieron mediante el enlace de invitación__

[7:35] __Alguien añadió a +591 77178401__

[7:49] **+591 71872723:** En la estación de servicio Tacuarandi

[7:50] **+591 75515740:**
> _+591 71872723: En la estación de servicio Tacuarandi_
Muchas gracias

[7:56] **+591 68616631:** surtidor Tarija gasolina especial

[8:39] **+591 71198548:** Buenos días

[8:39] **+591 71198548:** Alguien cargo gasolina clarita oidia

[8:54] **+591 72960822:** Buen día , surtidor tacuarandi gasolina especial

[8:59] **+591 71198548:** Gracias

[9:30] **+591 75515740:** Gasolina Especial 
Surtidor Tacuarandi 
No hay fila

[9:41] **+591 73483881:**
> _+591 68616631: surtidor Tarija gasolina especial_
👍🏻

[9:42] **+591 74543937:** [Mensaje de voz]

[9:42] **+591 74543937:** [Sticker]

[10:03] **+591 75117885:** 🤭

[10:28] **+591 71875639:** Agrupa

[10:28] **+54 9 3886 41-3903:** [Mensaje de voz]

[10:40] **+591 63780962:** [Imagen]

[10:48] **+54 9 3886 41-3903:** [Mensaje de voz]

[10:49] **+591 71875639:**
> _+54 9 3886 41-3903: Mensaje de voz_
Agrupa

[10:49] **+54 9 3886 41-3903:** [Mensaje de voz]

[12:01] **+54 9 3886 41-3903:** En sointa ayy gasolina fila cortita

[12:02] **+54 9 3886 41-3903:** Diesel igual

[12:44] __+591 62854311 se unieron mediante el enlace de invitación__

[12:48] __+591 64343987 se unieron mediante el enlace de invitación__

[12:49] __Alguien añadió a +591 64343987__

[12:59] __+591 64116749 se unieron mediante el enlace de invitación__

[13:06] **+591 61862568:** Alguien sabe donde están vendiendo gasolina clarita....???

[13:06] **+591 71875639:**
> _+591 61862568: Alguien sabe donde están vendiendo gasolina clarita....???_
Agrupa tacuarandi

[13:28] __+591 68693801 se unieron mediante el enlace de invitación__

[13:28] __Alguien añadió a +591 68693801__

[13:30] __+591 67695743 se unieron mediante el enlace de invitación__

[13:37] __+591 76099442 se unieron mediante el enlace de invitación__

[13:39] __+591 67389348 se unieron mediante el enlace de invitación__

[13:50] **+591 69327934:** En qué parte hay etanol ?

[17:45] __+591 74516677 se unieron mediante el enlace de invitación__

[17:46] __Alguien añadió a +591 74516677__

[18:50] **+591 75132500:** [Video]

[21:10] **+591 79251139:** Buenas noches señores disculpen alguien sabe dónde hay gasolina clarita

[21:10] **+591 79251139:** ??

[21:11] **+591 72963325:** Esta tarde había en el tacuarandi

[21:11] **+591 72963325:** Hasta las 6 que cargue había aún

[21:12] **+591 79251139:**
> _+591 72963325: Esta tarde había en el tacuarandi_
Dónde queda tacuarandi disculpe

[21:12] **+591 79251139:** ??

[21:12] **+591 72963325:** Antes de ypfb

[21:12] **+591 72963325:** De morros blancos

[21:13] **+591 79251139:** Bueno muchas gracias

[23:58] __+591 76812703 se unieron mediante el enlace de invitación__

---

## 26 de julio de 2026

[8:03] **+591 75127881:** Buenos días alguien sabe donde hay gasolina etanol?

[14:43] **+591 69327934:** Si alguien sabe en qué parte hay etanol

[17:38] **+591 61862568:** Y este otro más pequeño a 110 bs de 46 piezas estuche color rojo

[17:38] **+591 61862568:** [Mensaje de album]

[17:38] **+591 61862568:** [Mensaje de album]

[17:38] **+591 61862568:** Juego de llaves de 53 piezas a la venta a tan solo 160 bs marca New tols... estuche color naranja

[17:38] **+591 61862568:** Información imbox

[17:38] **+591 61862568:** [Imagen]

[17:38] **+591 61862568:** [Imagen]

[17:38] **+591 61862568:** [Imagen]

[17:38] **+591 61862568:** [Imagen]

[17:38] **+591 61862568:** [Imagen]

[17:38] **+591 61862568:** [Imagen]

[17:38] **+591 61862568:** [Imagen]

[18:26] __+591 60274873 se unieron mediante el enlace de invitación__

[18:26] __Alguien añadió a +591 60274873__

[19:11] __+591 63773712 se unieron mediante el enlace de invitación__

---

## 27 de julio de 2026

[9:53] **+591 76836904:** Alguien sabe si llego etanol a la ex terminal

[11:15] **+591 72963325:** Buenos dias alguien sabe si estan vendiendo gasolina clarita ??

[11:36] **+591 74534560:** [Mensaje de voz]

[14:19] **+591 72999358:** Alguien sabe en qué Surtidor hay gasolina especial.

Y que vendan en bidón solamente con fotocopia de carnet?

[14:19] **+591 71875639:** Sointa

[14:19] **+591 71875639:** .

[14:22] **+591 75127881:** Alguien sabe donde hay gasolina etanol?

[14:41] **+591 79256927:** [Imagen] Etanol dónde don Daniel recién cargue

[14:42] **+591 75143839:** [Imagen]

[14:42] **+591 68698136:** [Reenviado muchas veces] EESSGasolina Especial
Para esta semana
Molle
Don Daniel
Sointa
Panamericano
San  jorge
Presidente Arce
Las Americas

[14:42] **+591 75143839:** [Imagen] Aqui hay especial, pero hay fila

[14:43] **+591 78709493:**
> _+591 68698136: EESSGasolina Especial
Para esta semana
Molle
Don Daniel
Sointa
Panamericano
San  jorge
Presidente Arce
Las Americas_
San Jorge y Panamericano no hay especial solo PLUS

[14:44] **+591 68698136:**
> _+591 78709493: San Jorge y Panamericano no hay especial solo PLUS_
Mandaron eso en otro grupo

[14:49] **+591 75127881:**
> _+591 79256927: Imagen: Etanol dónde don Daniel recién cargue_
Gracias

[15:07] **+591 73483881:** Don Daniel sin fila hay gaso y etanol

[15:11] **+591 63780494:** Portillo dijeron que hay la especial esta mañana a medio día lo metí a full al final me dice se acabó la especial esta es la plus

[15:11] **+591 63780494:** [Sticker]

[15:12] **+591 76945645:** [Sticker]

[15:47] **+591 68686988:** _Se eliminó este mensaje_

[16:46] **+591 71866332:** Buenas tardes donde hay gasolina especial en estos momentos gracias

[17:06] **+591 76836092:**
> _+591 71866332: Buenas tardes donde hay gasolina especial en estos momentos gracias_
Surtidor el molle rancho

[18:48] **+591 71866332:** Gracias

---

## 28 de julio de 2026

[6:04] **+591 72949826:** Buen día

[6:04] **+591 72949826:** Gasolina especial en q surtidor hay

[7:18] **+591 72978591:** Buen día

[7:22] **+591 72978591:** Alguien  sabe que días hay gasolina especial en surtidor el molle y surtidor moto mandez??

[9:49] **+591 72963020:** ?

[9:49] **+591 67960504:** Buen dia donde ay gasolina limpia

[10:11] **+591 73483881:**
> _+591 68698136: EESSGasolina Especial
Para esta semana
Molle
Don Daniel
Sointa
Panamericano
San  jorge
Presidente Arce
Las Americas_
.

[17:39] **+591 71875639:** Wenas alguien cargo gasolina especial

[18:14] __+591 68735171 se unieron mediante el enlace de invitación__

[18:15] **+591 68735171:** Buenas tardes alguien sabe dónde hay etanol?

---

## 29 de julio de 2026

[8:10] **+591 64321893:** Buen día alguien q sepa donde ay gasolina especial

[8:17] **+591 67378876:** Pasen el dato por favor!

[8:34] **+591 64321893:** .

[8:36] **+591 71875639:** Wen dia donde hay gasolina clarita

[8:38] **+591 64318534:** Buenos dias

[8:38] **+591 64318534:** Anoche cargue de don daniel dijeron que era la especial

[8:47] **+591 71875639:** Alguien cargo en otro lugar

[9:01] **+591 71875639:** Pase en dato cumpas

[9:22] **+591 71894444:** Saben si están vendiendo ya donde Don Daniel?

[9:37] **+591 71894444:** Donde Don Daniel habrá la especial pero la cisterna llega al medio día
Acabo de pasar

[9:38] **+591 72998577:** [Sticker]

[9:40] **+591 71875639:** Ire al panamericano a preguntar

[9:43] **+591 75127881:** Alguien sabe donde hay etanol?

[9:46] **+591 71894444:** En el agrupa hay la plus

En ypfb campesino están solo 4 autos en fila por q están actualizando sistema, pero hay gasolina de la especial

[10:31] **+591 61862568:** [Mensaje de album]

[10:32] **+591 61862568:** [Mensaje de album]

[10:32] **+591 61862568:** Y este otro más pequeño a 110 bs de 46 piezas estuche color rojo

[10:32] **+591 61862568:** Juego de llaves de 53 piezas a la venta a tan solo 160 bs marca New tols... estuche color naranja

[10:32] **+591 61862568:** [Imagen]

[10:32] **+591 61862568:** [Imagen]

[10:32] **+591 61862568:** [Imagen]

[10:32] **+591 61862568:** [Imagen]

[10:32] **+591 61862568:** [Imagen]

[10:32] **+591 61862568:** [Imagen]

[10:32] **+591 61862568:** [Imagen]

[11:47] **+591 67378876:** [Imagen] En el campeche hay especial, vayan! Acabo de cargar...

[15:02] **+591 73451735:** [Reenviado] [Imagen]

[15:53] **+591 71875639:** Dnd hay gasolina especial

[15:53] **+591 71875639:** Cerca

[16:11] **+591 76099442:** Las Américas

[16:11] **+591 76099442:** Esta, vacío

[16:11] **+591 68697122:** Buenas  tardes alguien sabe don hay etanol perdón

[16:51] **+591 72974985:** Avisen por favor donde hay etanol

[16:52] **+591 69327934:** Si por favor

[17:05] **+591 72985708:** Buenas tardes saben en qué surtidor hay gasolina clara por favor

[17:23] **+591 71875639:** Especial

[17:23] **+591 71875639:** Pamericano

[17:33] **+591 72990143:** Buenas tardes un taxi tipo vagoneta con parrilla para trabajar por día dentro del radio urbano por favor

[17:56] **+591 71198548:** Buenos tardes alguien sabe dónde están vendiendo gasolina especial clarita

[18:21] **+591 60256352:** San Jorge

[18:22] **+591 74540793:**
> _+591 60256352: San Jorge_
Que surtidor de San Jorge?

[18:22] **+591 60256352:** Surtidor San Jorge

[22:50] **+591 63504498:**
> _+591 68698136: Mandaron eso en otro grupo_
[Video]

---

## 30 de julio de 2026

[6:55] **+591 60256352:** Buen día gasolina especial a estas horas por favor

[6:57] **+591 79251139:** _Se eliminó este mensaje_

[7:57] **+591 60256352:** Por favor pasar el dato de gasolina especial

[9:20] **+591 73140648:** Si por favor donde ay ??? La especial ?

[9:20] **+591 71866559:** ???

[9:40] **+591 60256352:** No sabe cómo está la gasolina donde don Daniel

[10:46] **+54 9 3886 41-3903:** [Mensaje de voz]

[10:49] **+591 68735171:** Buenos días alguien sabe dónde hay etanol?

[11:07] **+591 74540793:**
> _+54 9 3886 41-3903: Mensaje de voz_
En sointa?

[11:08] **+591 74540793:** Está con fila el surtidor??

[11:50] **+591 60251131:** Hay en sointa

[11:50] **+591 60251131:** Eso me dijo est mañana el del surtidor Tarija

[12:00] **+591 75119208:** Alguien sabe donde hay gasolina eapecial

[12:00] **+591 75119208:** Me pasa el dato por favor

[12:01] **+591 60256352:** Sointa

[12:02] **+591 75127881:** Gasolina etanol alguien sabe donde hay?

[12:05] **+591 73140648:** Dónde queda sointa

[12:05] **+591 71875639:** Final circunvalacion

[12:05] **+591 71875639:** Ayer habia en san geronimo

[12:06] **+591 68735171:**
> _+591 75127881: Gasolina etanol alguien sabe donde hay?_
Podrían pasar el dato porfa

[13:49] **+591 76195199:** No saben en qué surtidor aparte del sointa hay gasolina especial ?

[14:21] **+591 72974985:** Ex terminal estan cargando etanol si a alguien le interesa el dato acabo de cargar

[14:30] **+591 75175156:** Gracias

[16:07] __+591 68694846 se unieron mediante el enlace de invitación__

[20:37] **+591 64318534:** Buenas noches

[20:37] **+591 64318534:** En que surtidor hay gasolina especial

[20:39] **+591 64318534:** Saben si en el surtidor don daniel hay gasolina especial?

[20:41] **+591 63780494:** San jorge había especial cargue a las 7pm

---

## 31 de julio de 2026

[1:20] **+591 76195618:** _Se eliminó este mensaje_

[1:26] **+591 68686988:** _Se eliminó este mensaje_

[1:27] **+591 68686988:** _Se eliminó este mensaje_

[1:29] **+591 68686988:** [Mensaje de voz]

[8:52] **+591 75146448:** Buen dia

[8:52] **+591 75146448:** Alguien sabe donde hay gasolina?

[8:52] **+591 69327934:** Alguien. Sabe en qué gasolinera hay etanol

[8:52] **+591 75146448:**
> _+591 75146448: Alguien sabe donde hay gasolina?_
Gasolina especial?

[8:59] **+591 63780494:** En el portillo tienen la plus y la etanol acabo de cargar ahi

[12:18] **+591 71875639:** Dnd hay gasolina clarita

[12:26] **+591 60251131:** En SOINTA

[13:27] **+591 60272671:**
> _+591 60251131: En SOINTA_
Es la especial ..?

[13:27] **+591 60272671:** O la plus

[13:28] **+591 60251131:** ESPECIAL

[13:29] **+591 60272671:** Gracias

[13:30] **+591 71875639:**
> _+591 60251131: En SOINTA_
Gracias

[13:49] **+591 69312200:** _Se eliminó este mensaje_

[18:23] __+591 64316997 se unieron mediante el enlace de invitación__

[19:39] **+591 69304176:** Gasolina especial

[19:39] **+591 69304176:** Hay sabe dónde pillo

[19:41] **+591 72949929:** Buenas noches especial y Etanol en Sointa

[19:43] **+591 71894444:** Otro lugar aparte de sointa 👀👀

---

## 1 de agosto de 2026

[8:39] **+591 78235592:** Buen día una consulta dónde hay gasolina blanquita

[11:05] **+591 69312879:** Buenos días alguien sabe donde están cargando etanol por fa

[11:54] **+591 72999358:**
> _+591 69312879: Buenos días alguien sabe donde están cargando etanol por fa_
Moto mendez, pero nose si seguirá habiendo

[13:15] **+591 74525861:** En las Vegas colegas cual hay?????

[14:36] **+591 73140648:** Buenas tardes alguien sabe donde ay gasolina la especial

[14:37] **+591 71897189:** _Se eliminó este mensaje_

[14:37] **+591 71897189:** _Se eliminó este mensaje_

[15:00] **+591 73875036:** Buenas tardes, alguien sabe donde puedo comprar gasolina en bidón???

[18:31] **+591 67184573:** Buenas tardes alguien sabe donde hay gasolina especial  ?

[18:40] **+591 73875036:** Buenas noches, alguien sabe en que surtidor cargan en bidón??

[18:45] **+591 71872024:** En el surtidor de las Vegas ahí cargan en bidón como siempre solo tu fotocopia de carnet único Noce si estás horas tendrán o si hay la especial pero si cargan 👍

---

## 2 de agosto de 2026

[9:11] **+591 71198548:** Buenos días alguien sabe dónde hay gasolina especial

[11:46] **+591 78708725:** Buenos días, dónde hay gasolina especial?

[11:47] **+591 74544944:** Surtidor del campesino

[13:56] **+591 68686988:** Sigue aviendo gadolina por el campesino alguirn save porfa

[15:06] **+591 74537707:** [Imagen] Balanzas digitales de cocina precio x unidad Al Mayor y Menor ...

[15:24] **+591 75138091:** Pewcio

[15:43] **+591 75116516:** Precio por favor

[15:44] **+591 74537707:** 43 bs ....

[15:44] **+591 74537707:** Estamos dando al mejor precio de todo tarija

[17:20] **+591 71897189:** Buenas tardes alguien puede  informar  x favor dónde están vendiendo gasolina

[17:20] **+591 71897189:** Que surtidor está vendiendo gasolina  x favor

[17:25] **+591 75124570:** YPFB del campesino

[17:31] **+591 71897189:** Ok gracias

[18:08] __+591 68694541 se unieron mediante el enlace de invitación__

[18:11] __+591 78232702 se unieron mediante el enlace de invitación__

---

## 3 de agosto de 2026

[7:46] **+591 71875639:** Wen dia alguien cargo gasolina clarita

[8:09] **+591 71894444:** Avisan por favor.

[8:11] **+591 74543626:** Hola buenas días moto Mendes  tiene la especial

[8:11] **+591 71894444:** Donde es ese surtidor?

[8:12] **+591 71875639:**
> _+591 74543626: Hola buenas días moto Mendes  tiene la especial_
Algo mas cerca😂

[8:19] **+591 78707745:**
> _+591 74543626: Hola buenas días moto Mendes  tiene la especial_
Gracias

[9:59] **+591 78235592:** Dónde hay gasolina clarita por favor

[9:59] **+591 79267492:** San jorge

[10:24] **+591 72985708:** [Imagen]

[10:24] **+591 71875639:** [Imagen]

[10:24] **+591 71875639:** San geronimo

[10:56] **+591 78235592:**
> _+591 71875639: Imagen_
Es la clarita?

[10:58] **+591 71875639:** Yes

[10:58] **+591 78235592:**
> _+591 71875639: Yes_
Gracias

[11:21] **+591 63780494:** Positivo la especial en san Geronimo

[11:36] **+591 71872024:** Una pregunta están cargando en bidones ahí en san gerónimo

[11:36] **+591 71875639:** Si

[11:45] **+591 71872024:** Gracias

[12:46] __+591 64579363 se unieron mediante el enlace de invitación__

[12:48] **+591 64579363:** Buanas tardes alguien save en que surtidor estan vendiendo la gasolina clarita

[13:43] **+591 71894444:** Buenas tsrdes
Gasina especial donde hay?

[13:54] **+591 71875639:**
> _+591 71875639: San geronimo_
Mm

[13:58] **+591 75515740:** Surtidor panamericano 
San Geronino
Hay la especial 
Clarita

[13:58] **+591 71875639:** Sointa

[14:00] **+591 71894444:** Gracias

[14:02] **+591 68694846:** 👍🏻

[14:17] **+591 71894444:** Cargue en las Vegas
Clarita 👍

[14:58] **+591 75515740:** 👍🏻

[18:32] **+591 75515740:** Buenas tardes

[18:33] **+591 75515740:** Alguien que me informe donde están vendiendo gasolina especial la  clarita por favor

[18:33] **+591 60256352:** Surtidor San gerónimo

[18:34] **+591 75515740:** Acabo de salir se termino me dijeron

[18:34] **+591 75515740:** Otro surtidor ?

[18:35] **+591 71897189:** En que surtidor están vendiendo gasolina alguien me podría informar x favor

[18:48] **+591 75515740:** HAY GASOLINA ESPECIAL EN SURTIDOR TACUARANDI la "clarita"
Habrá hasta el sábado la especial en este surtido 
NO HAY FILA

[18:49] **+591 75515740:** acabo de cargar 🏃🏻‍♂️
Aprovechen...

[19:12] **+591 76181373:** [Sticker]

[19:27] **+591 71875639:** Alguien puede enviar foto o imagen los de entel?

[19:28] **+591 60251131:** _Se eliminó este mensaje_

[20:51] **+591 68717611:**
> _+591 71875639: Alguien puede enviar foto o imagen los de entel?_
No

[20:51] **+591 68717611:** Ni con wifi

[20:52] **+591 75130876:** No se puede enviar fotos ni con wifi  Tigo 😡

[20:54] **+591 65821266:** Con starlink se puede normal

[20:59] **+591 64301527:** Ohh Perdón Don elon mosc

[21:01] **+591 67392004:** _Se eliminó este mensaje_

[21:45] **+591 74537707:** [Reenviado] https://vt.tiktok.com/ZS9hPme5dH6WT-bxSXO/

[21:58] **+591 69312879:** Buenas noches

[21:58] **+591 69312879:** Alguien sabe donde están vendiendo etanol a estas horas

[22:51] **+591 69312879:** Por favor amigos alguien sabe a que hora empiezan a cargar combustible los surtidores? Es urgente

[22:52] **+591 72426015:**
> _+591 75515740: Acabo de salir se termino me dijeron_
Algunos 8 am

[22:52] **+591 72426015:** El del  campeskno ypf desde las 4 am

[22:52] **+591 72426015:** Mi estimado juanito

[23:01] **+591 69312879:** Gracias muy amable

---

## 4 de agosto de 2026

[14:10] **+591 73483881:** Dónde hay gaso clarita en este momento?

[14:32] **+591 75515740:** Surtidor tacuarandi

[14:40] **+591 71897189:** Disculpen en la circunvalación hay gasolina  me podrían informar x favor

[16:46] __[Notificación del sistema]__

[19:42] **+591 74525861:** Buenas noches

[19:42] **+591 74525861:** Donde encuentro gasolina a esta hora

[19:45] **+591 75124570:** Tacuarendi

[20:12] **+591 75794111:** Buenas noches saben dónde hay gasolina

[20:12] **+591 75794111:**
> _+591 75124570: Tacuarendi_
Hay mucha fila ? Alguien sabe

[20:14] **+591 67378876:** _Se eliminó este mensaje_

[22:38] **+591 72949826:** Dónde hay gasolina por favor

[22:41] **+591 72949826:** Hola

[22:43] **+591 75794111:** Portillo

[22:54] **+591 72949826:** Jgracuad

[22:54] **+591 72949826:** Gracias

[23:10] **+591 73457507:** https://chat.whatsapp.com/IMo6ZG44UjNKjk9w3H2KUE?mode=hqrt3

---

## 5 de agosto de 2026

[7:46] **+591 63780494:** Gasolina especial en el portillo la etanol no hay

[7:49] **+591 62853115:** Buenos días en q surtidor ya habra gasolina especial

[7:49] **+591 62853115:** Alguien sabe

[7:50] **+591 71875639:**
> _+591 72985708: Imagen_
...

[8:18] **+591 71872024:** [Mensaje de album]

[8:19] **+591 71872024:** [Imagen] MOTO CARGA 
☑️ Realizamos envio de encomiendas 
☑️Recojemos encomiendas llevamos hasta su domicilio 
☑️ Servicio de translados

[8:19] **+591 71872024:** [Imagen]

[8:19] **+591 71872024:** [Imagen]

[8:39] **+591 63780494:**
> _+591 62853115: Buenos días en q surtidor ya habra gasolina especial_
Portilloooooooooo

[8:40] **+591 68289593:** [Imagen]

[8:40] **+591 68289593:** Portillo

[8:41] **+591 69307503:**
> _+591 63780494: Portilloooooooooo_
[Mensaje de voz]

[9:16] **+591 76547557:** Me pasa el link del grupo porfa

[11:29] **+591 72042913:** Alguien sabe como registrarse para compra en vidones de gasolina por favor me pasa el daro

[12:20] **+591 77178786:** Saben si hay gasolina en YPFB morros blancos

[12:20] **+591 77178786:** O mucha fila ?

[12:34] **+591 75127881:** Alguien sabe donde hay gasolina etanol?

[14:22] **+591 64318534:** Saben en que surtidores mas hay gasolina especial o etanol?

[15:37] **+591 75146448:** Buenas

[15:37] **+591 75146448:** Tardes

[15:37] **+591 75146448:** Alguien sabe donde hay gasolina especial

[16:11] __+591 69836650 se unieron mediante el enlace de invitación__

[16:34] **+591 71866559:**
> _+591 75146448: Alguien sabe donde hay gasolina especial_
Campesino

[16:48] **+591 69836650:** [Imagen]

[17:32] **+591 78708725:** No hay gasolina especial en ningún surtidor y no saben si va a llegar esta semana

[17:33] **+591 67384303:** Alguien sabe si en algun surtidor estan vendiendo Gasolina Etanol

[17:36] **+591 78232702:** Don Daniel etanol

[17:39] **+591 67384303:**
> _+591 78232702: Don Daniel etanol_
Gracias hermano

[18:26] **+54 9 3886 41-3903:** [Mensaje de voz]

[18:30] **+591 78708725:** Todas las avenida las Américas hasta llegar a Morro blancos surtidores, no hay en el Portillo tampoco hay todita la circunvalación hasta Las Vegas. No hay gasolina especial no saben si van a llegar esta semana. Ayer dicen que había

[18:38] **+591 72999358:** Todos los días hay la especial, sino que varía cada surtidor...

[18:38] **+591 73453128:** [Mensaje de voz]

[18:41] **+591 64301527:** Mucho se alteran luego llega normal pero la gente va a hacérsela cagar y se hacen las filas

[19:09] **+591 60251131:** Gasolina está llegando normal yo fui ayer al medio día a las vegas y había la especial y fila de 2 o 3 autos no mas

[19:57] **+591 67378876:**
> _+591 69836650: Video_
Jajaja que pornero!

[20:29] **+591 64318534:** En el surtudor don daniel hay gasolina plus pero aun hay etanol resien estoy por cargar etanol y no hay fila

[21:18] **+591 76185088:** Buenas noches. No saben donde hay gasolina especial ahorita?

---

## 6 de agosto de 2026

[8:01] **+591 78702088:** Buenos días

[8:01] **+591 78702088:** Algún surtidor que este cargando gasolina

[8:01] **+591 78702088:** Me pasan el dato por favor

[9:08] **+591 64318534:** En surtidores  hay gasolina especial?

[9:09] **+591 72942858:**
> _+591 64318534: En surtidores  hay gasolina especial?_
Pasen el dato

[9:19] **+591 67960504:** Buenos dias donde ay gasolina limpia

[9:20] **+591 71203130:** [Imagen] 201 AÑOS 1.825 - 2026

[10:21] __+591 62432717 se unieron mediante el enlace de invitación__

[10:55] **+591 60262808:** Si alguien sabe de alguien q tenga para vender un escape para cg o un grupo de venta de repuesto de motos

[11:21] __Alguien añadió a +591 62432717__

[11:38] **+591 72973019:** Buen día no saben donde están cargando gasolina especial

[11:44] **+591 72999358:** Campesino decían esta mañana

[12:05] **+591 74525861:** Compartan info por favor

[15:28] **+591 71875639:** Alguien cargo gasolina clarita

[15:30] **+591 75143839:**
> _+591 71875639: Alguien cargo gasolina clarita_
❓❓❓❓❓❓❓

[15:30] **+591 75143839:** Avisen...xfa

---

## 7 de agosto de 2026

[8:46] **+591 75127881:** Buenos días alguien sabe donde hay gasolina etanol?

[8:49] **+591 71872024:** En el YPFB del mercado campesino hay gasolina clarita

[9:12] **+591 75131173:** [Imagen] Porfavor si tienen alguna información 🙏

[9:17] **+591 78708725:**
> _+591 71872024: En el YPFB del mercado campesino hay gasolina clarita_
Buenos días, y venden con bidón qué saben?

[9:32] **+591 75113568:**
> _+591 78708725: Buenos días, y venden con bidón qué saben?_
En surtidor del campesino no venden en bidón

[9:33] **+591 62854311:**
> _+591 71872024: En el YPFB del mercado campesino hay gasolina clarita_
[Sticker]

[10:42] **+591 60251131:** Donde hay Etanol

[10:42] **+591 60251131:** ?

[10:43] **+591 72949929:** Buen día especial en YPFB campesino

[10:44] **+591 60251131:** Que tal la fila

[11:00] **+591 72949929:** Pocos

[11:03] __+591 75132648 se unieron mediante el enlace de invitación__

[11:03] __Alguien añadió a +591 75132648__

[11:05] **+591 65821266:** Buen día

[11:05] **+591 65821266:** Alguien conoce alquiler de montacargas

[11:13] **+591 60251131:** No hay

[11:13] **+591 60251131:** Ta cerrau campesino

[11:13] **+591 60251131:** Recién está descargando la cisterna pero que gasolina será ni idea

[11:44] **+591 68289593:** Alguien que tenga un conocido, que tenga grúa

[11:44] **+591 68289593:** Para mover una camioneta es

[11:44] **+591 68289593:** Me pasa el número porfa

[11:44] **+591 69327934:** Etanol ?

[11:45] **+591 69327934:** En qué parte

[11:47] **+591 68698136:** [Reenviado] [Contacto: BEGIN:VCARD
VERSION:3.0
N:Condorí;Gruas Tarija De;Imar;;
FN:Gruas Tarija De Imar Condorí
item1.TEL;waid=59174512936:+591 74512936
item1.X-ABLabel:Celular
X-WA-BIZ-DESCRIPTION:Servicios de Gruas
X-WA-BIZ-NAME:Gruas Tarija De Imar Condorí
END:VCARD]

[11:47] **+591 68698136:**
> _+591 68698136: BEGIN:VCARD
VERSION:3.0
N:Condorí;Gruas Tarija De;Imar;;
FN:Gruas Tarija De Imar Condorí
item1.TEL;waid=59174512936:+591 74512936
item1.X-ABLabel:Celular
X-WA-BIZ-DESCRIPTION:Servicios de Gruas
X-WA-BIZ-NAME:Gruas Tarija De Imar Condorí
END:VCARD_
Ahi tiene

[11:47] **+591 72973019:** Alguien sabe donde están cargando gasolina especial la Clarita

[12:21] **+591 67378876:** [Imagen] Especial en el campeche!! Hasta las 5 habrá

[12:22] **+591 71894444:** Larga la fila?

[12:31] **+591 67378876:**
> _+591 71894444: Larga la fila?_
Fila de unos 15 minutos!

[12:35] **+591 72999358:** En el de morros blancos la fila debe estar de unos 40 min..

[15:35] **+591 69312879:** Buenas tardes amigos alguien sabe donde están cargando gasolina especial o etanol

[16:32] **+591 72976766:** San Geronimo

[17:05] **+591 78708725:**
> _+591 72976766: San Geronimo_
Es la especial

[17:58] **+591 71872024:** Disculpen En san Gerónimo cargan en bidón

[18:19] **+591 71872024:** [Imagen] San gerónimo sigue hay gasolina si dudan qué se está acabando Masomenos hasta las 9 dijo

[18:21] **+591 76836904:**
> _+591 71872024: Imagen: San gerónimo sigue hay gasolina si dudan qué se está acabando Masomenos hasta las 9 dijo_
Esta largo la fila ?

[18:22] **+591 78708725:**
> _+591 71872024: Imagen: San gerónimo sigue hay gasolina si dudan qué se está acabando Masomenos hasta las 9 dijo_
Que gasolina están cargando porfa

[18:23] **+591 73453128:** [Mensaje de voz]

[18:34] **+591 71872024:**
> _+591 76836904: Esta largo la fila ?_
No hay fila amigos aprovechen los que no cargaron en la mañana

[18:34] **+591 76836904:** GRACIAS

[18:37] **+591 78708725:**
> _+591 71872024: No hay fila amigos aprovechen los que no cargaron en la mañana_
Que gasolina están cargando porfa

[18:38] **+591 71872024:** Último dato en bidón están cargando 140 bs maximo por persona con fotocopia de carnet como siempre el único requisito hasta las 9 poray alcanzara dijo la qué carga

[18:47] **+591 68731773:** _Se eliminó este mensaje_

---

## 8 de agosto de 2026

[10:47] **+591 72903627:** Alguien sabe dónde hay gasolina blanquita

[10:48] **+591 71192881:**
> _+591 72903627: Alguien sabe dónde hay gasolina blanquita_
Si xfavor avisen

[10:58] __[Llamada]__

[10:59] **+591 78708725:**
> _+591 72903627: Alguien sabe dónde hay gasolina blanquita_
En el surtidor las vegas

[11:27] **+591 68616631:** villa nueva está gasolina clarita

[12:03] **+591 71875639:**
> _+591 68616631: villa nueva está gasolina clarita_
Dnd ese

[13:51] **+591 74507185:** https://www.facebook.com/share/p/18wAZntTTN/

[15:39] **+591 67962583:** Alguien sabe dónde ahí gasolina buena

[15:40] **+591 71875639:** Vegas

[15:41] **+591 63786945:** En la agrupa hay gasolina especial

[15:41] **+591 67962583:** Gracias

[15:47] **+591 72960822:** En surtidor Villanueva ( san Gerónimo) gasolina especial, no hay nada de fila

[19:02] **+591 78703080:** Donde hay gasolina   a esta hora   alguien sabe por fabor

[19:42] **+591 72976766:** San Geronimo

[19:43] __+591 63774897 se unieron mediante el enlace de invitación__

[19:43] __Alguien añadió a +591 63774897__

[19:43] __+591 64315275 se unieron mediante el enlace de invitación__

[19:43] __+591 75149463 se unieron mediante el enlace de invitación__

[19:43] __Alguien añadió a +591 64315275__

[19:43] __+591 63771242 se unieron mediante el enlace de invitación__

[19:43] __Alguien añadió a +591 75149463__

[19:43] __+591 63771242, +591 75149463 y +591 64315275 salieron__

[19:44] __Alguien añadió a +591 63771242__

[19:44] __+591 67995662 añadió a +591 64315275__

[19:44] __+591 71878674 se unieron mediante el enlace de invitación__

[19:44] __+591 60274507 se unieron mediante el enlace de invitación__

[19:45] __+591 68686252 se unieron mediante el enlace de invitación__

[19:45] __+591 72900216 se unieron mediante el enlace de invitación__

[19:45] __+591 72902772 se unieron mediante el enlace de invitación__

[19:45] __Alguien añadió a +591 72902772__

[19:45] __+591 79284222 se unieron mediante el enlace de invitación__

[19:49] __+591 60270538 se unieron mediante el enlace de invitación__

[19:49] __Alguien añadió a +591 60270538__

[19:53] __+591 77878271 se unieron mediante el enlace de invitación__

[19:54] __+591 72908757 se unieron mediante el enlace de invitación__

[19:54] __Alguien añadió a +591 77878271__

[19:54] __+591 74506005 se unieron mediante el enlace de invitación__

[19:54] __+591 73462950 se unieron mediante el enlace de invitación__

[19:54] __+591 71196497 se unieron mediante el enlace de invitación__

[20:00] __+591 62857077 se unieron mediante el enlace de invitación__

[20:03] __+591 72376847 se unieron mediante el enlace de invitación__

[20:08] __+591 73482879 se unieron mediante el enlace de invitación__

[20:08] __Alguien añadió a +591 73482879__

[20:10] __+591 75112180 se unieron mediante el enlace de invitación__

[20:10] __Alguien añadió a +591 75112180__

[20:13] __+591 77178704 se unieron mediante el enlace de invitación__

[20:13] __+591 67695743 se unieron mediante el enlace de invitación__

[20:19] __+591 75118962 se unieron mediante el enlace de invitación__

[20:19] __+591 60260183 se unieron mediante el enlace de invitación__

[20:20] __+591 72983071 se unieron mediante el enlace de invitación__

[20:23] __+591 76183119 se unieron mediante el enlace de invitación__

[20:24] __Alguien añadió a +591 76183119__

[20:26] __+591 67968964 se unieron mediante el enlace de invitación__

[20:36] __+591 64709432 se unieron mediante el enlace de invitación__

[20:46] __+591 60261840 se unieron mediante el enlace de invitación__

[20:53] __+591 72990742 se unieron mediante el enlace de invitación__

[21:08] __+591 76190876 se unieron mediante el enlace de invitación__

[21:13] __+591 72950502 se unieron mediante el enlace de invitación__

[21:16] __+591 67591385 se unieron mediante el enlace de invitación__

[21:21] __+591 77170522 se unieron mediante el enlace de invitación__

[21:49] __+591 68710345 se unieron mediante el enlace de invitación__

[21:50] __Alguien añadió a +591 68710345__

[22:07] **+591 73451069:**
> _+591 72426015: Algunos 8 am_
No saben Enq

[22:07] **+591 73451069:** Surtidor

[22:07] **+591 73451069:** Hay gasolina

[22:07] **+591 73451069:** Por favor avisen

[22:09] __+591 72970475 se unieron mediante el enlace de invitación__

[22:11] **+591 74537707:** [Reenviado] https://vt.tiktok.com/ZS9h7gqXaAjTN-MNGRI/

[22:24] __+591 64338061 se unieron mediante el enlace de invitación__

[22:24] __Alguien añadió a +591 64338061__

[22:30] __+591 62851390 se unieron mediante el enlace de invitación__

[22:38] __+591 70224019 se unieron mediante el enlace de invitación__

[22:39] __Alguien añadió a +591 70224019__

[22:52] **+591 72903627:** Pueden pasar el enlace del grupo xfavor

[23:07] __+591 69317750 se unieron mediante el enlace de invitación__

[23:07] __Alguien añadió a +591 69317750__

[23:25] __+591 74509579 se unieron mediante el enlace de invitación__

[23:26] __Alguien añadió a +591 74509579__

[23:27] __+591 72422353 se unieron mediante el enlace de invitación__

[23:58] __+591 71890219 se unieron mediante el enlace de invitación__

---

## 9 de agosto de 2026

[0:00] __Alguien añadió a +591 71890219__

[0:00] __+591 76193458 se unieron mediante el enlace de invitación__

[0:03] __+591 75138887 se unieron mediante el enlace de invitación__

[0:40] __+591 63393319 se unieron mediante el enlace de invitación__

[2:04] __+591 73489032 se unieron mediante el enlace de invitación__

[2:04] __Alguien añadió a +591 73489032__

[4:57] __+591 63793336 se unieron mediante el enlace de invitación__

[5:33] __+591 74543036 se unieron mediante el enlace de invitación__

[6:26] __+591 63774126 se unieron mediante el enlace de invitación__

[7:08] __+591 72560824 se unieron mediante el enlace de invitación__

[7:22] **+591 77176030:** Buenos días 

Saben dónde hay gasolina?

[8:28] **+591 78703080:** Si por fabor saben dondehay gasolina ?

[8:30] __+591 62573108 se unieron mediante el enlace de invitación__

[8:31] **+591 67995662:** Abre este enlace para unirte a mi grupo de WhatsApp: https://chat.whatsapp.com/Kaaw4UZwAcNAuM3RQUFpEv?s=sw&p=a&mlu=4

[8:46] **+591 71894444:** Buen día
Saben donde hay gasolina?

[9:29] **+591 63791971:** Buen día alguien sabe si  están vendiendo normal con bidón porfavor

[9:32] **+591 60274507:** Si.  Con fotocopia de carnet  nomas

[9:54] __+591 71869861 se unieron mediante el enlace de invitación__

[9:54] __Alguien añadió a +591 71869861__

[10:26] __+591 68131964 se unieron mediante el enlace de invitación__

[10:26] __Alguien añadió a +591 68131964__

[10:54] __+591 69333935 se unieron mediante el enlace de invitación__

[10:55] __Alguien añadió a +591 69333935__

[11:02] __+591 75798904 se unieron mediante el enlace de invitación__

[11:05] __+591 67395019 se unieron mediante el enlace de invitación__

[11:05] __+591 72966160 se unieron mediante el enlace de invitación__

[11:47] __+591 72953460 se unieron mediante el enlace de invitación__

[11:48] **+591 75146448:** Hola

[11:48] **+591 75146448:** Buen dia

[11:49] **+591 75146448:** Donde hay gasolina especial

[11:49] **+591 75146448:** Podrían pasar el dato porfavor

[11:54] **+591 60274507:** Hoy dificil domingo ayer cargue  en el tarija.  La especial mañana donde tocara

[11:59] __+591 73451365 se unieron mediante el enlace de invitación__

[12:13] __+591 73481309 se unieron mediante el enlace de invitación__

[12:14] __Alguien añadió a +591 73481309__

[12:15] __+591 72952915 se unieron mediante el enlace de invitación__

[12:37] __+591 67992567 se unieron mediante el enlace de invitación__

[12:37] __Alguien añadió a +591 67992567__

[12:52] __+591 75147474 se unieron mediante el enlace de invitación__

[13:44] __+591 75153879 se unieron mediante el enlace de invitación__

[13:45] **+591 69327934:** Etanol ?

[13:45] **+591 69327934:** Alguien. Sabe

[13:59] **+591 72999358:**
> _+591 69327934: Etanol ?_
Ex terminal había en la mañana, nose si seguirá habiendo

[14:00] **+591 69327934:** A qué hora fuiste a cargar ?

[14:00] **+591 69327934:** Tipo

[14:00] **+591 69327934:** Qué hora

[14:00] **+591 72999358:** Nose en otro grupo así avisaron...

[14:00] __+591 60267747 se unieron mediante el enlace de invitación__

[14:01] __+591 67381511 se unieron mediante el enlace de invitación__

[14:03] __+591 74643349 se unieron mediante el enlace de invitación__

[14:40] **+591 64338061:** Gasolina saben donde hay buenas tardes

[15:01] **+591 67963233:** Buenas tardes

[15:01] **+591 67963233:** Alguien sabe donde hay gasolina a esta hota

[15:03] __+591 74637856 se unieron mediante el enlace de invitación__

[15:53] __+591 61853000 se unieron mediante el enlace de invitación__

[16:07] __+591 77879528 se unieron mediante el enlace de invitación__

[16:08] __+591 73673550 se unieron mediante el enlace de invitación__

[16:09] __+591 73451618 se unieron mediante el enlace de invitación__

[16:44] __+591 75146349 se unieron mediante el enlace de invitación__

[18:02] __+591 76993582 se unieron mediante el enlace de invitación__

[18:16] **+591 73875036:** Buenas

[18:16] **+591 73875036:** Alguien sabe donde hay gasolina a esta hora

[18:16] **+591 73875036:** ???

[18:17] **+591 72953460:** YPFB en la parada al chaco

[18:29] **+591 64338061:**
> _+591 72953460: YPFB en la parada al chaco_
Sigue abiendo ?

[18:37] **+591 72953460:** 👍San jorge igual

[18:38] **+591 72867582:** Especial?

[18:39] **+591 72426015:** Alguien q me ñueda pasar corriente por favor

[19:30] __+591 72946833 se unieron mediante el enlace de invitación__

[19:54] __+591 72999782 se unieron mediante el enlace de invitación__

[20:37] **+591 62630610:** Buenas noches alguien sabe dónde hay gasolina ahorita?

[20:38] **+591 72867582:** Delivery

---

## 10 de agosto de 2026

[7:26] **+591 73456683:** Buenos días alguien sabe en que surtidor están vendiendo gasolina

[7:27] **+591 77878271:** YPFB en la parada al chaco

[7:27] **+591 73456683:** Gracias

[7:56] **+591 73482879:** Donde hay gasolina especial o etanol??

[7:57] **+591 71897189:** Buen día, dónde están vendiendo gasolina? Por favor alguien me diría

[8:06] **+591 74537707:**
> _+591 77878271: YPFB en la parada al chaco_
Está larga la fila

[8:06] **+591 74537707:** ??

[8:13] **+591 63780494:** No hay mucha fila recién pase por ahi

[8:14] **+591 63780494:** Cargue a las 7 am pero solo hay la plus

[8:14] **+591 64338061:**
> _+591 63780494: Cargue a las 7 am pero solo hay la plus_
Ahí piden licencia para cargar?

[8:21] **+591 63780494:** No me pidieron nada

[8:21] **+591 63780494:** Cargue normal

[8:29] **+591 71897189:** Alguien x favor que sepa dónde están vendiendo gasolina en estos momentos x favor x la exterminal si alguien vio gracias

[8:37] **+591 60252340:** En ex terminal hay y morros blancos

[8:37] **+591 60252340:** Solo la plus pero

[8:40] **+591 71897189:** Ok muchas gracias

[8:41] **+591 75147474:** Gasolina especial surtidor YPFB morros blancos fila corta

[8:43] **+591 64301527:** Grande sur trading

[9:10] **+591 75147474:**
> _+591 75147474: Gasolina especial surtidor YPFB morros blancos fila corta_
Perdón es la plus que está n vendiendo

[9:12] **+591 63793336:** [Mensaje de voz]

[9:12] **+591 63793336:**
> _+591 63793336: Mensaje de voz_
[Mensaje de voz]

[9:31] **+591 60267747:** Surtidor panamericano cerca del coliseo tiene gasolina plus

[9:31] **+591 60267747:** Y la fila no está muy larga

[9:31] **+591 60267747:** Acabo de cargar

[10:10] __+591 63531238 se unieron mediante el enlace de invitación__

[10:11] __Alguien añadió a +591 63531238__

[11:20] **+591 72975761:** Compañeros alguien q pase el dato de algún surtidor donde no estén haciendo fila

[11:33] **+591 74548288:** Surtidor moto Méndez

[11:33] **+591 77170522:** Surtidor Tarija, fila de unos 14 autos

[11:37] **+591 72975761:** 👍

[11:39] **+591 68694846:** _Se eliminó este mensaje_

[11:42] **+591 75146448:**
> _+591 77170522: Surtidor Tarija, fila de unos 14 autos_
Gasolina especial

[11:42] **+591 75146448:** ?

[11:55] **+591 63774126:** Buenos días alguien  sabe  en que  surtidor  están  vendiendo  etanol

[11:58] **+591 77170522:**
> _+591 75146448: Gasolina especial_
Es la plus

[12:36] **+591 75146448:** Alguien sabe donde hay gasolina especial que pase el dato porfavor

[12:37] **+591 68131964:** Surtidor las Vegas o la de don diego

[12:37] **+591 75146448:** Gracias

[12:39] **+591 75146448:**
> _+591 68131964: Surtidor las Vegas o la de don diego_
Cual es la de don diego?

[12:43] **+591 71875639:** Hay en las vegas?

[12:45] **+591 71875639:**
> _+591 75146448: Cual es la de don diego?_
Don daniel debe ser

[13:02] **+591 64301527:** Alguien sabe porque están haciendo fila para gasolina?

[13:03] **+591 71875639:** Dnd hay gasolina clarita locos

[14:25] **+591 69327934:** Gasolina etanol

[14:25] **+591 69327934:** Alguien sabe

[14:39] **+591 75186906:** [Imagen]

[15:04] **+591 71875639:**
> _+591 64301527: Alguien sabe porque están haciendo fila para gasolina?_
Xq n hay

[15:07] **+591 71875639:** Dnd hay gasolina clarita?

[15:07] **+591 63780494:** Pienso que en sointa debe haber clarita había fila como de 20 autos y donde hay fila siempre hay especial

[15:07] **+591 71875639:**
> _+591 63780494: Pienso que en sointa debe haber clarita había fila como de 20 autos y donde hay fila siempre hay especial_
Q hora

[15:07] **+591 63780494:** Hace media hora

[15:08] **+591 75186906:** Donde hay gasolina especial

[15:08] **+591 71875639:** Gracias

[15:19] **+591 73456683:** _Se eliminó este mensaje_

[15:21] __+591 74559709 se unieron mediante el enlace de invitación__

[15:23] **+591 74559709:** Buenas saben de algún surtidor que tenga gasolina no importa si hay fila

[15:30] **+591 60251131:**
> _+591 74559709: Buenas saben de algún surtidor que tenga gasolina no importa si hay fila_
Tarija

[15:33] **+591 74559709:**
> _+591 60251131: Tarija_
Gracias

[15:51] **+591 75515740:** Buenas tardes

[15:52] **+591 75515740:** Alguien podría avisarme donde hay gasolina Especial, clarita?

[15:54] **+591 72426015:** No hsy  tofo pluss no mas

[17:20] **+591 63531238:** Buenas alguien sabe si hay gasolina por la zona san Gerónimo

[17:20] **+591 63531238:** ??

[17:21] **+591 75515740:** Busco gallina Especial alguien sabe algo ?

[17:22] **+591 72990143:**
> _+591 75515740: Busco gallina Especial alguien sabe algo ?_
criolla o granjera?

[17:25] **+591 75515740:**
> _+591 72990143: criolla o granjera?_
Jajajaja Jajajaja 
Quise decir gasolina Especial " clarita"

[17:27] **+591 72990143:** 😖

[18:46] **+591 60251131:** La del surtidor Tarija salían con bidones con gasolina clarita

[18:54] **+591 61862568:** Yo compre en El Tarija solo hay plus no mas...

[18:59] **+591 74507185:** Avia gasolina clarita

[18:59] **+591 74507185:** Pero ya no ay

[19:02] **+591 72968117:** Buenas noches no saben en q surtidor hay gasolina

[19:02] **+591 72968117:** ??

[19:03] **+591 71875639:** [Mensaje de voz]

[19:08] **+591 68746056:**
> _+591 72968117: Buenas noches no saben en q surtidor hay gasolina_
En el grupo había acabo de cargar hace 10 minutos

[19:11] **+591 72968117:** Gracias

[22:07] **+591 69333935:** _Se eliminó este mensaje_

[22:12] **+591 64315275:**
> _+591 68746056: En el grupo había acabo de cargar hace 10 minutos_
De la especial ?

[22:38] **+591 64338061:** Buenas noches alguien sabe si en Algún lado hay gasolina a estas horas saben ?

---

## 11 de agosto de 2026

[7:27] **+591 71875639:** Buenos dias donde hay gasolona especial xfavor

[8:14] **+591 73483881:** Hay filota en el surtidor Tarija Pero no sé si habrá la especial

[8:34] **+591 78692302:**
> _+591 73483881: Hay filota en el surtidor Tarija Pero no sé si habrá la especial_
Desde donde esta la cola

[8:34] **+591 73483881:** 3 cuadras

[8:42] **+591 75515740:** Buen día 
Alguien que sepa en que surtidor están vendiendo gasolina Especial clarita

[9:57] **+591 64338061:**
> _+591 64315275: De la especial ?_
Buen día algún surtidor que haiga gasolina ahorita

[9:58] **+591 64315275:**
> _+591 64338061: Buen día algún surtidor que haiga gasolina ahorita_
X2

[9:59] **+591 78240922:** A la tarde se pilla mas seguro la especial

[9:59] **+591 71875639:** San jorge supuestamente

[10:01] **+591 72999358:**
> _+591 78240922: A la tarde se pilla mas seguro la especial_
Cómo siempre y sin fila

[10:29] **+591 71875639:** Alas 2

[10:29] **+591 71875639:** En don daniel

[10:29] **+591 71875639:** Especial abra

[10:29] **+591 71875639:** Luego aqui en el tarija hay blanquita

[10:29] **+591 71875639:** Fila media larga

[10:32] **+591 71875639:** [Imagen]

[10:32] **+591 63780494:** Surtidor panamericano de san Geronimo a partir de medio día abra especial pero ya hay fila una cuadra

[11:21] **Tú:** Buen dia en que surtidor tienen gasolina

[11:24] **+591 73897953:** [Imagen]

[11:37] **+591 75149463:**
> _Tú: Buen dia en que surtidor tienen gasolina_
Panamericano

[11:58] __+591 78225036 se unieron mediante el enlace de invitación__

[12:55] __+591 67378987 se unieron mediante el enlace de invitación__

[12:56] __+591 75129306 se unieron mediante el enlace de invitación__

[13:02] __+591 76920181 se unieron mediante el enlace de invitación__

[13:04] __+591 63779256 se unieron mediante el enlace de invitación__

[13:15] **+591 69327934:** Gasolina etanol alguien sabe

[13:15] **+591 71875639:** En el tarija habia clarita

[13:16] __+591 76196000 se unieron mediante el enlace de invitación__

[13:21] __+591 73454321 se unieron mediante el enlace de invitación__

[13:21] **+591 75515740:** Gasolina especial en que surtidor están cargando ?

[13:37] __+591 67388101 se unieron mediante el enlace de invitación__

[14:06] **+591 73483881:** Tacuarandi sin fila Pero no sé si hay la especial

[14:07] **+591 76836904:** Alguien sabe si las vegas sigue la fila larga?

[14:11] **+591 63531238:**
> _+591 76836904: Alguien sabe si las vegas sigue la fila larga?_
Si

[14:18] **+591 77870087:** Don daniel.... Gasolina especial ...fila d 1 cuadra y media masomenos

[14:21] **+591 75140034:** Etanol no saben en q surtidor hay????

[14:32] **+591 69327934:** Si alguien sabe

[14:32] **+591 69327934:** Dónde hay

[14:32] **+591 69327934:** Etanol

[14:57] __+591 73497164 se unieron mediante el enlace de invitación__

[14:58] __Alguien añadió a +591 73497164__

[16:08] __+591 69327422 se unieron mediante el enlace de invitación__

[16:08] __+591 72960135 se unieron mediante el enlace de invitación__

[16:09] __Alguien añadió a +591 69327422__

[16:14] __+591 72996308 se unieron mediante el enlace de invitación__

[16:19] **+591 72960135:** 👋🏻👋🏻

[17:10] __+591 72950854 se unieron mediante el enlace de invitación__

[17:24] __+591 77175895 se unieron mediante el enlace de invitación__

[17:28] __+591 61618526 se unieron mediante el enlace de invitación__

[17:39] **+591 64580937:** [Mensaje de voz]

[17:47] __+591 67398221 se unieron mediante el enlace de invitación__

[17:52] **+591 67995662:** [Mensaje de voz]

[18:02] **+591 64579363:** Buenas tardes alguien saven si todavia hay gasolina en el surtidor don daniel

[18:05] **+591 67995662:** Abre este enlace para unirte a mi grupo de WhatsApp: https://chat.whatsapp.com/Kaaw4UZwAcNAuM3RQUFpEv?s=sw&p=a&mlu=4

[18:05] __+591 71873484 se unieron mediante el enlace de invitación__

[18:05] __+591 67967584 se unieron mediante el enlace de invitación__

[18:05] __+591 75127124 se unieron mediante el enlace de invitación__

[18:05] __+591 76184700 se unieron mediante el enlace de invitación__

[18:06] __+591 75465137 se unieron mediante el enlace de invitación__

[18:06] __+591 72970214 se unieron mediante el enlace de invitación__

[18:07] __+591 60253410 se unieron mediante el enlace de invitación__

[18:09] **+591 64580937:**
> _+591 64579363: Buenas tardes alguien saven si todavia hay gasolina en el surtidor don daniel_
[Mensaje de voz]

[18:09] __+591 72994717 se unieron mediante el enlace de invitación__

[18:13] __+591 60280229 se unieron mediante el enlace de invitación__

[18:16] __+591 67385609 se unieron mediante el enlace de invitación__

[18:23] __+591 60263835 se unieron mediante el enlace de invitación__

[18:27] __+591 76193928 se unieron mediante el enlace de invitación__

[18:28] __+591 68691063 se unieron mediante el enlace de invitación__

[18:28] __+591 75140008 se unieron mediante el enlace de invitación__

[18:36] __+591 74519930 se unieron mediante el enlace de invitación__

[18:43] __+591 68749867 se unieron mediante el enlace de invitación__

[18:54] __+591 60262595 se unieron mediante el enlace de invitación__

[19:14] __+591 60268715 se unieron mediante el enlace de invitación__

[19:15] __+591 71868397 se unieron mediante el enlace de invitación__

[19:15] __Alguien añadió a +591 71868397__

[19:17] __+591 72979828 se unieron mediante el enlace de invitación__

[19:22] __+591 60255251 se unieron mediante el enlace de invitación__

[19:32] __+591 76835242 se unieron mediante el enlace de invitación__

[19:47] __+591 69332895 se unieron mediante el enlace de invitación__

[20:05] **+591 78249245:** buenas noches

[20:05] **+591 78249245:** alguien sabe dónde están cargando gasolina ahora en la noche

[20:06] __Alguien añadió a +591 76835242__

[20:07] **+591 71875639:** En don daniel iba haber por la tarde

[20:24] **+591 73483881:** Sointa

[20:27] __+591 75149508 se unieron mediante el enlace de invitación__

[20:48] __+591 78229658 se unieron mediante el enlace de invitación__

[21:07] **+591 67995662:** [Mensaje de voz]

[21:22] **+591 67995662:**
> _+591 67995662: Mensaje de voz_
.

[22:21] __+591 72973940 se unieron mediante el enlace de invitación__

[22:59] __+591 60258982 se unieron mediante el enlace de invitación__

---

## 12 de agosto de 2026

[1:39] __+591 77873163 se unieron mediante el enlace de invitación__

[2:20] __+591 75122143 se unieron mediante el enlace de invitación__

[4:25] __+591 72790204 se unieron mediante el enlace de invitación__

[4:25] __Alguien añadió a +591 72790204__

[5:10] __+591 72985600 se unieron mediante el enlace de invitación__

[5:10] __Alguien añadió a +591 72985600__

[5:50] __+591 60727116 se unieron mediante el enlace de invitación__

[6:01] __+591 68717700 se unieron mediante el enlace de invitación__

[6:02] **+591 68717700:** Buen día

[6:02] **+591 68717700:** Gracias por agregarme

[6:02] __Alguien añadió a +591 68717700__

[6:29] __+591 68739965 se unieron mediante el enlace de invitación__

[7:01] __+591 63970705 se unieron mediante el enlace de invitación__

[7:07] __+591 72994627 se unieron mediante el enlace de invitación__

[7:11] __+591 69302521 se unieron mediante el enlace de invitación__

[7:27] **+591 68702338:** Buen dia a todos, una consulta, en q surtidores están cargando gasolina

[7:47] __+591 70221685 se unieron mediante el enlace de invitación__

[7:47] __Alguien añadió a +591 70221685__

[7:47] **+591 68697122:** Alguien sabe en qué surtidor hay etanol

[7:48] __+591 74673073 se unieron mediante el enlace de invitación__

[7:50] __+591 69305929 se unieron mediante el enlace de invitación__

[7:58] **+591 69331405:** No hay gasolina. 
Fila en todos los surtidores.

[7:58] **+591 69331405:** Qlp

[8:02] __+591 77172140 se unieron mediante el enlace de invitación__

[8:02] **+591 63780494:** Las vegas
Sointa
Tacuarandi
San jorge
Portillo

Están todos con conos no están atendiendo todavia

[8:04] **+591 68717700:** Si no hay gasolina nose cuando habrá la verdad es fregada la cosa

[8:15] __+591 75155112 se unieron mediante el enlace de invitación__

[8:15] __Alguien añadió a +591 75155112__

[8:15] __+591 63648379 se unieron mediante el enlace de invitación__

[8:18] **+591 74670785:** Donse hay  gasolina

[8:19] __+591 60277162 se unieron mediante el enlace de invitación__

[8:19] **+591 63797053:** Gasolina especial dnd hay

[8:19] **+591 67995662:** [Mensaje de voz]

[8:19] **+591 63797053:** xf

[8:19] __+591 69310319 se unieron mediante el enlace de invitación__

[8:21] **+591 67995662:** [Video]

[8:23] **+591 69327934:**
> _+591 67995662: Mensaje de voz_
Hay etanol

[8:23] **+591 69327934:** ?

[8:25] **+591 72949826:** Hola buen día dónde hay gasolina especial

[8:26] **+591 63797053:** [Sticker]

[8:40] **+591 72964737:** grave í

[8:40] **+591 69327934:** Etanol

[8:40] **+591 69327934:** Alguien sabe

[8:40] **+591 69327934:** En qué gasolinería hay

[8:43] **+591 68719052:** En el tarija hay fila pero vaya saber para que tipo de gasolina es

[8:43] **+591 75118556:** [Imagen] 🎬🔥 STREAMING PREMIUM PARA TU HOGAR 🔥🎬
El mejor entretenimiento, sin cortes ni complicaciones 📺✨
Disfruta de tus plataformas favoritas 👇
✅ Netflix
✅ Disney+
✅ HBO Max
✅ Paramount+
✅ Prime Video
✅ Crunchyroll
✅ YouTube Premium
✅ Spotify Premium
✅ Flujo TV
🎯 Series, películas, anime, deportes, música y TV en vivo
🚀 Activación rápida
🏠 Ideal para toda la familia
📲 Pedidos y consultas por WhatsApp:
👉 75118556
🔥 Convierte tu casa en un cine hoy mismo 🔥

[8:43] **+591 75118556:** [Imagen] 🚀 ¡Haz crecer tus redes sociales como un profesional! 📈
¿Quieres más alcance, más clientes y una imagen de autoridad?
✅ Seguidores para Facebook, Instagram y TikTok.
✅ Likes para Facebook e Instagram. (No ofrecemos likes para TikTok).
✅ Vistas para tus videos.
⚡ Entrega rápida.
🔒 Servicio seguro y confidencial.
💬 Atención personalizada.
📲 Escríbeme ahora por WhatsApp: 75118556
Impulsa tu marca, aumenta tu credibilidad y destaca frente a tu competencia. ¡Es momento de llevar tus redes al siguiente nivel!
#MarketingDigital #RedesSociales #Instagram #Facebook #TikTok #Seguidores #Vistas #ImpulsaTuMarca

[8:48] __+591 61858648 se unieron mediante el enlace de invitación__

[8:49] __Alguien añadió a +591 61858648__

[9:00] __+591 78706211 se unieron mediante el enlace de invitación__

[9:05] __+591 72908667 se unieron mediante el enlace de invitación__

[9:06] __+591 64583312 se unieron mediante el enlace de invitación__

[9:07] **+591 60256352:** Buen día no saben dónde hay etanol

[9:30] __+591 72964548 se unieron mediante el enlace de invitación__

[9:46] __+591 62620320 se unieron mediante el enlace de invitación__

[9:54] __+591 67388953 se unieron mediante el enlace de invitación__

[9:55] __Alguien añadió a +591 67388953__

[10:43] **+591 69327934:** O especial

[10:52] __+591 67377962 se unieron mediante el enlace de invitación__

[10:54] **+591 63774897:** Buenas disculpe saben dónde ay gasolina y no ah mucha fila?

[11:23] __+591 60250385 se unieron mediante el enlace de invitación__

[11:24] __+591 71867314 se unieron mediante el enlace de invitación__

[11:59] __+591 68684009 se unieron mediante el enlace de invitación__

[11:59] __Alguien añadió a +591 68684009__

[12:16] **+591 78706211:** Saben si hay gasolina en la ex terminal

[12:16] **+591 78706211:** ?

[12:16] **+591 72908667:**
> _+591 78706211: Saben si hay gasolina en la ex terminal_
Si, había, yo cargue hace ratitos

[12:17] **+591 78706211:**
> _+591 72908667: Si, había, yo cargue hace ratitos_
La fila está larga?

[12:17] **+591 64583312:** Especial donde

[12:17] **+591 72908667:**
> _+591 78706211: La fila está larga?_
Habia fila, pero avanzaba rápido

[12:20] **+591 68705100:** Estimados hay a la venta los últimos 60 litros de gasolina premium 98 octanos a 13.50 el litro(gasolina Brasilera)
Gasolina de alto rendimiento y calidad
El miércoles nos llega el otro sisterna (1200 LTS)

[12:20] **+591 67995662:** Abre este enlace para unirte a mi grupo de WhatsApp: https://chat.whatsapp.com/Kaaw4UZwAcNAuM3RQUFpEv?s=sw&p=a&mlu=4

[12:20] __+591 70238365 se unieron mediante el enlace de invitación__

[12:21] **+591 70238365:** En que surtidor estan cagando gasolina

[12:21] **+591 71203130:**
> _+591 70238365: En que surtidor estan cagando gasolina_
Surtidor Tarija

[12:22] **+591 71203130:** Cola de unos 30 vehiculos

[12:22] __+591 63785960 se unieron mediante el enlace de invitación__

[12:23] __+591 67375838 se unieron mediante el enlace de invitación__

[12:24] **+591 69310319:** En el agrupa hay poca fila

[12:24] **+591 69310319:** _Se eliminó este mensaje_

[12:24] __+591 60273491 se unieron mediante el enlace de invitación__

[12:24] **+591 69310319:** Y hay especial

[12:24] **+591 60256352:**
> _+591 69310319: En el agrupa hay poca fila_
En agrupa hay la especial o etanol

[12:25] **+591 70238365:**
> _+591 69310319: Y hay especial_
.

[12:25] **+591 69310319:** Especial yo cargué ya

[12:26] **+591 75127881:** Alguien sabe donde hay gasolina etanol?

[12:29] __+591 64691610 se unieron mediante el enlace de invitación__

[12:29] __+591 73453434 se unieron mediante el enlace de invitación__

[12:29] __Alguien añadió a +591 64691610__

[12:33] __+591 61861438 se unieron mediante el enlace de invitación__

[12:34] __+591 74541389 se unieron mediante el enlace de invitación__

[12:37] __+591 63587835 se unieron mediante el enlace de invitación__

[12:38] __+591 74822182 se unieron mediante el enlace de invitación__

[12:38] __+591 73486458 se unieron mediante el enlace de invitación__

[12:42] __+591 65811282 se unieron mediante el enlace de invitación__

[12:44] __+591 67905098 se unieron mediante el enlace de invitación__

[12:44] __+591 72949262 se unieron mediante el enlace de invitación__

[12:44] __+591 73458429 se unieron mediante el enlace de invitación__

[12:50] __+591 63787432 se unieron mediante el enlace de invitación__

[12:51] __+591 73482336 se unieron mediante el enlace de invitación__

[12:52] __+591 75114009 se unieron mediante el enlace de invitación__

[12:55] __+591 78343048 se unieron mediante el enlace de invitación__

[12:55] __+591 71195758 se unieron mediante el enlace de invitación__

[12:59] __+591 67391036 se unieron mediante el enlace de invitación__

[13:02] __+591 68707751 se unieron mediante el enlace de invitación__

[13:03] __+591 64695398 se unieron mediante el enlace de invitación__

[13:04] **+591 64695398:** Saben dónde hay gasolina y que carguen en bidón?

[13:04] **+591 64695398:** Por favor

[13:05] __+591 69327766 se unieron mediante el enlace de invitación__

[13:06] __+591 63774712 se unieron mediante el enlace de invitación__

[13:08] __+591 73494410 se unieron mediante el enlace de invitación__

[13:09] **+591 75146448:** Donde hay gasolina especial

[13:09] **+591 75146448:** Alguien sabe pofavor

[13:10] **+591 70238365:** [Imagen] Tan cargando con vidon en el agrupa

[13:12] **+591 75146448:**
> _+591 70238365: Imagen: Tan cargando con vidon en el agrupa_
Es clarita

[13:12] **+591 75146448:** Me dijeron que era plus

[13:15] **+591 67963233:** Alguien sabe donde hay poca fila

[13:16] **+591 70238365:** Agrupa

[13:19] __+591 62980357 se unieron mediante el enlace de invitación__

[13:21] __+591 60272478 se unieron mediante el enlace de invitación__

[13:30] __+54 9 3875 03-0038 se unieron mediante el enlace de invitación__

[13:32] __+591 68857300 se unieron mediante el enlace de invitación__

[13:37] __+591 74525743 se unieron mediante el enlace de invitación__

[13:38] __Alguien añadió a +591 74525743__

[13:40] __+591 61872201 se unieron mediante el enlace de invitación__

[13:42] **+591 74637856:** Estan vendiendo gasolina especial en la agrupa...??

[13:48] **+591 70238365:** Si

[13:49] __Navas se unieron mediante el enlace de invitación__

[13:50] __Alguien añadió a Navas__

[14:00] __+591 73455995 se unieron mediante el enlace de invitación__

[14:19] __+591 67381033 se unieron mediante el enlace de invitación__

[14:24] **+591 67963233:** En san geronimo

[14:24] **+591 67963233:** Quetal esta la fila

[14:24] **+591 67963233:** Alguien sabe

[15:12] __+591 79255883 se unieron mediante el enlace de invitación__

[15:18] __+591 72969146 se unieron mediante el enlace de invitación__

[15:32] **+591 69327934:** Gasolina especial

[15:32] **+591 69327934:** Dónde hay

[15:33] **+591 71867314:** Agrupa

[15:33] **+591 74540793:**
> _+591 71867314: Agrupa_
Que tan larga está la fila en agrupa?

[15:33] **+591 71867314:** Hace media hora volvió a entrar una sisterna

[15:33] **+591 71867314:**
> _+591 74540793: Que tan larga está la fila en agrupa?_
Está un poco pero avanza rápido

[15:34] **+591 71867314:** Pero si es para moto si o si con Bsisa en mano

[15:35] **+591 65800835:** [Imagen]

[15:35] **+591 71872723:** Que tal esta la gasolina de tacuarandi

[15:36] **+591 71872723:** ?????

[15:37] __+591 69324629 se unieron mediante el enlace de invitación__

[15:37] **+591 60253410:** Alguien sabe dónde ay etanol

[15:38] **+591 75127881:**
> _+591 60253410: Alguien sabe dónde ay etanol_
Sointa

[15:38] **+591 60268715:** Tacuarandi no hay

[15:41] **+591 65800835:** En agrupa hay plus y etanol

[15:42] **+591 71195758:** Donde hay especial

[15:42] **+591 68289593:** 🤝

[15:59] **+591 67963233:** En san martin

[15:59] **+591 67963233:** Hay gasolina?

[15:59] **+591 67963233:** Alguien sabe

[16:00] **+591 67591385:** Ok

[16:00] **+591 67591385:** Ok

[16:04] **+591 60274507:** Si hay en san martin

[16:04] **+591 60274507:** La especial

[16:06] **+591 68684009:**
> _+591 60274507: Si hay en san martin_
Seguro q es especial..una ves me vendieron roja esa gasolina

[16:07] **+591 60274507:** Asi cargue hace rato

[16:07] **+591 60274507:** Especial

[16:08] **+591 79255883:** Hay fila en san Martín?

[16:09] __+591 76805237 se unieron mediante el enlace de invitación__

[16:14] **+591 67963233:** En camin9

[16:14] **+591 67963233:** A san marti

[16:19] **+591 68717611:** Buenas tardes

[16:19] **+591 68717611:** Quería saber en qué surtidor hay gasolina

[16:19] **+591 68717611:** Cualquiera justo estoy con poca gasolina

[16:19] __+591 65825016 se unieron mediante el enlace de invitación__

[16:19] **+591 79255883:**
> _+591 68717611: Quería saber en qué surtidor hay gasolina_
San Martín aún hay

[16:20] **+591 68717611:** Voy gracias

[16:28] **+591 71872723:** SOINTA no esta muy larga la cola y solo hay etanol

[16:32] **+591 76195199:**
> _+591 79255883: San Martín aún hay_
Es especial ?

[16:33] **+591 69913636:** Ya no hay Gasolina en la Ana Martín

[16:33] **+591 75129306:** Quien dijo

[16:34] **+591 68717611:** Se acaba de terminar en el Tarija

[16:34] **+591 68717611:**
> _+591 75129306: Quien dijo_
Acabo de llegar y se acabo

[16:34] **+591 68717611:** O saben dónde hay, justo estoy con el tanque rojo

[16:36] **+591 67963233:** En donde hay gasolina a esta hora?

[16:36] **+591 75129306:** En el rancho

[16:36] **+591 75129306:** Ta vacío nomas

[16:36] **+591 75186906:** Alguien sabe donde hay gasolina clarita

[16:38] **+591 67963233:** En la ciudad no saben donde hay gasolina

[16:39] **+591 74525743:** Alguien sabe quién vende gasolina

[16:39] **+591 67963233:**
> _+591 75129306: En el rancho_
Podria ser.. pero es lejitos

[16:39] **+591 67963233:** Alguien sabe donde hay gasolina

[16:42] **+591 64583312:** Buenas tardes, alguien quiere realizarse una corona dental

[16:43] **+591 67392004:** Moto Méndez hay gasolina y sin fila

[16:43] **+591 71875639:**
> _+591 64583312: Buenas tardes, alguien quiere realizarse una corona dental_
Yo kiero limpieza

[16:43] **+591 60268715:** Xterminal hay todavía

[16:44] **+591 68717611:**
> _+591 60268715: Xterminal hay todavía_
Gasolina? O etanol

[16:49] **+591 71872024:** Alguien sabe si sigue hay gasolina en la San Martin

[16:50] __+591 77547274 se unieron mediante el enlace de invitación__

[17:02] **+591 60268715:**
> _+591 68717611: Gasolina? O etanol_
Plus

[17:02] **+591 75129306:** Qetal es esa plus

[17:02] **+591 71875639:** Dicen q la plus ya esta llegando bien

[17:02] **+591 60268715:** Amarilla clarita

[17:03] **+591 71875639:** Alguien tuvo problema alguno

[17:03] **+591 60268715:** No hay mucha fila

[17:03] **+591 71875639:**
> _+591 60268715: Amarilla clarita_
Dnd

[17:03] **+591 60268715:** Xterminal

[17:15] __+591 75774536 se unieron mediante el enlace de invitación__

[17:20] **+591 73483881:** 🤔 por qué hay fila en las gasolineras.. se acabará o subirá ?

[17:22] **+591 71894444:** Ninguno
Solo que la mayoría de los surtidores carga en la mañana así que es más seguro cargar por la tarde en cualquier surtidor

[17:24] **+591 67905098:**
> _+591 71894444: Ninguno
Solo que la mayoría de los surtidores carga en la mañana así que es más seguro cargar por la tarde en cualquier surtidor_
?

[17:25] **+591 61861438:** Alguien sabe dónde hay gasolina a estas horas

[17:25] **+591 61861438:** ?

[17:26] **+591 67905098:** En el portillo pero está larga la fila

[17:27] **+591 69310319:** En el surtidor de campe hay en las mañana y para vacioy

[17:27] __+591 67771469 se unieron mediante el enlace de invitación__

[17:28] **+591 72949929:**
> _+591 69310319: En el surtidor de campe hay en las mañana y para vacioy_
Buenas tardes hoy cargué la plus

[17:31] **+591 67591385:** [Mensaje de voz]

[17:42] __+591 72907123 se unieron mediante el enlace de invitación__

[17:43] __Alguien añadió a +591 72907123__

[18:02] **+591 63504498:** Dónde puedo conseguir gasolina ahorita

[18:03] **+591 60279821:** [Imagen]

[18:03] **+591 60279821:** En la ex terminal

[18:10] **+591 75138091:** _Se eliminó este mensaje_

[18:13] __+591 67962338 se unieron mediante el enlace de invitación__

[18:14] __Alguien añadió a +591 67962338__

[18:20] **+591 71872723:** Acaban de descargar etanol en Sointa

[18:20] **+591 71872723:** Fila de unas 2 cuadras

[18:28] __+591 67992060 se unieron mediante el enlace de invitación__

[18:53] **+591 71195758:** Donde mas hay

[18:53] **+591 71195758:** Gasolina

[18:54] __+591 76174998 se unieron mediante el enlace de invitación__

[18:57] **+591 61862568:** Alguien sabe si hay gasolina en el surtidor Tarija...???

[18:57] **+591 76174998:**
> _+591 61862568: Alguien sabe si hay gasolina en el surtidor Tarija...???_
No hay

[18:58] **+591 67963233:**
> _+591 71872723: Acaban de descargar etanol en Sointa_
Esta larga la fila

[18:58] **+591 61862568:**
> _+591 76174998: No hay_
Gracias

[19:00] **+591 76174998:** Alguien sabe dónde mañana habrá gasolina especial?

[19:08] **+591 71195758:** Don daniel llego etanol

[19:18] **+591 64695398:** Saben dónde hay gasolina?

[19:18] __+591 75136530 se unieron mediante el enlace de invitación__

[19:29] **+591 71195758:**
> _+591 64695398: Saben dónde hay gasolina?_
Don daniep etanol

[19:29] **+591 71195758:** Agrupa  plus y etanol

[19:29] **+591 71195758:** Ex terminal  plus creo

[19:29] **+591 71195758:** Campesino

[19:29] **+591 71195758:** Plusa

[19:57] __+591 69324499 se unieron mediante el enlace de invitación__

[19:57] __Alguien añadió a +591 69324499__

[19:57] **+591 60263311:** H

[20:07] **+591 72960822:** Hay gasolina en el Portillo, pero la fila está larga

[20:21] **+591 68717611:**
> _+591 72960822: Hay gasolina en el Portillo, pero la fila está larga_
Eso es del gas amigo

[20:27] **+591 72964548:** [Mensaje de album]

[20:27] **+591 72964548:** [Imagen]

[20:27] **+591 72964548:** [Imagen]

[20:27] **+591 72964548:** [Imagen]

[20:27] **+591 72964548:** [Imagen]

[20:27] **+591 72964548:** Buenas noches amigos por si tienen algun amigo o familiar que esté buscando turbante de chuncho en 600bs mas su caja pluma semi natural tamaño adulto

[21:17] **+591 61861438:** Alguien sabe dónde hay gasolina a estas horas

[21:18] **+591 74541389:** Exterminal etanol

[21:23] **+591 68717700:** Aquí en el mastil millonario hay

[21:23] **+591 68717700:** Están vendiendo

[21:23] **+591 68717700:** Pero está larga cola

[21:38] **+591 69310319:** En el agrupa seguían vendiendo

[21:45] **+591 63787432:**
> _+591 61861438: Alguien sabe dónde hay gasolina a estas horas_
No nadie sabe

[21:47] **+591 61861438:** Okis

[21:48] **+591 74541389:** Jjajjajaja

[22:09] __+591 77179760 se unieron mediante el enlace de invitación__

[23:50] __+591 64709974 se unieron mediante el enlace de invitación__

---

## 13 de agosto de 2026

[0:23] __+591 64473775 se unieron mediante el enlace de invitación__

[0:24] __Alguien añadió a +591 64473775__

[2:04] **+591 68702338:** Buen dia a todos, una consulta, en q surtidores están cargando gasolina

[6:35] **+591 67905098:** [Mensaje de voz]

[6:37] __+591 64325441 se unieron mediante el enlace de invitación__

[6:49] **+591 60256352:**
> _+591 67905098: Mensaje de voz_
Es la especial la clarita

[6:56] **+591 63787432:**
> _+591 67905098: Mensaje de voz_
Gracias

[7:00] **+591 63787432:** Sabe si cargan en bidón?

[7:01] **+591 63787432:**
> _+591 67905098: Mensaje de voz_
Ahí??

[7:13] **+591 63785960:** Buenos Dias gasolina clarita

[7:19] __+591 71224583 se unieron mediante el enlace de invitación__

[7:28] **+591 68680221:** Buen día dónde hay gasolina especial...???

[7:34] **+591 61861438:** Alguien q sepa donde están vendiendo en bidon

[7:43] **+591 64325441:**
> _+591 61861438: Alguien q sepa donde están vendiendo en bidon_
En la Ypf morros blancos

[7:44] **+591 61861438:** Posi pero está re larga la fila

[7:54] **+591 61861438:** [Imagen] YPFB

[8:02] **+591 71195758:**
> _+591 61861438: Imagen: YPFB_
Avisa puess

[8:02] **+591 71195758:** [Sticker]

[8:02] **+591 71195758:** Pa ir con mi media docena de bidones

[8:02] **+591 71195758:** Jajaja

[8:06] **+591 72942858:** [Mensaje de voz]

[8:08] **+591 60252340:** _Se eliminó este mensaje_

[8:11] **+591 63780494:** Portillo hay etanol

[8:19] **+591 67960504:** Buenos dias donde ay gasolina limpia

[8:32] __+591 72995800 se unieron mediante el enlace de invitación__

[8:33] __Alguien añadió a +591 72995800__

[9:24] **+591 61858648:** No saben si hay gaso especial o etanol en don Daniel ?

[9:26] **+591 60252340:** Agrupa hay etanol

[9:27] **+591 78702088:** En la ex terminal igual abia Etanol

[9:27] __+591 76188784 se unieron mediante el enlace de invitación__

[9:28] **+591 76188784:** Buenos días, alguien sabe enq surtidor están vendiendo gasolina especial?

[9:29] **+591 73458429:** Dónde esta la fila mas corta

[9:33] **+591 63794699:**
> _+591 73458429: Dónde esta la fila mas corta_
Ex terminal fila de tres cuadras

[9:51] __+591 72984358 se unieron mediante el enlace de invitación__

[9:52] __Alguien añadió a +591 72984358__

[9:59] **+591 68717611:** Alguien sabe si en San Jorge hay gasolina

[10:03] **+591 61861438:** Solo hay la plus en todo ello

[10:04] **+591 71894444:** Recién pasé por las Vegas y están aun descargando pero no me dijeron de cual es

[10:05] **+591 61861438:** La plus es acabo de cargar de ahí

[10:47] __+591 75142573 se unieron mediante el enlace de invitación__

[10:47] __+591 61820333 se unieron mediante el enlace de invitación__

[10:56] __+591 60274535 se unieron mediante el enlace de invitación__

[10:59] __+591 72963113 se unieron mediante el enlace de invitación__

[11:01] __Alguien añadió a +591 60274535__

[11:04] __+591 78237038 se unieron mediante el enlace de invitación__

[11:09] __+591 68908950 se unieron mediante el enlace de invitación__

[11:11] __Alguien añadió a +591 68908950__

[11:16] __+591 75140145 se unieron mediante el enlace de invitación__

[11:18] __+591 67396627 se unieron mediante el enlace de invitación__

[11:18] __+54 9 11 2669-5519 se unieron mediante el enlace de invitación__

[11:23] __+591 72977679 se unieron mediante el enlace de invitación__

[11:23] **+591 71875639:** Dnd hay gasolina clarita

[11:23] **+591 71875639:** Locos

[11:23] **+591 71875639:** Kien cargo

[11:26] **+591 67963233:** Buenas

[11:26] **+591 67963233:** Brotheres

[11:26] **+591 67963233:** Donde hay gasolina

[11:29] **+591 72977679:**
> _+591 71875639: Dnd hay gasolina clarita_
X2 xfa si alguien tiene el dato

[11:31] **+591 72990143:** Exterminal hay

[11:31] **+591 72990143:** [Imagen]

[11:31] **+591 72977679:** Especial o plus amigo?

[11:32] **+591 67963233:** En 28 minutos bajo

[11:32] **+591 72976766:** Plus

[11:34] **+591 67960504:** La plus q tal esta no esta amarilla

[11:38] **+591 71866559:** Todo ello hay plus nmas y igual con fila

[11:38] **+591 64325441:** que gente exigente  Diomio 
No les basta con que les avisen donde hay gasolina ⛽

[11:39] **+591 60251131:** [Sticker]

[11:42] **+591 69324499:** Por favor datos de En qué surtidores aún tengan gasolina ??

[11:43] **+591 67963233:**
> _+591 64325441: que gente exigente  Diomio 
No les basta con que les avisen donde hay gasolina ⛽_
Por eso

[11:43] **+591 67963233:** A estas alturas

[11:43] **+591 67963233:** Saber donde hay gasolina y fila corta ya es  mucha ayuda

[11:45] **+591 67905098:**
> _+591 64325441: que gente exigente  Diomio 
No les basta con que les avisen donde hay gasolina ⛽_
Nove 🤣

[11:46] **+591 69310319:** Surtidor agrupa

[11:47] **+591 64325441:**
> _+591 67905098: Nove 🤣_
Estés ya se pasan parece que quieren que le metan un trago para ver si sabe bien  si tiene gusto a gasolina ⛽ 😂😂😂

[11:48] **+591 71894444:** Pero que cuesta decir es la plus o la especial
Si ta están escribiendo que tanto puede quitarles escribir eso
Qlp los especiales, tanto los exigentes como los informantes

[11:54] __+591 76190902 se unieron mediante el enlace de invitación__

[11:55] **+591 60255251:** Surtidor terminal hay gasolina etanol, los trabajadores indica q ya está terminado, hasta las 2 a 3 posiblemente alcance... Los q están cerca alcanzan todavía

[11:57] **+591 67963233:**
> _+591 60255251: Surtidor terminal hay gasolina etanol, los trabajadores indica q ya está terminado, hasta las 2 a 3 posiblemente alcance... Los q están cerca alcanzan todavía_
Fila

[11:57] **+591 67963233:** De cuantas cuadras

[11:59] __+591 75138320 se unieron mediante el enlace de invitación__

[12:18] **+591 67963233:** Donde hay gasolinita

[12:21] **+591 67963233:** Hola

[12:21] **+591 75116516:** Se puede preguntar
Alguien si conoce, responderá 
Sean amables

[12:22] **+591 67963233:** Donde hay gasolina con fila corta

[12:22] **+591 67963233:** ?

[12:22] **+591 75127881:** Alguien sabe si hay etanol  en el Sointa

[12:26] **+591 60255251:** Buenas tardes a todos, una consulta, alguien sabe si está vendiendo gasolina especial en el surtidor del campesino?

[12:27] **+591 72977679:**
> _+591 60255251: Buenas tardes a todos, una consulta, alguien sabe si está vendiendo gasolina especial en el surtidor del campesino?_
Plus

[12:43] **+591 62630610:** Buenas tardes alguien sabe dónde hay gasolina especial con fila corta  porfavor ?

[12:46] **+591 70238365:** [Imagen]

[12:51] **+591 63648379:** Alguien sabe cuánto cuenta aproximadamente ponerle encendido a botón a la moto el mío pegasus a pura patada pero quisiera algo más cómodo , estará muy caro ??

[12:56] **+591 70238365:** 30 a 50 bs cuesta

[13:00] **+591 72994717:**
> _+591 63648379: Alguien sabe cuánto cuenta aproximadamente ponerle encendido a botón a la moto el mío pegasus a pura patada pero quisiera algo más cómodo , estará muy caro ??_
Tienes que comprarte batería pero están de 180 Bs. Para arriba si no me equivoco ... ahi esta el detalle ...

[13:19] **+591 75136530:** Surtidor ⛽ de la extranca libre sin fila atencion normal para gasolina

[13:20] **+591 71872024:**
> _+591 75136530: Surtidor ⛽ de la extranca libre sin fila atencion normal para gasolina_
No sabes que gasolina están dando ahi

[13:22] **+591 75136530:**
> _+591 71872024: No sabes que gasolina están dando ahi_
Eso sí que no sabría decirte , pero con lo escaso que está el combustible no está para escoger 🤷 la verdad no sé cuál es

[13:28] **+591 79256927:** Etanol o especial en q surtidor consigo porfa alguien q me de información le agradecería.

[13:38] **+591 71872024:** [Imagen] La plus en la ex tranca

[13:40] **+591 71872024:** [Imagen] No hay fila nada

[13:46] **+591 63648379:**
> _+591 72994717: Tienes que comprarte batería pero están de 180 Bs. Para arriba si no me equivoco ... ahi esta el detalle ..._
Total cuanto sería Masomeno? No tengo problema con el dinero pero quisiera saber un presupuesto exacto

[13:46] **+591 63648379:** No tengo el botón ni nada solo patada tengo que comprarle todo .

[14:02] __+591 72966030 se unieron mediante el enlace de invitación__

[14:05] **+591 60255251:** [Imagen] Agrupa todavía tiene gasolina etanol, las filas no están muy largo

[14:06] **+591 73483881:** En el tarija la fila está solamente una cuadra pero no sé si es la plus o la especial

[14:10] **+591 74541389:**
> _+591 73483881: En el tarija la fila está solamente una cuadra pero no sé si es la plus o la especial_
Plus

[14:10] **+591 74541389:** Ya pregunté

[14:12] **+591 68717700:** Cuánto es la plus y la etanol si alguien supiera gracias

[14:12] **+591 68717700:** ??

[14:14] **+591 74670785:** [Mensaje de voz]

[14:17] **+591 60255251:** Super etanol 92 está 8.28 bs y la gasolina premium plus o especial está 6.96 bs el litro

[14:28] __+591 78232878 se unieron mediante el enlace de invitación__

[14:28] **+591 75465137:** Alguien sabe si dónde don Daniel está larga la fila???

[14:30] __+591 65283317 se unieron mediante el enlace de invitación__

[14:56] **+591 73483881:**
> _+591 75465137: Alguien sabe si dónde don Daniel está larga la fila???_
No creo si solo hay la plus

[16:24] **+591 74534560:** Buenas tardes en el molle saben que gasolina están vendiendo por favor gracias

[16:28] **+591 62853115:** Plus

[16:28] **+591 74534560:**
> _+591 62853115: Plus_
Muchas gracias mi estimado

[16:54] **+591 71875639:** Dnd hay gasolina

[17:00] **+591 74534560:** Ay en el  TACUARANDI , Y P F B DE MORRO BLANCO,  SAN JORGE , LA EXTRANCA Y SOINTA pero la plus

[17:08] __+591 60267962 se unieron mediante el enlace de invitación__

[17:14] **+591 76193458:** Buenas tardes,disculpen me pueden informar en qué surtidor están vendiendo gasolina especial

[17:16] **+591 67905098:** [Video]

[17:16] **+591 67905098:** Sin fila

[17:37] __+591 71864343 se unieron mediante el enlace de invitación__

[17:38] __+591 68629856 se unieron mediante el enlace de invitación__

[17:46] **+591 74541389:** Portillo

[17:48] __+591 69330305 se unieron mediante el enlace de invitación__

[18:21] __+591 63695967 se unieron mediante el enlace de invitación__

[18:22] **+591 63695967:** _Se eliminó este mensaje_

[18:23] **+591 63695967:** Compañeros

[18:23] __[Llamada]__

[18:23] **+591 75129306:** Bloqeo

[18:23] **+591 63695967:** En que surtidor hay gaso

[18:35] **+591 74543937:** Exterminal de la plus

[19:06] __+591 76194463 se unieron mediante el enlace de invitación__

[19:26] __+591 74537076 se unieron mediante el enlace de invitación__

[19:59] **+591 64318534:** En el surtidor don daniel no hay gasolina ni especial ni la plus solo etanol resien estoy cargando y no hay fila

[20:22] **+591 71894444:** Hay gasolina en algún surtidor a esta hora!?

[20:23] **+591 71868397:** Moto mendez

[20:24] **+591 71894444:** Donde que da

[20:24] **+591 71894444:** Por favor

[20:24] **+591 71868397:** Carretera a san lorenzo

[20:24] **+591 76194463:** Carretera san Lorenzo

[20:25] **+591 71894444:**
> _+591 71868397: Carretera a san lorenzo_
Gracias

[20:25] **+591 67392004:** Agrupa hay pero con fila

[20:26] **+591 75515740:** Surtidor YPFB hay  la plus no hay fila

[20:26] **+591 71894444:** En morros blancos?

[20:26] **+591 75515740:** Si

[20:26] **+591 71894444:** Gracias

[20:26] **+591 75515740:** Morros Blancos

[20:27] **+591 75515740:** El portillo tiene  cero fila

[20:27] **+591 75515740:** Hay gasolina 
Péro no se cual

[20:28] **+591 76174998:** No saben si mañana igual tendrá  Daniel la Etanol ?

[20:34] **+591 71894444:** En sointa estoy cargando
Tiene la plus

[20:36] **+591 71894444:** Y confirmo que no es la amarilla oscura qué se venía vendiendo, esta más clara pero aún siguen vendiendo como la us

[20:39] **+591 72940584:** En agrupa hay etanol

[20:57] **+591 75129306:** Al final cuál sirve

[20:57] **+591 75129306:** 🤔

[21:01] **+591 72999358:**
> _+591 71894444: Y confirmo que no es la amarilla oscura qué se venía vendiendo, esta más clara pero aún siguen vendiendo como la us_
👀

[21:15] __+591 70235075 se unieron mediante el enlace de invitación__

[21:21] **+591 68746056:** Surtidor tacuarandi hay gasolina plus

[21:21] **+591 68746056:** Yo acabo de cargar

[21:21] **+591 68746056:** No hay fila

[21:26] **+591 74525743:** Gracias

[21:29] **+591 63774897:** Gracias

[21:29] **+591 63774897:** Cargan en bidón?

[21:46] **+591 68746056:**
> _+591 63774897: Cargan en bidón?_
Sii

---

## 14 de agosto de 2026

[6:20] __+591 69334388 se unieron mediante el enlace de invitación__

[6:40] **+591 72995800:** Buenos días 
Alguien me podría decir dónde hay gasolina

[6:45] **+591 67905098:** [Mensaje de voz]

[6:45] **+591 72995800:** Muchas gracias

[6:46] **+591 76174998:**
> _+591 72995800: Buenos días 
Alguien me podría decir dónde hay gasolina_
En Daniel tiene etanol y dijo que le llegara la especial

[7:32] __+591 68692961 se unieron mediante el enlace de invitación__

[7:34] **+591 71195758:**
> _+591 76174998: En Daniel tiene etanol y dijo que le llegara la especial_
Que hora ya estara  repartie do no ssben

[8:02] **+591 72994627:** _Se eliminó este mensaje_

[8:23] **+591 67960504:** Buenos dias donde ay gasolina limpia

[8:26] **+591 71195758:** Ypfv dijeron creo y don daniel no se ssbe que hora  habra

[8:26] **+591 75186906:** Si porfa alguien q pase el dato

[8:27] **+591 72995800:** En YPFB está larga la fila?

[8:27] **+591 72995800:** Yo estoy en fila en la Exterminal y aún no están cargando

[8:27] **+591 69913636:** Buen día en la San Martín llego la especial acabo de cargar

[8:27] **+591 72995800:**
> _+591 69913636: Buen día en la San Martín llego la especial acabo de cargar_
Hay Fila?

[8:28] **+591 75186906:**
> _+591 69913636: Buen día en la San Martín llego la especial acabo de cargar_
Q tal esta la fila disculpa

[8:28] **+591 60267962:**
> _+591 69913636: Buen día en la San Martín llego la especial acabo de cargar_
La blanquita?

[8:29] **+591 72995800:**
> _+591 71195758: Ypfv dijeron creo y don daniel no se ssbe que hora  habra_
Alguien está en la fila de YPFB?
Está larga?

[8:30] **+591 72898019:**
> _+591 72995800: Alguien está en la fila de YPFB?
Está larga?_
Ypfb del campesino. No hay mucha fila

[8:33] **+591 71875639:**
> _+591 72898019: Ypfb del campesino. No hay mucha fila_
Clarita?

[8:35] __+591 64326376 se unieron mediante el enlace de invitación__

[8:40] __+591 75133705 se unieron mediante el enlace de invitación__

[8:48] __+591 78236750 se unieron mediante el enlace de invitación__

[9:07] __+591 75141556 se unieron mediante el enlace de invitación__

[9:23] **+591 64326376:** Buenos dias

[9:23] **+591 64326376:** Donde hay gasolina especial?

[9:24] **+591 60267962:** En la domingo sabio

[9:24] **+591 60267962:** Buen dia

[9:24] **+591 64326376:** Esta larga la fila?

[9:26] **+591 60267962:** Si

[9:26] **+591 64326376:** Gracias

[9:26] **+591 60267962:** 👍👍

[9:35] **+591 68717700:** [Imagen]

[9:35] **+591 68717700:** No hay fila en YPFB del campesino

[9:35] **+591 60267962:** Pero es la plus

[9:35] **+591 68717700:** Si

[9:36] **+591 67378876:**
> _+591 68717700: Imagen_
Especial???

[9:36] **+591 68717700:** Si

[9:36] **+591 67378876:**
> _+591 68717700: Si_
Buenísimo!! Gracias Hno

[9:37] **+591 61862568:** En el surtidor Tarija fila larga...

[10:02] **+591 74670785:** Disculpen la pregunta en el  capesino  hay gasolina  especial

[10:05] **+591 68717700:** Si hay

[10:05] **+591 68717700:** No hay fila casi nada

[10:07] **+591 72999358:** Alguien que esté en la fila del surtidor UPDS ?

(Adelante)

Sabe si todavía siguen vendiendo la gasolina especial?

[10:08] **+591 61862568:** Si hay pero esta re larga la fila

[10:15] **+591 76188784:** Buenos días, disculpe alguien sabe si llego gasolina especial en el surtidor del molle o Moto Méndez del Rancho?

[10:17] **+591 69312879:**
> _+591 76188784: Buenos días, disculpe alguien sabe si llego gasolina especial en el surtidor del molle o Moto Méndez del Rancho?_
Aun no llega

[10:18] **+591 78225036:** Buenos días alguien sabe si en los surtidores ypfb arce.tacuarandi.o del san Jorge hay gasolina especial gracias

[10:18] **+591 72999358:**
> _+591 76188784: Buenos días, disculpe alguien sabe si llego gasolina especial en el surtidor del molle o Moto Méndez del Rancho?_
Moto Mendez es la plus

[10:34] **+591 68705100:** Amigos donde puedo ir a cargar gasolina y q no haya mucha fila

[10:41] **+591 72995800:** En la Ex terminal no había mucha fila

[10:56] **+591 69312879:** Alguien sabe si en el surtidor moto mendez están vendiendo diésel

[10:57] __+591 78220474 se unieron mediante el enlace de invitación__

[10:57] **+591 69312879:** Aquí al molle aun no llega

[11:12] **+591 63504498:**
> _+591 72995800: En la Ex terminal no había mucha fila_
En la ex terminal es la especial?

[11:21] **+591 63504498:** Hay gasolina en el surtidor del campesino

[11:23] __Alguien añadió a +591 69334388__

[11:24] __+591 67995662 añadió a +591 75141556 y +591 78220474__

[11:24] __+591 72995800, +591 72908757 y +591 69302002 salieron__

[11:24] __Alguien añadió a +591 72995800__

[11:25] __+591 72995800 salieron__

[11:25] __Alguien añadió a +591 72995800__

[11:26] __+591 72995800 salieron__

[11:26] __Alguien añadió a +591 72995800__

[11:26] __+591 72995800 salieron__

[11:49] **+591 78225036:** Buenas saben si el surtidor Tarija sigue hay gasolina especial ?

[11:58] **+591 68717700:** Yo cargue frente el campesino en 10 minutos máximo no avía cola

[11:59] **+591 74544944:** Ya no hay especial en el campesino

[12:12] **+591 64338061:** Ahorita no saben donde hay gasolina pero que no haiga mucha fila porfavor?

[12:17] **+591 64315275:** Gasolina especial horita donde hay ?

[12:31] **+591 68707751:** Etanol ?

[12:31] **+591 63970705:** [Imagen]

[12:33] **+591 78225036:** Fila de una cuadra en el san martin

[12:35] **+591 74670785:** Donde hay gasolina especial

[12:35] **+591 74670785:** Porfis avicen

[12:47] **+591 78225036:** San martin

[12:47] **+591 78225036:** Pero con fila

[12:47] **+591 74525743:** Hay fila

[12:47] **+591 78225036:** Larga ahora

[13:20] **+591 71195758:** No estan cargando en bidon en don Daniel

[13:20] **+591 71195758:** Solo si estas en ciscargio

[13:24] **+591 75118556:** [Imagen] 🎬🔥 STREAMING PREMIUM PARA TU HOGAR 🔥🎬
El mejor entretenimiento, sin cortes ni complicaciones 📺✨
Disfruta de tus plataformas favoritas 👇
✅ Netflix
✅ Disney+
✅ HBO Max
✅ Paramount+
✅ Prime Video
✅ Crunchyroll
✅ YouTube Premium
✅ Spotify Premium
✅ Flujo TV
🎯 Series, películas, anime, deportes, música y TV en vivo
🚀 Activación rápida
🏠 Ideal para toda la familia
📲 Pedidos y consultas por WhatsApp:
👉 75118556
🔥 Convierte tu casa en un cine hoy mismo 🔥

[13:24] **+591 75118556:** [Imagen] 🚀 ¡Haz crecer tus redes sociales como un profesional! 📈
¿Quieres más alcance, más clientes y una imagen de autoridad?
✅ Seguidores para Facebook, Instagram y TikTok.
✅ Likes para Facebook e Instagram. (No ofrecemos likes para TikTok).
✅ Vistas para tus videos.
⚡ Entrega rápida.
🔒 Servicio seguro y confidencial.
💬 Atención personalizada.
📲 Escríbeme ahora por WhatsApp: 75118556
Impulsa tu marca, aumenta tu credibilidad y destaca frente a tu competencia. ¡Es momento de llevar tus redes al siguiente nivel!
#MarketingDigital #RedesSociales #Instagram #Facebook #TikTok #Seguidores #Vistas #ImpulsaTuMarca

[13:27] **+591 68700198:** ACABAN DE DESCARGAR GASOLINA ESPECIAL EN EL SURTIDOR DON DANIEL, AL MOMENTO Q LLEGUE CERO FILA

[13:29] **+591 68707751:**
> _+591 68700198: ACABAN DE DESCARGAR GASOLINA ESPECIAL EN EL SURTIDOR DON DANIEL, AL MOMENTO Q LLEGUE CERO FILA_
De verdad?

[13:35] **+591 75113568:**
> _+591 68700198: ACABAN DE DESCARGAR GASOLINA ESPECIAL EN EL SURTIDOR DON DANIEL, AL MOMENTO Q LLEGUE CERO FILA_
Disculpen No saben si venden en bidón

[13:36] **+591 71195758:**
> _+591 75113568: Disculpen No saben si venden en bidón_
Solo si estás  en ciscargio

[13:36] **+591 71195758:** Yo estoy pero no se que falta  me dijo no me cargo

[13:42] **+591 75113568:** Bueno gracias

[13:48] **+591 61862568:** Yo cargue en la ex terminal gasolina sin fila era la plus pero estaba clarita ...

[14:58] **+591 64315275:** Buenas tardes gasolina especial en don Daniel todavía hay

[15:00] **+591 64315275:** La fila no está tan larga

[15:11] **+591 68680221:**
> _+591 64315275: Buenas tardes gasolina especial en don Daniel todavía hay_
Cargan en bidón...???

[15:19] **+591 64315275:**
> _+591 68680221: Cargan en bidón...???_
No se nio vi

[15:19] **+591 64315275:** Pero hay de la especial y esta blanca

[15:26] **+591 75146873:** Buenas tardes disculpen alguien tiene gasolina en bidon para vender

[15:34] **+591 68680221:**
> _+591 64315275: Pero hay de la especial y esta blanca_
Gracias amigo

[15:54] **+591 72990143:** Exterminal venden en bidon

[15:54] **+591 72990143:** Fila muy corta hace una hora

[16:34] **+591 68717700:** En el mastil millonario igual está la cola cortisima

[16:34] **+591 68717700:** Creo q ya se normalizo la venta de gasolina

[16:34] **+591 73453128:** [Imagen]

[16:34] **+591 73453128:** [Mensaje de voz]

[16:34] **+591 73453128:** [Mensaje de album]

[16:35] **+591 73453128:** [Imagen]

[16:35] **+591 73453128:** [Imagen]

[16:40] **+591 71872723:** Precio y medidas

[16:45] **+591 73453128:** [Mensaje de voz]

[16:46] **+591 60262595:** [Imagen]

[16:48] **+591 73453128:** [Imagen]

[16:51] __+591 69840929 se unieron mediante el enlace de invitación__

[16:51] __Alguien añadió a +591 69840929__

[17:06] **+591 74525743:** Dónde hay gasolina disculpe chicos

[17:10] __+591 72947156 se unieron mediante el enlace de invitación__

[17:11] __Alguien añadió a +591 72947156__

[17:17] **+591 74521020:**
> _+591 74525743: Dónde hay gasolina disculpe chicos_
Don Daniel

[17:45] **+591 68717700:** En todo lado hay

[17:45] **+591 68717700:** Pero en el mastil no había fila

[17:51] **+591 67905098:** En el portillo san Jorge tacuarandi igual hay sin fila

[17:52] __+591 72997886 se unieron mediante el enlace de invitación__

[17:52] **+591 78702088:**
> _+591 73453128: Imagen_
Cm es posible tan caro

[18:00] **+591 75127124:** [Mensaje de voz]

[18:01] **+591 78225036:**
> _+591 67905098: En el portillo san Jorge tacuarandi igual hay sin fila_
Pero puro plus

[18:02] **+591 67905098:** Todas la misma huevada

[18:02] **+591 67905098:** Yo en todo el tiempo cargue sin elegir nunca se jodió mi auto

[18:02] **+591 68749557:** _Se eliminó este mensaje_

[19:17] **+591 74525743:** Hay gasolina en las Vegas pero es plus

[19:27] **+591 68707751:** En ypfb igual

[22:01] **+591 72985708:** Si en todos los surtidores hay la plus

[22:17] **+591 72975761:** Algún surtidor con gasolina especial

[22:28] **+591 75118556:** [Imagen] 🚀 Dale impulso a tu TikTok y haz crecer tu cuenta 🔥
¿Quieres más alcance, más interacción y que tu perfil se vea más activo? 👀📲
✅ Seguidores reales para aumentar tu presencia
❤️ Likes para que tus videos se vean más virales
👁️ Vistas para impulsar tu contenido
🔄 Compartidos para llegar a más personas
💸 Precios accesibles
⚡ Entrega rápida
📩 Atención directa y segura
Haz que tu cuenta destaque y genera más confianza desde hoy 🔥
📲 Pedidos y consultas al: 75118556

---

## 15 de agosto de 2026

[2:49] **+591 60262595:** [Imagen]

[7:00] __+591 67909506 se unieron mediante el enlace de invitación__

[7:01] __Alguien añadió a +591 67909506__

[7:20] **+591 72945844:** En que surtidor hay gasolina especial, avisen

[7:22] **+591 67905098:**
> _+591 72945844: En que surtidor hay gasolina especial, avisen_
Buen día !! Porfavor!!!

[7:32] **+591 67968964:** Surtidor de San Jorge II

[7:33] **+591 78249245:**
> _+591 67968964: Surtidor de San Jorge II_
hay mucha fila???

[7:35] **+591 63970705:** [Imagen]

[7:50] **+591 72997886:**
> _+591 67968964: Surtidor de San Jorge II_
Buen dia seguro que hay especial confirme porfavor

[7:59] **+591 67968964:**
> _+591 78249245: hay mucha fila???_
Si casi 6 cuadras

[7:59] **+591 78249245:**
> _+591 67968964: Si casi 6 cuadras_
ufufu

[8:29] **+591 67967584:** Gasolina Plus en agrupa

[8:40] **+591 72945325:** Buen día no hay especial 😱🫪

[8:41] **+591 75113568:** Gasolina especial en el surtidor Tarija la fila unas 3 cuadras

[8:44] **+591 72997886:**
> _+591 75113568: Gasolina especial en el surtidor Tarija la fila unas 3 cuadras_
Donde queda ese surtidor porfavor

[8:44] **+591 75113568:** Puente San Martin

[8:47] **+591 72997886:**
> _+591 75113568: Puente San Martin_
Seguro hasta ayer había plus

[8:49] **+591 68717611:** Saben dónde puedo cargar con bidon

[9:00] **+591 75113568:** Puente San Martin hay la especial y cargan en bidón

[9:00] **+591 72997886:**
> _+591 75113568: Puente San Martin hay la especial y cargan en bidón_
Gracias

[9:12] **+591 62854311:** En las Vegas

[9:12] **+591 62854311:** Gasolina especial

[9:12] **+591 74525743:** Fila hay

[9:12] **+591 74525743:** ?

[9:13] **+591 62854311:** Poca fila

[9:13] **+591 74525743:** Gracias

[9:15] **+591 63795999:** [Imagen] Liquidación de repuestos bajaj etiqueta rosada solo por hoy .......al inbox

[9:34] **+591 69312879:** Buen día
Alguien sabe donde hay etanol

[11:27] __+591 70216466 se unieron mediante el enlace de invitación__

[11:27] __Alguien añadió a +591 70216466__

[11:43] __+591 63397967 se unieron mediante el enlace de invitación__

[12:27] **+591 63809912:** Buenos días donde hay gaso

[12:28] **+591 68717611:**
> _+591 63809912: Buenos días donde hay gaso_
Campesino

[12:28] __+591 73413189 se unieron mediante el enlace de invitación__

[12:34] **+591 69310319:** En en l agrupa hay con poca  fila

[12:36] **+591 74519930:** [Imagen]

[12:39] **+591 72963325:** [Imagen] Sointa

[14:33] **+591 67962583:** Buenas tardes alguien sabe que surtidor ahí gasolina

[14:37] **+591 79256927:**
> _+591 67962583: Buenas tardes alguien sabe que surtidor ahí gasolina_
Las Vegas especial y poca fila

[14:38] **+591 61861438:** Alguien sabe dónde estás vendiendo gasolina en bidón a esta hora

[14:43] **+591 72977230:**
> _+591 61861438: Alguien sabe dónde estás vendiendo gasolina en bidón a esta hora_
Las vegas

[14:44] **+591 61861438:** Copiado

[14:44] **+591 61861438:** [Sticker]

[15:13] **+591 73483881:** Surtidor Tarija

[15:14] **+591 72966160:** Las vegas no hay fila

[15:34] **+591 75186906:**
> _+591 72966160: Las vegas no hay fila_
Gracias bro

[15:35] **+591 74525743:** Yo cargue la especial hay en la Vegas pero en la mañana

[15:51] **+591 67381033:** Hay todavia en las vegas?

[15:55] **+591 72969146:**
> _+591 67381033: Hay todavia en las vegas?_
Si

[16:30] __+591 75117506 se unieron mediante el enlace de invitación__

[17:08] __+591 76197093 se unieron mediante el enlace de invitación__

[17:17] **+591 65811053:** Alguien sabe si donde don Daniel hay gasolina especial?

[17:17] **+591 65811053:** O en agrupa??

[17:29] **+591 77178786:** Si, tiene la especial hay poca fila, también está vendiendo Diésel

[17:30] **+591 68746056:**
> _+591 77178786: Si, tiene la especial hay poca fila, también está vendiendo Diésel_
En cuál surtidor

[17:30] **+591 68746056:** ??

[17:30] **+591 77178786:** Don Daniel

[17:30] **+591 77178786:** [Imagen]

[17:33] **+591 65811053:** Se agoto ahorita en las vegas

[17:43] **+591 74540793:** Saben si en don Daniel dejan cargar en bidón?

[17:46] **+591 77870087:**
> _+591 74540793: Saben si en don Daniel dejan cargar en bidón?_
No cargan en bidón

[17:48] **+591 74540793:**
> _+591 77870087: No cargan en bidón_
Gracias

[18:09] **+591 74525743:** Dónde hay gasolina chicos

[18:10] **+591 70235075:** Surtidor tarija vi q estaban asiendo fila

[18:13] **+591 61861438:**
> _+591 70235075: Surtidor tarija vi q estaban asiendo fila_
A q hora viste ?

[18:15] **+591 79256415:** Donde hay gasolina?

[18:18] **+591 74525743:** De don danil

[18:39] **+591 60251131:** Surtidor Tarija

[18:39] **+591 60251131:** [Imagen] Fila de 5 autos

[18:41] **+591 65283317:**
> _+591 60251131: Imagen: Fila de 5 autos_
Gasolina Especial mano?

[18:42] **+591 60251131:** Ni idea pero de qué hay gasolina hay gasolina😬

[18:43] **+591 60251131:** Cuando cargue te aviso cual es 😅

[18:44] **+591 63780494:** Don Daniel que gasolina hay

[18:44] **+591 63780494:** ??

[18:53] **+591 60251131:** [Imagen]

[18:53] **+591 60251131:** Es la Especial

[19:01] **+591 65283317:** Gracias bro.

[19:29] __+591 68489645 se unieron mediante el enlace de invitación__

[19:39] **+591 75186906:** Hay gssolina en la gasolinera de don daniel y no esta mucho la fila

[19:40] **+591 72955920:** Portillo.. especial..cero fila..tb en bidones

[19:42] **+591 72960135:**
> _+591 75186906: Hay gssolina en la gasolinera de don daniel y no esta mucho la fila_
La especial??

[19:46] **+591 75186906:** Si

[19:46] **+591 64301527:** Ya en ningún lado hay fila

[19:49] **+591 72955920:** Ojalá sea definitivo..

[19:53] **+591 72960135:** [Imagen] En el Surtidor Tarija (a lado de la Domingo Savio) también hay Gasolina Especial y no hay casi nada de fila

[19:56] **+591 75186906:**
> _+591 72960135: Imagen: En el Surtidor Tarija (a lado de la Domingo Savio) también hay Gasolina Especial y no hay casi nada de fila_
Ya se esta normalisando al parecer

[19:57] **+591 75186906:** En todas no hay mucha fila

[19:57] **+591 72960135:** Si aprovechen de cargar gasolina clara

[19:58] **+591 74541389:** Piden fotocopia de carnet

[19:58] **+591 74541389:** O me harán validar bsisa de mi moto para cargar en tacho

[20:03] **+591 75186906:** Fotocopia de carnet

[20:03] **+591 74541389:** Ya

[20:04] **+591 79256415:** Ex terminal hay

[20:04] **+591 74541389:**
> _+591 72960135: Imagen: En el Surtidor Tarija (a lado de la Domingo Savio) también hay Gasolina Especial y no hay casi nada de fila_
Ya iré a hacer cargar

[20:27] **+591 63787432:** Siguen cargando??

[20:33] **+591 74537707:** En el soyta estaban cargando pero con la tarjeta

[20:37] **+591 71894444:** En sointa hay clarita ola plus?

[20:37] **+591 78250221:** Tengan cuidado a mí me dijeron que era la especial y saqué un poco en botella y era la plusss nomas surtidor las vegas 📝

[20:38] **+591 78250221:** Era oscura la gasolina

[20:39] **+591 71894444:** Buenas noches
Gasolina especial en que surtidor hay en este momento?

[20:40] **+591 72949929:** Buenas noches en el Tarija y clarita está

[20:40] **+591 72949929:** Poca fila recién cargue

[20:42] **+591 71894444:** Gracias

[20:49] **+591 77175043:** Don Daniel sin fila

[20:49] **+591 77175043:** Gazolina especial

[20:59] **+591 76181373:** Q surtidor no piden tarjeta besisa para cargar disculpen

[21:01] **+591 71894444:** Aquí en el Tarija no están pidiendo y gasolina especial sin fila
Si hay son 4 o 5 autos

[21:05] **+591 76181373:** Ok gracias 👍

[21:39] **+591 72996308:** [Imagen]

[21:39] **+591 72996308:** No hay fila y gasolina especial hasta las 10 dijo bidon

[21:42] **+591 74541389:** Fotocopia?

[21:48] **+591 72996308:**
> _+591 74541389: Fotocopia?_
Necesario

[21:50] **+591 76181373:** En san Gerónimo cargue recién especial , sin fila

[22:52] **+591 60262595:** [Imagen]

[22:54] **+591 76174998:** Saben si hay especial

[22:54] **+591 76174998:** En Daniel ?

[22:55] **+591 77175043:**
> _+591 76174998: En Daniel ?_
Si especial habia hace rato

[22:55] **+591 76174998:** Bueno gracias

[22:56] **+591 75186906:** [Imagen]

[23:18] **+591 69315287:**
> _+591 77175043: Si especial habia hace rato_
Están vendiendo a esta hora

[23:18] **+591 69315287:** Disculpa

[23:19] **+591 76174998:** Si hay

[23:19] **+591 76174998:** Hace ratito cargué

---

## 16 de agosto de 2026

[6:07] __+591 72975812 se unieron mediante el enlace de invitación__

[7:20] **+591 67905098:** [Imagen] Sin fila agrupa

[7:24] **+591 69315287:** Ok gracias

[7:56] __+591 68696816 se unieron mediante el enlace de invitación__

[9:49] **+591 74525743:** Dónde gasolina especial?

[9:50] **+591 73140648:** Donde ay la especial

[9:50] **+591 73140648:** ?

[9:54] **+591 72693210:** Surtidor tacuarandi full especial

[9:54] **+591 72693210:** Cero fila hace 10 minutos cargue ahí

[9:58] **+591 78703080:** Tacuarandi  vacio esta no  hay filas

[9:58] **+591 78703080:** Arce   poca  fila

[10:33] **+591 75132621:** Buenas donde encuentro gasolina especial

[12:23] __Alguien añadió a +591 72975812__

[12:24] __+591 67394082 se unieron mediante el enlace de invitación__

[13:03] __+591 64311645 se unieron mediante el enlace de invitación__

[13:04] __Alguien añadió a +591 64311645__

[17:25] **+591 75794111:** Dónde hay gasolina ?

[17:25] **+591 75794111:** Pueden pasar el dato

[17:25] **+591 75794111:** Por favor

[17:54] __+591 63806816 se unieron mediante el enlace de invitación__

[20:37] **+591 74549616:** Alguien

[20:37] **+591 74549616:** Sabe dónde hay gasolina ahora

[20:38] **+591 74549616:** ??

[20:55] **+591 78706211:**
> _+591 74549616: Sabe dónde hay gasolina ahora_
En todas

[22:39] **+591 67382556:** No

[22:39] **+591 74525743:** No hay gasolina ningún lado

---

## 17 de agosto de 2026

[7:21] __+591 68742046 se unieron mediante el enlace de invitación__

[7:22] **+591 67905098:** Esta mañana pase por ypfb d parada Chaco estaba cargando

[8:05] **+591 74525743:** Buenas chicos

[8:06] **+591 74525743:** Dónde hay gasolina especial para cargar

[8:07] **+591 68717700:** En todo lado hay hoy

[8:07] **+591 74525743:** Gracias

[8:09] **+591 71875639:** Donde hay la especial

[8:09] **+591 73483881:** Si ya se normalizo

[8:11] **+591 75515740:** Buen día 
Alguien sabe en que surtidor hay gasolina especial ?

[8:12] **+591 64301527:** No lees

[9:14] **+591 71875639:** Dond hay gasolina

[9:14] **+591 71875639:** Especial

[10:19] **+591 75140604:** [Sticker]

[10:19] **+591 75140604:** Lean😁

[10:19] **+591 74525743:** Las vengas es plus por si la dudas

[10:20] **+591 74525743:** Lean pero

[10:20] **+591 74525743:** [Sticker]

[10:22] **+591 75515740:** Alguien sabe si hay Gasolina en Agrupa o YPFB del campesino?

[10:24] **+591 75515740:** Surtidor Don Daniel 
No hay gasolina
a la tarde habrá 2 de la tarde  Plus

[10:33] **+591 63780494:** En el panamericano hay la plus ojo

[12:29] __+591 75114138 se unieron mediante el enlace de invitación__

[13:00] **+591 75146448:** Hola buenas tardes

[13:00] **+591 75146448:** Alguien sabe donde hay gasolina especial

[13:00] **+591 75146448:** Porfavor

[13:06] **+591 72999358:** Moto mendez

[13:08] **+591 75118556:** [Imagen] 🚀 ¡Haz crecer tus redes sociales como un profesional! 📈
¿Quieres más alcance, más clientes y una imagen de autoridad?
✅ Seguidores para Facebook, Instagram y TikTok.
✅ Likes para Facebook e Instagram. (No ofrecemos likes para TikTok).
✅ Vistas para tus videos.
⚡ Entrega rápida.
🔒 Servicio seguro y confidencial.
💬 Atención personalizada.
📲 Escríbeme ahora por WhatsApp: 75118556
Impulsa tu marca, aumenta tu credibilidad y destaca frente a tu competencia. ¡Es momento de llevar tus redes al siguiente nivel!
#MarketingDigital #RedesSociales #Instagram #Facebook #TikTok #Seguidores #Vistas #ImpulsaTuMarca

[14:09] **+591 75146448:**
> _+591 72999358: Moto mendez_
Que surtidor?

[14:10] **+591 75146448:** Como se llama

[14:11] **+591 76836092:**
> _+591 75146448: Que surtidor?_
Moto Mendez pasando tomatitas

[14:25] **+591 71872024:** Surtidor don Daniel ya están dando la plus

[14:26] **+591 71872024:** [Imagen]

[14:40] **+591 71875639:** Especial?

[14:41] **+591 78706211:** Saben si hay gasolina en la Ex terminal?

[15:16] **+591 60255251:** [Imagen] Surtidor moto Mendez aún hay gasolina especial, poca fila, casi nada de fila ...

[15:23] __+591 70218076 se unieron mediante el enlace de invitación__

[15:32] __+591 60275451 se unieron mediante el enlace de invitación__

[15:34] **+591 71875639:**
> _+591 60255251: Imagen: Surtidor moto Mendez aún hay gasolina especial, poca fila, casi nada de fila ..._
Muy cerca

[15:37] **+591 75149463:** Surtidor panamericano,y de la ex terminal todo normal y sin filas

[15:37] **+591 71875639:**
> _+591 75149463: Surtidor panamericano,y de la ex terminal todo normal y sin filas_
Es la plus no

[15:45] **+591 63780494:** Portillo la plus tambien

[16:20] **+591 75152237:** Siguen vendiendo en bidón?

[16:20] **+591 75152237:** Buenas tardes

[16:32] **+591 75152237:** Quien tiene gasolina para vender

[16:32] **+591 75152237:** Imbox

[16:37] **+591 73486458:** Con el permiso del administrador del grupo, alguien sabe o tiene el contacto de algún contacto que quiera vender su garrafa de gas, si saben o quieren vender comunicarse a mi inbox

[17:08] __+591 76193125 se unieron mediante el enlace de invitación__

[17:19] __+591 69623125 se unieron mediante el enlace de invitación__

[18:05] **+591 67382556:** [Mensaje de voz]

[18:07] **+591 67382556:** _Se eliminó este mensaje_

[18:07] **+591 74537707:** Aquí no venden agua

[18:08] **+591 75118556:** [Imagen] 🚀 Impulsá tu Instagram al siguiente nivel. 📈✨
🔥 Seguidores, likes, vistas y compartidos a precios increíbles. 📲 Escribime al 75118556 y empezá a crecer hoy. 💙

[18:12] **+591 74525743:**
> _+591 67382556: Mensaje de voz_
[Sticker]

[18:30] **+591 73456067:** Buenas noches alguien sabe dónde hay gasolina?

[18:36] **+591 70218076:** En el surtidor don Daniel no hay fila

[18:47] **+591 75186906:** Ya esta normal en cualquier lado

[18:54] **+591 75117885:** A cuanto esta el diésel??

[18:55] **+591 75186906:** Eso si nose solo cargue gasolina

---

## 18 de agosto de 2026

[7:36] **+591 71875639:** Buenos dias donde hay gasolina especial

[7:54] **+591 63779256:** [Imagen]

[7:58] **+591 64301527:** Eso es nieve

[7:58] **+591 72978591:**
> _+591 63779256: Imagen_
Donde es ??

[8:01] **+591 72867582:**
> _+591 72978591: Donde es ??_
Iscayachi parrce

[8:03] **+591 72990143:** [Imagen] Buen día, ha nevado en Sama

[8:15] **+591 67382556:** _Se eliminó este mensaje_

[8:18] **+591 63779256:**
> _+591 67382556: Mensaje de voz_
[Sticker]

[8:18] **+591 60274507:** [Sticker]

[8:19] **+591 67375838:** Alguien sabe dónde hay gasolina

[8:27] **+591 71875639:**
> _+591 64301527: Eso es nieve_
No es empanada blankeada

[8:27] **+591 71875639:** 😂

[9:01] **+591 65818918:** Surtidor tarija hay gasolina poca fila

[9:15] **+591 71875639:**
> _+591 65818918: Surtidor tarija hay gasolina poca fila_
Especial

[9:15] **+591 71875639:** ?

[9:17] **+591 62855388:**
> _+591 67382556: Mensaje de voz_
Mierda Bolivia Bolivia... Jajajaja que la Fau al jurcio... Jajajaja

[9:18] **+591 72999358:** Surtidor Moto Mendez hay gasolina especial.

Por si alguien necesita

[9:27] **+591 68405155:**
> _+591 72999358: Surtidor Moto Mendez hay gasolina especial.

Por si alguien necesita_
Grupa igual

[9:28] **+591 71875639:**
> _+591 68405155: Grupa igual_
Agrupa hay especial?

[9:28] **+591 72962359:**
> _+591 72999358: Surtidor Moto Mendez hay gasolina especial.

Por si alguien necesita_
Dónde es??

[9:28] **+591 68405155:**
> _+591 71875639: Agrupa hay especial?_
Si

[9:31] **+591 71875639:** Gracias

[9:32] **+591 67382556:** [Mensaje de voz]

[9:38] **+591 57887437:**
> _+591 67382556: Mensaje de voz_
Más audios por javor

[9:39] **+591 57887437:**
> _+591 67382556: Mensaje de voz_
El equipo ganará para el siguiente partido

[9:41] **+591 67382556:** [Mensaje de voz]

[9:42] **+591 71875639:** Don orlando este grupo no es de la gremial

[9:43] **+591 73486458:** [Sticker]

[9:44] **+591 57887437:**
> _+591 71875639: Don orlando este grupo no es de la gremial_
No es de la gremial es de la primera A para ir a la Simón bolivar

[9:45] **+591 71875639:**
> _+591 57887437: No es de la gremial es de la primera A para ir a la Simón bolivar_
Seniors?

[9:47] **+591 57887437:**
> _+591 67382556: Mensaje de voz_
Si, esta bien,  jugará para la próxima,  jugará al arco

[9:49] **+591 57887437:**
> _+591 67382556: Mensaje de voz_
O en medio , o delantero quiere probar👍

[9:51] **+591 72998577:**
> _+591 71875639: Don orlando este grupo no es de la gremial_
[Sticker]

[10:01] **+591 72999358:**
> _+591 57887437: No es de la gremial es de la primera A para ir a la Simón bolivar_
[Video]

[10:01] **+591 72999358:** [Mensaje de unknown]

[10:12] **+591 72962359:** Alguien sabe si hay gasolina en la circunvalación y don Daniel porfa

[10:35] **+591 75127881:** Buenos días alguien  sabe si aun se puede comprar gasolina   en bidón solo con fotocopia  de carnet

[10:46] **+591 75152237:** Buen día se puede a las 1 en el surtidor de San Gerónimo

[10:47] **+591 71875639:** [Imagen]

[10:47] **+591 71875639:** Especial san geornimo

[10:47] **+591 60272671:**
> _+591 71875639: Especial san geornimo_
Hay arta fila ...?

[10:49] **+591 71875639:** Una cuadra

[10:49] **+591 71875639:** Maso

[10:55] **+591 73481309:**
> _+591 67382556: Mensaje de voz_
🤫

[11:19] **+591 69310319:** Alguien sabe que gasolina está en el agrupa

[11:21] **+591 72903627:** Anoche pregunté dijeron que Iván a vender la amarilla

[11:33] **+591 74541389:** [Reenviado] Estaciones de Servicio con Gasolina Especial
Moto Mendez
Agrupa
Sointa
Panamericano
Portillo
P.A. Arce
Las Americas

[12:07] **+591 72964737:** etanol alguin sabe dnd hay

[12:28] **+591 72943744:**
> _+591 72964737: etanol alguin sabe dnd hay_
Si por favor

[12:29] **+591 67963248:** Ok

[12:41] **+591 72990143:**
> _+591 63779256: Sticker_
[Sticker]

[13:02] **+591 75146448:**
> _+591 74541389: Estaciones de Servicio con Gasolina Especial
Moto Mendez
Agrupa
Sointa
Panamericano
Portillo
P.A. Arce
Las Americas_
Pregunte en la agrupa

[13:02] **+591 75146448:** Es la plus

[13:02] **+591 75146448:** Porque informan mal

[13:16] **+591 74541389:** Pero eso será en la semana

[13:16] **+591 74541389:** Ahorita no están todos con esa gasolina

[13:16] **+591 74541389:** Solo que llegaré la especial

[13:16] **+591 74541389:** Así me dijieron en mi otro grupo

[13:18] **+591 57887437:** Es mentira cada día cambian

[13:18] **+591 74541389:** Jajajjs

[13:18] **+591 74541389:** Pero por eso

[13:18] **+591 74541389:** Jajjajaja

[13:18] **+591 74541389:** Al rededor de la semana

[13:18] **+591 74541389:** Tendrán especial

[13:18] **+591 74541389:** Talvez tengan mañana

[13:18] **+591 74541389:** Talvez pasado

[13:20] **+591 73486458:** @~Nose Saquenlo del grupo por mentiroso

[13:20] **+591 73486458:** [Sticker]

[13:20] **+591 74541389:** Jajajaja

[13:20] **+591 74541389:** Que malo

[13:20] **+591 74541389:** 😔

[13:20] **+591 73486458:** Mentira fren jodita nomás era jsjsjsj

[13:21] **+591 74541389:** Jajajaja

[13:22] **+591 60251131:** [Imagen]

[13:22] **+591 60251131:** [Sticker]

[13:23] **+591 74541389:**
> _+591 60251131: Imagen_
JAJAJAJA

[13:23] **+591 74541389:** Eso eso

[13:23] **+591 74541389:** [Sticker]

[13:24] **+591 57887437:**
> _+591 74541389: Así me dijieron en mi otro grupo_
Seguro reenviaste lo que envía el viejito polémico de Carlos España. En su grupito.     Ese no sabe nada.  Desinforma nomas

[13:24] **+591 74541389:** Ni idea quien será ese

[13:25] **+591 74541389:** De un tal Sergio reenvié

[13:27] **+591 57887437:**
> _+591 74541389: Ni idea quien será ese_
[Imagen] De ahí sacaron Ese se inventa no se de dónde.    Mentira es desinforma nomas

[13:27] **+591 74541389:** Ahhhh

[13:28] **+591 74541389:** Debe ser

[13:28] **+591 74541389:**
> _+591 57887437: Imagen: De ahí sacaron Ese se inventa no se de dónde.    Mentira es desinforma nomas_
Igualito el mensaje

[13:28] **+591 57887437:** Es el mismo mensaje

[13:29] **+591 71875639:** Panamerica hay especial carge alas 11

[13:30] **+591 74418754:**
> _+591 75127881: Buenos días alguien  sabe si aun se puede comprar gasolina   en bidón solo con fotocopia  de carnet_
Alguien sabe donde venden solo con fotocopia? Por favor

[13:31] **+591 74541389:**
> _+591 57887437: Es el mismo mensaje_
Si pero no es del tipo

[13:31] **+591 74541389:**
> _+591 74418754: Alguien sabe donde venden solo con fotocopia? Por favor_
En el Tarija

[13:31] **+591 75186906:** Las vegas don daniel

[13:31] **+591 74541389:** Pero es plus

[13:32] **+591 74418754:** Gracias

[13:32] **+591 74418754:**
> _+591 74541389: En el Tarija_
En el tarija esta la especial?

[13:32] **+591 74541389:**
> _+591 74418754: En el tarija esta la especial?_
No

[13:32] **+591 74418754:** O en el de san geronimo no venden en bidón?

[13:32] **+591 74541389:** Plus

[13:33] **+591 74418754:**
> _+591 74541389: No_
👍🏻

[13:33] **+591 73486458:**
> _+591 60251131: Sticker_
[Sticker]

[13:44] **+591 69312879:** [Imagen]

[13:44] **+591 69312879:** Por Yunchara una intensa nevada

[13:48] **+591 79251139:** [Sticker]

[13:59] **+591 57887437:**
> _+591 71875639: No es empanada blankeada_
Ya vendrá el de poncho rojo.    Eso es nieve, dirá 😂

[14:03] **+591 57887437:** [Imagen]

[14:04] **+591 71875639:** X eso 😂hay taititu

[14:39] **+591 74525861:** Alguien cargo en las vegas

[14:41] **+591 74525861:** Saben que gasolina es

[14:42] **+591 63268696:**
> _+591 74525861: Alguien cargo en las vegas_
Plus

[14:42] **+591 74525861:** Ok gracias

[14:43] **+591 74525861:** No saben donde hay especial ahorita

[14:47] **+591 62853115:** Moto mendez

[14:48] **+591 74418754:** Alguien sabe si en el surtidor de san geronimo puedo cargar en bidon?

[14:48] **+591 74418754:** Con fotocopia

[15:01] **+591 60263311:** Siempre se podía. O desde cuándo restringieron

[15:01] **+591 65800835:**
> _+591 74525861: No saben donde hay especial ahorita_
En san geronimo especial poca fila

[15:02] **+591 74525861:**
> _+591 65800835: En san geronimo especial poca fila_
Es cerca del coliseo universitario???

[15:05] **+591 68697122:** Alguien sabe dónde hay etanol ?

[15:06] **+591 65800835:**
> _+591 74525861: Es cerca del coliseo universitario???_
Si

[15:13] __+591 76184876 se unieron mediante el enlace de invitación__

[16:27] **+591 69315287:** Alguien sabe donde hay gasolina

[16:27] **+591 69315287:** Agrupa

[16:27] **+591 71875639:** Panamericano

[16:30] **+591 69315287:** Ypfb verdad

[16:44] __+591 60264808 se unieron mediante el enlace de invitación__

[18:32] **+591 79251139:**
> _+591 65800835: En san geronimo especial poca fila_
[Sticker]

[18:34] **+591 78240922:** En el Daniel 5 gatos apenas

[18:35] **+591 79251139:**
> _+591 78240922: En el Daniel 5 gatos apenas_
Por si acaso hay Cargan en bidón ??

[18:36] **+591 72942858:**
> _+591 78240922: En el Daniel 5 gatos apenas_
Es la especial o la plus

[18:37] **+591 78240922:** Solo pase no tuve tiempo para preguntártelo 😁

[19:52] **+591 71875639:** [Mensaje de voz]

[19:58] **+591 74519930:** 👍👍

[22:26] __+591 73494718 se unieron mediante el enlace de invitación__

---

## 19 de agosto de 2026

[4:47] **+591 67995662:** Abre este enlace para unirte a mi grupo de WhatsApp: https://chat.whatsapp.com/Kaaw4UZwAcNAuM3RQUFpEv?s=sh&p=a&mlu=4

[5:23] __+591 72976386 se unieron mediante el enlace de invitación__

[5:32] __+591 69307872 se unieron mediante el enlace de invitación__

[5:47] __+591 73021895 se unieron mediante el enlace de invitación__

[6:15] __+591 64315170 se unieron mediante el enlace de invitación__

[6:30] __+591 74540036 se unieron mediante el enlace de invitación__

[6:43] __+54 9 2216 05-8369 se unieron mediante el enlace de invitación__

[6:43] __+591 74507730 se unieron mediante el enlace de invitación__

[6:47] __+591 67382432 se unieron mediante el enlace de invitación__

[6:48] __+591 72948767 se unieron mediante el enlace de invitación__

[6:54] __+591 71390714 se unieron mediante el enlace de invitación__

[7:03] __Alguien añadió a +591 72976386__

[7:03] __+591 67995662 añadió a +591 67382432, +591 71390714, +591 74507730, +54 9 2216 05-8369 y +591 72948767__

[7:03] __+591 76190876 salieron__

[7:10] __+591 67997705 se unieron mediante el enlace de invitación__

[7:18] __+591 75111184 se unieron mediante el enlace de invitación__

[7:18] __Alguien añadió a +591 75111184__

[7:56] __+591 67628237 se unieron mediante el enlace de invitación__

[7:58] __+591 78273084 se unieron mediante el enlace de invitación__

[7:59] **+591 72948767:** ⛽

[8:12] **+591 63780494:** Surtidor morros blancos YPFB sin fila y hay la especial

[8:23] **+591 71390714:** Muchas gracias por la información

[8:26] __+591 71872225 se unieron mediante el enlace de invitación__

[8:39] __+591 73453408 se unieron mediante el enlace de invitación__

[8:50] __+591 72991821 se unieron mediante el enlace de invitación__

[8:51] __Alguien añadió a +591 72991821__

[8:54] __+591 77875522 se unieron mediante el enlace de invitación__

[9:04] __+591 63561972 se unieron mediante el enlace de invitación__

[9:05] __Alguien añadió a +591 63561972__

[9:11] **+591 63793336:** Buen día 
Disculpen, alguien sabe donde regulan bien el gas? Motor grande, equipo de 3ra generación

[9:12] **+591 74525743:** Surtidor YPFB fila larga

[9:33] __+380 67 632 9713 se unieron mediante el enlace de invitación__

[9:38] **+380 67 632 9713:** [Mensaje de album]

[9:38] **+380 67 632 9713:** [Imagen] Hola, si te interesa invertir 50 Bs y recibir 2000 Bs, envíame un mensaje para empezar y obtener esa increíble ganancia en solo 5 minutos.💯💯💯

[9:38] **+380 67 632 9713:** [Imagen]

[9:38] **+380 67 632 9713:** [Imagen]

[9:38] **+380 67 632 9713:** [Imagen]

[9:38] **+380 67 632 9713:** [Video]

[9:38] **+380 67 632 9713:** [Mensaje de album]

[9:39] **+380 67 632 9713:** [Imagen] Hola, si te interesa invertir 50 Bs y recibir 2000 Bs, envíame un mensaje para empezar y obtener esa increíble ganancia en solo 5 minutos.💯💯💯

[9:39] **+380 67 632 9713:** [Imagen]

[9:39] **+380 67 632 9713:** [Imagen]

[9:39] **+380 67 632 9713:** [Imagen]

[9:39] **+380 67 632 9713:** [Video]

[9:39] **+380 67 632 9713:** [Mensaje de album]

[9:39] **+380 67 632 9713:** [Imagen] Hola, si te interesa invertir 50 Bs y recibir 2000 Bs, envíame un mensaje para empezar y obtener esa increíble ganancia en solo 5 minutos.💯💯💯

Juro ante Dios Todopoderoso que, si realmente estoy intentando engañarte o estafarte, que Dios Todopoderoso castigue a toda mi generación; que no viva para recoger los frutos de mi trabajo; que la muerte, la enfermedad, la decepción y el fracaso sean mi destino. Que así sea para mí, en el nombre de Jesús. Amén.🥳

[9:39] **+380 67 632 9713:** [Imagen]

[9:39] **+380 67 632 9713:** [Imagen]

[9:39] **+380 67 632 9713:** [Imagen]

[9:39] **+380 67 632 9713:** [Video]

[9:39] **+591 70238365:**
> _+380 67 632 9713: [album]_
🤔

[9:39] __+591 72998730 se unieron mediante el enlace de invitación__

[9:39] **+591 64301527:** Boten a esa hija de perra

[9:40] **+591 72998577:** verdad

[9:40] **+380 67 632 9713:**
> _+591 72998577: verdad_
Si

[9:40] **+380 67 632 9713:** _Un admin., +591 67995662, eliminó este mensaje._

[9:40] **+380 67 632 9713:** _Un admin., +591 67995662, eliminó este mensaje._

[9:40] **+380 67 632 9713:** _Un admin., +591 67995662, eliminó este mensaje._

[9:40] **+380 67 632 9713:** _Un admin., +591 67995662, eliminó este mensaje._

[9:40] **+380 67 632 9713:** _Un admin., +591 67995662, eliminó este mensaje._

[9:40] **+380 67 632 9713:** _Un admin., +591 67995662, eliminó este mensaje._

[9:45] **+591 78703080:** Al administrador  por fabor  eliminar este  tipo de  mensajes  puesto q el grupo   es  especifico

[9:48] **+591 71866332:** Esas cosas no se deben permitir en el grupo

[9:49] **+591 72960822:** Al administrador q eliminé este tipo de estafas, el grupo es para el carguio de gasolina

[9:50] **+591 72984358:** Buenos dias no saben enque surtidor  estaran repartiendo  gasolina especial

[9:57] **+591 72999358:** @~😀LUIS ANGEL😊

[9:58] **+591 74525743:** En el surtidor YPFB no es especial por si la dudas es plus

[9:58] **+591 74670785:** De  acuerdo eliminen a  esos

[10:01] **+591 73483881:**
> _+591 74525743: En el surtidor YPFB no es especial por si la dudas es plus_
Gracias

[10:08] __+591 63789296 se unieron mediante el enlace de invitación__

[10:23] __+591 73457052 se unieron mediante el enlace de invitación__

[10:24] __Alguien añadió a +591 73457052__

[10:33] **+591 73453408:**
> _+380 67 632 9713: [album]_
Esto es estafa mucho cuidado .

[10:44] **+591 67967073:** Champu papa aceite

[10:45] **+591 60272671:** Alguien sabe en que surtidor hay gasolina especial hay gasolina

[10:55] __+591 67378675 se unieron mediante el enlace de invitación__

[10:56] __Alguien añadió a +591 67378675__

[11:06] __+591 72948229 se unieron mediante el enlace de invitación__

[11:07] **+591 60272671:** [Imagen] Gaso Especial en el panamericano

[11:07] **+591 60272671:** [Mensaje de unknown]

[11:15] __+591 70228252 se unieron mediante el enlace de invitación__

[11:16] __+591 67377277 se unieron mediante el enlace de invitación__

[11:17] **+591 70228252:** Buen día disculpen alguien sabe donde están cargando con bidón?? Y donde hay gasolina??

[11:20] **+591 64709432:** saben si en las vegas hay gasolina especial?

[11:30] **+591 78249245:** alguien. sabe dónde hay gasolina especial

[11:32] **+591 64315275:**
> _+591 78249245: alguien. sabe dónde hay gasolina especial_
En la panamericano están diciendo

[11:40] **+591 71390714:** En YPFB hay cargue hace una hora  y para que dice que es plus vi que cargaron en bidón y era especial

[11:42] **+591 78225036:**
> _+591 71390714: En YPFB hay cargue hace una hora  y para que dice que es plus vi que cargaron en bidón y era especial_
Cuál ypfb del campesino o de la carcel???

[11:42] **+591 71390714:** El de la cárcel

[11:42] **+591 71390714:** La fila es larga pero avanza rápido

[11:43] **+591 71390714:** En efectivo tiene que ser el pago no aceptan QR

[11:44] **+591 71390714:** Muchos quedaron colgados por eso y tuvieron que salir de la fila

[12:01] **+591 78225036:** Mil gracias bro

[12:08] **+591 68697122:** Etanol alguien sabe don hay

[12:25] **+591 75130876:** _Se eliminó este mensaje_

[12:28] __+591 69324595 se unieron mediante el enlace de invitación__

[12:31] __+7 950 472-70-00 se unieron mediante el enlace de invitación__

[12:40] **+7 950 472-70-00:** [Mensaje de album]

[12:40] **+7 950 472-70-00:** [Imagen] Hola, si te interesa invertir 50 Bs y recibir 2000 Bs, envíame un mensaje para empezar y obtener esa increíble ganancia en solo 5 minutos.💯💯💯

[12:40] **+7 950 472-70-00:** [Imagen]

[12:40] **+7 950 472-70-00:** [Imagen]

[12:40] **+7 950 472-70-00:** [Imagen]

[12:40] **+7 950 472-70-00:** [Video]

[12:40] **+7 950 472-70-00:** [Mensaje de album]

[12:40] **+7 950 472-70-00:** [Imagen] Hola, si te interesa invertir 50 Bs y recibir 2000 Bs, envíame un mensaje para empezar y obtener esa increíble ganancia en solo 5 minutos.💯💯💯

[12:40] **+7 950 472-70-00:** [Imagen]

[12:40] **+7 950 472-70-00:** [Imagen]

[12:40] **+7 950 472-70-00:** [Imagen]

[12:41] **+7 950 472-70-00:** [Video]

[12:41] **+591 72998730:**
> _+7 950 472-70-00: [album]_
Borren ah esos numeros

[12:41] **+7 950 472-70-00:** [Mensaje de album]

[12:41] **+7 950 472-70-00:** [Imagen] Hola, si te interesa invertir 50 Bs y recibir 2000 Bs, envíame un mensaje para empezar y obtener esa increíble ganancia en solo 5 minutos.💯💯💯

Juro ante Dios Todopoderoso que, si realmente estoy intentando engañarte o estafarte, que Dios Todopoderoso castigue a toda mi generación; que no viva para recoger los frutos de mi trabajo; que la muerte, la enfermedad, la decepción y el fracaso sean mi destino. Que así sea para mí, en el nombre de Jesús. Amén.🥳

[12:41] **+7 950 472-70-00:** [Imagen]

[12:41] **+7 950 472-70-00:** [Imagen]

[12:41] **+7 950 472-70-00:** [Imagen]

[12:41] **+7 950 472-70-00:** [Video]

[12:41] **+7 950 472-70-00:** [Mensaje de album]

[12:41] **+7 950 472-70-00:** [Imagen] Hola, si te interesa invertir 50 Bs y recibir 2000 Bs, envíame un mensaje para empezar y obtener esa increíble ganancia en solo 5 minutos.💯💯💯

Juro ante Dios Todopoderoso que, si realmente estoy intentando engañarte o estafarte, que Dios Todopoderoso castigue a toda mi generación; que no viva para recoger los frutos de mi trabajo; que la muerte, la enfermedad, la decepción y el fracaso sean mi destino. Que así sea para mí, en el nombre de Jesús. Amén.🥳

[12:41] **+7 950 472-70-00:** [Imagen]

[12:41] **+7 950 472-70-00:** [Imagen]

[12:41] **+7 950 472-70-00:** [Imagen]

[12:41] **+7 950 472-70-00:** [Video]

[12:42] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:42] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:42] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:42] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:42] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:42] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:42] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:42] **+591 76945645:** LPM qué ratas!

[12:42] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:42] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:42] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:42] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:42] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:43] **+7 950 472-70-00:**
> _+7 950 472-70-00: [album]_
No estoy aquí para estafar a nadie y quitarle el dinero que tanto le ha costado ganar; eso solo sería una maldición para mí y para mi familia. El mundo es un pañuelo y todo da vueltas: aunque no me afecte a mí directamente, las consecuencias acabarían recayendo sobre mi familia o mis hijos.

[12:45] __+591 67968239 se unieron mediante el enlace de invitación__

[12:45] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:45] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:45] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:45] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:45] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:45] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:46] **+591 73453408:**
> _+7 950 472-70-00: [album]_
Eliminen a ese glasé de estafas  administrador por favor se supone q este es un grupo es para informar sobre gasolina

[12:47] **+591 60280229:** Sakenla che llena la memoria con sus burreras

[12:48] **+7 950 472-70-00:**
> _+591 73453408: Eliminen a ese glasé de estafas  administrador por favor se supone q este es un grupo es para informar sobre gasolina_
Te he estafado antes?

[12:48] **+591 60280229:** Ta bien k mande una ves ya mando komo 10 veces

[12:49] **+591 60280229:** Si tanto kieres regalar lleva en efectivo y da a los niños de kalle k nesecitan

[12:51] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:51] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:51] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:51] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:51] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:51] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[12:51] **+591 74525743:** Saquen a esa

[12:52] **+591 73453408:** Saquenla

[12:52] **+591 73453408:** Urgente

[12:52] **+591 72998730:** Reporten ese numero para que lo bloqueeb

[12:52] **+591 74525743:** Donde estas el admin

[12:52] **+591 71875639:** Saquenlo

[12:53] **+591 74525743:**
> _+591 72998730: Reporten ese numero para que lo bloqueeb_
Xd

[12:53] **+591 60262595:** Lo reportemos

[12:53] **+591 72999358:** Si mejor lo reportemos

[12:53] **+591 72999358:** [Sticker]

[12:53] **+591 67378876:** Saquen la

[12:54] **+591 72999358:** Cómo estafa reporten

[12:54] **+591 57887437:** Etiquen al admi.

[12:54] **+591 57887437:** Todos.  Así va despertar

[12:54] **+591 60262595:** Ya lo reporte

[12:54] **+591 57887437:** @~😀LUIS ANGEL😊

[12:55] **+591 74525743:** @admin

[12:55] **+591 57887437:**
> _+591 57887437: @~😀LUIS ANGEL😊_
Este es el admi

[12:55] **+591 75131234:** @~😀LUIS ANGEL😊

[12:55] **+591 60280229:** Ya le mande sms ojala la sake

[12:57] **+591 71894444:** Eliminen pues

[12:57] **+591 72962359:** Qlp saquen a ese hdp q manda sus huevadas

[12:57] **+591 71894444:**
> _+591 60280229: Ya le mande sms ojala la sake_
Avisas para que no metamos la pata 😂😂

[12:58] __+234 706 058 8922 se unieron mediante el enlace de invitación__

[12:58] **+591 60280229:** 👍

[12:59] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[12:59] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[12:59] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[12:59] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[12:59] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[12:59] **+591 67378898:**
> _+591 64709432: saben si en las vegas hay gasolina especial?_
Las vegas gasolina la plus

[12:59] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[12:59] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[12:59] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[12:59] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[12:59] **+591 60280229:** Otra😡

[13:00] **+591 79278315:**
> _+234 706 058 8922: [album]_
Puta está lleno de estos números extranjeros para estafar

[13:00] **+591 73453408:** Nos salgamos todos de este grupo

[13:00] **+591 60256352:** Si hay que sacarle del grupo

[13:01] **+591 71894444:** Eliminen a los que están con números raros

[13:01] **+591 73453408:** Yo me salgo no quiero renegar con estas ratas

[13:01] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[13:01] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[13:01] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[13:01] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[13:01] **+591 71875639:** Justo hay un solo admin

[13:01] **+591 71875639:** Ahorita le pido

[13:01] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[13:01] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[13:01] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[13:01] **+234 706 058 8922:** _Un admin., +591 67995662, eliminó este mensaje._

[13:02] **+591 72960822:** Por favor reportar a la flcc

[13:02] **+591 71894444:** Pa qué comparten el e lase en el grupo
Ahí nomas debería quedarse

[13:03] **+591 72990143:** A la FELC ya estoy reportado

[13:03] **+591 72960822:** Administrador hay q bloquear a estas estafadoras

[13:03] **+591 72990143:** Gentusa sinvergüenza creen que están en su jardín de niños

[13:07] **+591 60263311:** _Se eliminó este mensaje_

[13:07] **+591 72990143:**
> _+234 706 058 8922: [album]_
Última vez que publican eso en este grupo están advertidos

[13:10] __+591 67995662 eliminó a +380 67 632 9713__

[13:10] **+591 78249245:**
> _+591 64315275: En la panamericano están diciendo_
es plus

[13:11] __+591 67995662 eliminó a +234 706 058 8922__

[13:15] **+591 67995662:** [Mensaje de voz]

[13:16] **+591 73486458:** No entiendo nada che que paso muchachos

[13:16] **+591 73486458:** [Sticker]

[13:16] **+591 71875639:** [Sticker]

[13:21] **+591 73486458:**
> _+591 71875639: Sticker_
Lit es que trabajo de delivery pe jsksksks y justo estaba con pedido

[13:29] **+591 78249245:** alguien q aya cargado la especial avise dnd hay porfa

[14:05] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:05] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:05] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:05] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:05] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:06] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:06] **+591 71875639:** Welta?

[14:06] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:06] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:06] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:06] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:06] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:06] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:06] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:06] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:06] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:06] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:06] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:06] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:06] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:06] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:07] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:07] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:07] **+591 60251131:** [Imagen]

[14:08] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:08] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:08] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:08] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:08] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:11] **+591 71894444:** Otra vez che

[14:12] **+591 70238365:** Donde hay gasolina

[14:12] **+591 70238365:** Saben

[14:12] **+591 70238365:** En vidon

[14:12] **+591 72942824:** No se jura en vano

[14:16] **+591 79259608:**
> _+591 70238365: Donde hay gasolina_
Circuvalacion fotocipia d carnet haata 20 litros, justo taba cargando y consultaron, sin fila!!

[14:17] **+591 71875639:** Especial es en las vegas?

[14:17] **+591 70238365:** Gracias

[14:25] **+591 72948767:** En San Martin poca gente y venden en bidón también con fotocopia carnet

[14:25] **+591 67968239:** Saben si estan cargando gasolina en el agrupa o don daniel????

[14:26] **+7 950 472-70-00:** Tengo 2000 bs para cualquiera que pueda agregarme a un grupo de WhatsApp, ¿vale?

[14:26] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:26] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:26] **+7 950 472-70-00:** _Un admin., +591 67995662, eliminó este mensaje._

[14:27] **+591 74525743:** Agrega está

[14:27] **+591 74525743:** [Sticker]

[14:27] **+591 78703080:**
> _+7 950 472-70-00: Tengo 2000 bs para cualquiera que pueda agregarme a un grupo de WhatsApp, ¿vale?_
BLOQUEEN

[14:34] __+591 67995662 eliminó a +7 950 472-70-00__

[14:56] **+591 72426015:** [Imagen]

[14:56] **+591 72426015:** Especial en campesino

[14:56] **+591 72426015:** Sin fila

[14:57] **+591 72964737:** gracias 🙏🙏

[14:57] **+591 64315170:** Venderán en vidon

[15:00] **+591 78225036:**
> _+591 70238365: Donde hay gasolina_
San Gerónimo pero la plus

[15:58] __+591 73499889 se unieron mediante el enlace de invitación__

[16:29] __+591 76822471 se unieron mediante el enlace de invitación__

[16:30] __Alguien añadió a +591 76822471__

[21:05] __+591 72958736 se unieron mediante el enlace de invitación__

---

## 20 de agosto de 2026

[9:10] __+7 921 018-81-99 se unieron mediante el enlace de invitación__

[9:11] **+7 921 018-81-99:** _Un admin., +591 67995662, eliminó este mensaje._

[9:11] **+7 921 018-81-99:** _Un admin., +591 67995662, eliminó este mensaje._

[9:11] **+7 921 018-81-99:** _Un admin., +591 67995662, eliminó este mensaje._

[9:11] **+7 921 018-81-99:** _Un admin., +591 67995662, eliminó este mensaje._

[9:12] **+7 921 018-81-99:** _Un admin., +591 67995662, eliminó este mensaje._

[9:12] **+7 921 018-81-99:** _Un admin., +591 67995662, eliminó este mensaje._

[9:12] **+7 921 018-81-99:** [Mensaje de album]

[9:12] **+7 921 018-81-99:** [Imagen] Hola, si te interesa invertir 50 Bs y recibir 2.000 Bs, envíame un mensaje para empezar y obtener esa ganancia increíble en solo 5 minutos.💯💯💯


Juro ante Dios Todopoderoso que, si realmente estoy intentando engañarte o estafarte, que Dios Todopoderoso castigue a toda mi generación; que no viva para recoger los frutos de mi trabajo; que la muerte, la enfermedad, la decepción y el fracaso sean mi destino. Que así sea para mí, en el nombre de Jesús. Amén.🥳

[9:12] **+7 921 018-81-99:** [Imagen]

[9:12] **+7 921 018-81-99:** [Imagen]

[9:12] **+7 921 018-81-99:** [Imagen]

[9:12] **+7 921 018-81-99:** [Video]

[9:12] **+591 74525743:** Vino la rata 🐀

[9:13] __[Notificación del sistema]__

[9:14] **+591 71875639:** [Mensaje de voz]

[9:14] **+591 78703080:**
> _+7 921 018-81-99: [album]_
Bloqueen

[9:14] **+7 921 018-81-99:** [Mensaje de album]

[9:14] **+7 921 018-81-99:** [Imagen] Hola, si te interesa invertir 50 Bs y recibir 2.000 Bs, envíame un mensaje para empezar y obtener esa ganancia increíble en solo 5 minutos.💯💯💯


Juro ante Dios Todopoderoso que, si realmente estoy intentando engañarte o estafarte, que Dios Todopoderoso castigue a toda mi generación; que no viva para recoger los frutos de mi trabajo; que la muerte, la enfermedad, la decepción y el fracaso sean mi destino. Que así sea para mí, en el nombre de Jesús. Amén.🥳

[9:14] **+7 921 018-81-99:** [Imagen]

[9:14] **+7 921 018-81-99:** [Imagen]

[9:14] **+7 921 018-81-99:** [Imagen]

[9:14] **+7 921 018-81-99:** [Video]

[9:15] **+591 73451554:** [Mensaje de voz]

[9:17] **+591 63779256:**
> _+591 73451554: Mensaje de voz_
Si tiene la rason

[9:17] **+591 75129306:** Eliminemlos

[9:17] **+591 72990143:** Vamos a tener que armar otro grupo

[9:18] **+591 74525743:** Ambin haga alguien amistrador

[9:18] **+591 75129306:** O mando sicario

[9:18] **+591 72990143:** Estás ratas deben ser del gobierno ahí están que pululan

[9:18] **+591 73499889:** [Sticker]

[9:20] **+591 79259608:** [Sticker]

[9:22] **+591 63779256:**
> _+7 921 018-81-99: [album]_
[Sticker]

[9:25] **+591 72960822:** Buen día a todos, por favor q haya 2 administradores para bloquear a estas estafadoras

[9:26] **+591 71875639:**
> _+591 72960822: Buen día a todos, por favor q haya 2 administradores para bloquear a estas estafadoras_
Ya le pedi qm pase no me paso

[9:26] **+591 71875639:** Para ocupau parece

[9:27] **+591 72960822:** Parece q trabaja y q nombre uno más para ayudarlo

[9:29] **+591 71875639:** Sino creemos otro grupoy y nos mudamos ahi

[9:29] **+591 71894444:** Es q el enlace es abierto igual entraran

[9:29] **+591 63780494:** De una vez más el link

[9:30] **+591 71894444:** Por un tiempo hay q andar eliminando y el administrador bloquear el número

[9:31] **+591 72960822:**
> _+591 71875639: Sino creemos otro grupoy y nos mudamos ahi_
Buena idea

[9:31] **+591 72999358:** [Mensaje de album]

[9:31] **+591 72999358:** [Imagen] Háganme admi y verán la diferencia.

Ya tengo dos grupos aparte.

[9:31] **+591 72999358:** [Imagen]

[9:32] **+591 72960822:** Q sean ,2 administradores

[9:37] **+591 72942858:** Eliminen esa persona el administrador

[9:39] **+591 78703080:** Sera q el administrador le  auspicia a esa estafadora  ??????? 😁

[9:40] **+591 71875639:** Vamos crear

[9:40] **+591 71875639:** Otro grupo

[9:42] __+591 60250362 se unieron mediante el enlace de invitación__

[9:47] **+591 72999400:** [Sticker]

[9:48] **+591 72960822:**
> _+591 71875639: Vamos crear_
De una vez

[9:48] **+591 67394082:** _Se eliminó este mensaje_

[9:49] **+591 68697122:** Alguien sabe donde hay etanol perdón

[9:50] **+591 70235075:** Buen dia saben donde hay gasolina clarita xfa

[9:51] __+591 73489400 se unieron mediante el enlace de invitación__

[9:51] **+591 67905098:**
> _+591 72960822: De una vez_
Igual va aparecer ahí 🤣🤣🤣esos son como virus en todos los grupos están

[9:51] **+591 67905098:** Solo no hay q hacerles caso nada más

[9:52] **+591 60256352:** [Reenviado] Gasolina blankita
Tarija
Tacuarandi
San jorge
Precidente arce

[10:10] **+591 71875639:** [Reenviado] https://chat.whatsapp.com/IKDMCVcqrPnLwKHFR93vNa?s=sw&p=a&ilr=1

[10:14] **+591 63780494:**
> _+591 71875639: https://chat.whatsapp.com/IKDMCVcqrPnLwKHFR93vNa?s=sw&p=a&ilr=1_
Todos al grupo

[10:14] **+591 63780494:** [Sticker]

[10:20] **+591 71875639:** [Sticker]

[10:36] **+591 73482336:** Alguien sabe si están pidiendo bsisa en tarjeta?

[10:36] **+591 73482336:** En el surtidor Tarija ?

[10:38] **+591 71875639:** No piden

[10:39] **+591 73482336:** Gracias

[10:39] **+591 74541389:** No piden

[11:37] __+591 60252918 se unieron mediante el enlace de invitación__

[11:58] __+234 704 735 0503 se unieron mediante el enlace de invitación__

[11:59] **+591 72974985:** Este grupo de gasolina  se esta convirtiendo mas de  compra y venta de todo menos de gasolina

[12:01] **+591 74541389:** Jajaja

[12:02] **+591 63648379:** A cuanto está la gasolina en Tarija ?

[12:02] **+591 63648379:** Ahora ando por sucre compañero

[12:03] **+591 63648379:** Está a 15 bs el litro por acá

[12:06] **+591 72042913:** Dijuuuu

[12:06] **+591 72042913:** Na q ver

[12:06] **+591 74541389:** Jajajjaa

[12:06] **+591 74541389:** Nada que ver eso

[12:07] **+591 74541389:** La gasolina está en su precio normal

[12:07] **+591 74541389:** Y no subirá

[12:07] **+591 63780494:** [Reenviado] https://chat.whatsapp.com/IKDMCVcqrPnLwKHFR93vNa?s=sw&p=a&ilr=1

[12:07] **+591 63780494:** A ese grupo se están cambiando todos sin virus y sin nada de otro rubro

[12:09] **+591 71875639:**
> _+591 63780494: https://chat.whatsapp.com/IKDMCVcqrPnLwKHFR93vNa?s=sw&p=a&ilr=1_
Hay estamos informando

[12:09] **+591 71875639:**
> _+591 72974985: Este grupo de gasolina  se esta convirtiendo mas de  compra y venta de todo menos de gasolina_
Si hay otro grupo netamente gasolina

[12:09] __+591 68683602 se unieron mediante el enlace de invitación__

[12:11] **+591 73456683:**
> _+591 71875639: Si hay otro grupo netamente gasolina_
Pasen el link para unirme al grupo

[12:11] **+591 73456683:** Por favor

[12:11] **+591 71875639:**
> _+591 71875639: https://chat.whatsapp.com/IKDMCVcqrPnLwKHFR93vNa?s=sw&p=a&ilr=1_
Hay esta hno querido

[12:13] **+591 73456683:**
> _+591 71875639: Hay esta hno querido_
Gracias

[12:54] **+234 704 735 0503:** [Mensaje de album]

[12:54] **+234 704 735 0503:** [Imagen] 50Bs para obtener 2000 Bs

100 Bs para obtener 3000 Bs

200 Bs para obtener 5000 Bs

300 Bs para obtener 6000 Bs

400 Bs para obtener 8000 Bs

500 Bs para obtener 10000 Bs

600 Bs para obtener 13000 Bs

¿Estás listo para que te explique qué hacer?

Es 100% seguro y legítimo. Envíame un mensaje directo si te interesa.

[12:54] **+234 704 735 0503:** [Imagen]

[12:54] **+234 704 735 0503:** [Imagen]

[12:54] **+234 704 735 0503:** [Video]

[12:54] **+591 68707751:**
> _+234 704 735 0503: [album]_
Aún no estoy listo.

[13:06] **+591 60251131:** Aún no quiero ser estafado😅

[13:08] **+591 64301527:**
> _+234 704 735 0503: [album]_
Eliminen a esa cagada

[13:09] **+591 72958736:**
> _+591 64301527: Eliminen a esa cagada_
Si eliminen de una vez

[13:10] **+591 75515740:**
> _+591 72958736: Si eliminen de una vez_
De una vez, el grupo tiene un fin determinado

[13:13] **+591 72942858:**
> _+234 704 735 0503: [album]_
Eliminen esas mierdas 💩

[13:13] **+591 71875639:** Se pasamos al otro grupo pibes

[13:21] **+591 75186906:** _Se eliminó este mensaje_

[13:22] **+591 75186906:** Cual

[13:23] **+591 71875639:**
> _+591 63780494: https://chat.whatsapp.com/IKDMCVcqrPnLwKHFR93vNa?s=sw&p=a&ilr=1_
..

[14:13] **+591 78235592:** Buenas dónde están cargando gasolina blanca por favor

[14:50] **+591 71875639:** [Mensaje de voz]

[14:51] **+591 70235075:**
> _+591 71875639: Mensaje de voz_
Positivo

[15:02] **+591 75515740:**
> _+591 71875639: Mensaje de voz_
Pasen link para unirse por favor

[15:04] **+591 63780494:** _Un admin., +591 67995662, eliminó este mensaje._

[16:04] __+591 67995662 eliminó a +7 921 018-81-99__

[16:05] __+591 67995662 eliminó a +591 71875639__

[16:06] __+591 67995662 eliminó a +591 63780494__

[16:07] **+591 69333935:** Alguien sabe donde hay Etanol?

[16:07] **+591 67995662:** Buenas tardes

[16:07] **+591 67995662:** Dónde hay gasolina ⛽ especial

[16:28] **+591 77172588:** Alguien sabe dónde están vendiendo la especial

[16:53] **+591 68707751:**
> _+591 77172588: Alguien sabe dónde están vendiendo la especial_
Tacuarandi

[17:17] **+591 76195199:**
> _+591 77172588: Alguien sabe dónde están vendiendo la especial_
Hace rato había en el surtidor del campesino

[17:17] **+591 69327934:** Etanol ?

[17:51] **+234 704 735 0503:** _Un admin., +591 67995662, eliminó este mensaje._

[17:52] **+591 70238365:**
> _+234 704 735 0503: Tengo 2500 Bs y quiero que alguien me agregue a un grupo._
[Sticker]

[18:21] **+591 72962359:** Este grupo se fue a la mierda con esos estafadores q nadie los saca😤😤😤

[18:24] **+591 75130876:** SI TODA LA.RAZON

[18:24] **+591 75152237:** Si

[18:28] **+591 60280229:** Pueden salirse nadie les obliga estar aki🤔🤫

[18:28] __+591 67995662 eliminó a +234 704 735 0503__

[18:37] **+591 67995662:**
> _+591 72962359: Este grupo se fue a la mierda con esos estafadores q nadie los saca😤😤😤_
Ya lo sake del grupo a esos estafadores

[18:39] **+591 74519930:**
> _+591 67995662: Ya lo sake del grupo a esos estafadores_
Bravo

[18:42] **+591 68616631:** [Mensaje de voz]

[18:44] **+591 75131234:** Tacuarandi

[18:47] **+591 67995662:**
> _+591 75131234: Tacuarandi_
Dijo

[18:49] **+591 60280229:**
> _+591 75131234: Tacuarandi_
Dijo

[18:52] __+591 74526449 se unieron mediante el enlace de invitación__

[18:58] **+591 71198548:** Buenas noches alguien sabe en qué surtidor hay gasolina especial

[19:04] **+591 68616631:**
> _+591 75131234: Tacuarandi_
dijo

[19:06] __+591 79250200 se unieron mediante el enlace de invitación__

[19:19] **+591 79250200:** Buenas nochea, en que surtidor puedo encontar ahurita gasolina especial?

[19:20] **+591 78249245:** Daniel hay plus

[19:24] **+591 72867582:** En el sointa vi fila pero nose cuál gasolina es

[19:57] **+591 79250200:** Muchas gracias

[21:16] **+591 73451069:**
> _+591 74544944: Ya no hay especial en el campesino_
Buenas

[21:16] **+591 73451069:** Alguien sabe donde hay gasolina

[21:17] **+591 65283317:** Buenas noches. Alguien sabe dónde hay gasolina a esta hora?

[21:28] **+591 74525743:** Don Daniel ví

[21:28] **+591 74525743:** Que hay aun

---

## 21 de agosto de 2026

[4:26] **+591 67962583:** Buenos días alguien sabe que surtidor ahí gasolina

[8:22] **+591 68695886:** Buen día en qué surtidor hay la gasolina blanquita

[8:26] **+591 60280229:** Blanca?? ni idea😬

[8:54] **+591 75111184:** Surtidor ypfb de la cárcel con fila pero hay gasolina especial

[9:04] **+591 69333935:**
> _+591 75111184: Surtidor ypfb de la cárcel con fila pero hay gasolina especial_
Cuanta fila?

[9:17] **+591 76184700:** Buen día, alguien sabe si en San Gerónimo hay gasolina especial?

[9:37] **+591 72955920:**
> _+591 75111184: Surtidor ypfb de la cárcel con fila pero hay gasolina especial_
No hay..negativo!

[9:37] **+591 72955920:** Alguien sabe?

[9:37] **+591 72955920:** _Se eliminó este mensaje_

[9:37] **+591 72955920:** _Se eliminó este mensaje_

[9:37] __+591 60278374 se unieron mediante el enlace de invitación__

[10:53] **+591 76837290:** Dónde hay gasolina especial?

[10:53] **+591 74540793:** Saben si en las Vegas la gasolina está blanca??

[10:54] **+591 75147474:** Tacuarandi especial cero fila

[10:54] **+591 68699801:** Aki en la tranca hay gasolina normal sin fila pero no está tan clarita ..

[10:55] __+591 63807006 se unieron mediante el enlace de invitación__

[12:56] **+591 78239250:** Ypfb de campesino vacío, gasolina blanquita.

[12:57] **+591 78239250:** [Imagen]

[13:05] **+591 78249245:**
> _+591 76837290: Dónde hay gasolina especial?_
Tacuarandi

[13:09] **+591 68680221:** En tacuarandi...  O está larga la fila... Acabo de cargar ahí... Incluso con bidón

[13:26] **+591 76837290:** [Sticker]

[13:57] **+591 79251139:** Buenas tarde

[13:57] **+591 79251139:** Disculpen alguien sabe dónde están cargando gasolina en bidón

[13:57] **+591 79251139:** ??

[13:59] **+591 75186906:** Alguien sabe donde hay gasllina especial clarita

[14:08] **+591 74525861:** Si ppr favor información

[14:09] **+591 73483881:** _Se eliminó este mensaje_

[14:14] **+591 78249245:**
> _+591 78249245: Tacuarandi_
.

[14:14] **+591 78249245:** había hace rato

[14:15] **+591 69333935:**
> _+591 78249245: había hace rato_
que tal la fila?

[14:18] **+591 73483881:**
> _+591 69333935: que tal la fila?_
10 autos

[14:19] **+591 69333935:**
> _+591 73483881: 10 autos_
ahora mismo?

[14:19] **+591 69333935:** 😯

[14:19] __+591 78234737 se unieron mediante el enlace de invitación__

[14:26] **+591 74525861:** Alguien sabe que tal esta la gasolina en las vegas

[14:26] **+591 65283317:** Dónde queda el tacuarandi?

[14:27] **+591 71894444:** El q esta a lado de ypfb morros blancos

[15:03] **+591 79256415:** Buenas

[15:03] **+591 79256415:** Donde hay gasolina sin mucha fila?

[15:10] **+591 73483881:**
> _+591 79256415: Donde hay gasolina sin mucha fila?_
La plus? En todo lado

[15:14] **+591 69330305:** Gasolina especial dónde hay?

[15:15] **+591 79256415:** [Imagen] Gasolina especial en San geronimo no hay mucha fila

[15:15] **+591 79256415:** [Mensaje de unknown]

[15:16] **+591 69330305:** Gracias

[15:37] **+591 71868397:** Donde ay gasolina  compas

[15:37] **+591 71868397:** [Sticker]

[16:49] **+591 78236766:** Buenas tardes saben dónde hay etanol??

[16:55] **+591 69330305:** Por si les sirve Tacuarandi es especial pero hay fila de 3 cuadras

[16:55] **+591 68699801:** Portillo, pero Noce si seguirán teniendo

[19:58] **+591 76188784:** Buenas noches, alguien sabe si hay diésel en el surtidor moto mendez

[20:41] **+591 79251139:** Buenas noches

[20:42] **+591 79251139:** Disculpen alguien sabe dónde hay gasolina especial

[20:42] **+591 79251139:** La clarita por favor

[20:42] **+591 60274507:** Ex terminal hay

[20:43] **+591 60274507:** Especial

[20:43] **+591 79251139:**
> _+591 60274507: Ex terminal hay_
Muchas gracias

[20:43] **+591 69330305:**
> _+591 79251139: Disculpen alguien sabe dónde hay gasolina especial_
Tacuarandi

[20:43] **+591 69330305:** Nose si aún haya

[20:44] **+591 79251139:** Gracias por la información muchas gracias

[21:42] **+591 79251139:** Alguien sabe dónde hay gasolina especial no hay en el tacuarandi ni en la ex terminal

[21:42] **+591 79251139:** En la ex terminal hay gasolina plus

---

## 22 de agosto de 2026

[8:55] **+591 74525743:** Buen día chicos dónde hay gasolina

[9:49] **+591 74537707:** Tenemos Por Quintal 
Arroz Grano de Oro entero
Arroz Gallo paquete 10 unidades
Fideo Famosa surtido
Lazzaroni surtido
Sacos de 2 arrobas 
Azúcar bermejeña quintal
Azúcar Bermejeña arroba
Harina Milka quintal 1/2 quintal harina 0000 Florencia
Papel higiénicos Nacional Ecomax Super Pañales Huggies P M G XG XXG
Granaditas de 250 ML 500ml
Jabones lavandinas 
Sal por mayor 
Alimento para sus mascotas y otros productos por mayor y menor si tienes tienda por tu barrio  comunicate al privado  74537707 y pasarán a registrar tu pedido....

[9:50] **+591 74537707:** _Se eliminó este mensaje_

[10:21] **+591 68707751:**
> _+591 74537707: Tenemos Por Quintal 
Arroz Grano de Oro entero
Arroz Gallo paquete 10 unidades
Fideo Famosa surtido
Lazzaroni surtido
Sacos de 2 arrobas 
Azúcar bermejeña quintal
Azúcar Bermejeña arroba
Harina Milka quintal 1/2 quintal harina 0000 Florencia
Papel higiénicos Nacional Ecomax Super Pañales Huggies P M G XG XXG
Granaditas de 250 ML 500ml
Jabones lavandinas 
Sal por mayor 
Alimento para sus mascotas y otros productos por mayor y menor si tienes tienda por tu barrio  comunicate al privado  74537707 y pasarán a registrar tu pedido...._
No tenes gasolina?

[10:21] **+591 74537707:** Al privado te escribí si tambien

[10:22] **+591 74541389:** Jajaja

[10:28] **+591 71894444:**
> _+591 68707751: No tenes gasolina?_
[Sticker]

[10:50] **+591 78706211:** Saben si hay gasolina en la ex terminal ?

[10:56] **+591 72968117:**
> _+591 78706211: Saben si hay gasolina en la ex terminal ?_
No hay mucha fila

[10:57] **+591 68697122:**
> _+591 72968117: No hay mucha fila_
No sabe si es la especial

[10:58] **+591 71894444:** En la ex terminal no venden especial...... Almenos que recuerde nunca nadie dijo que hay especial, pura plus.

[11:14] **+591 79278315:**
> _+591 71894444: En la ex terminal no venden especial...... Almenos que recuerde nunca nadie dijo que hay especial, pura plus._
Ayer dijeron que efectivamente es plus la gasolina de la ex terminal 👍🏽

[11:18] **+591 78232702:** Etanol en Don Daniel.. poca fila

[13:32] **+591 71195758:**
> _+591 78232702: Etanol en Don Daniel.. poca fila_
No hay especial brow no sabes

[13:35] **+591 69334388:** [Imagen]

[13:36] **+591 69334388:** Etanol dos autos en Daniel

[13:36] **+591 78232702:** Recien staban cargando la otra gasolina pero nose cual

[13:41] **+591 71195758:** Alguien sabe  podria pasar el dato donde hay gasolina especial

[14:18] **+591 60255251:** Gasolina especial y etanol surtidor moto Mendez, los q están cerca x la provincia Mendez

[14:18] **+591 60255251:** Y los q quieren diesel, está vacío.....

[14:18] **+591 60255251:** [Imagen]

[14:18] **+591 60255251:** [Imagen]

[14:21] **+591 74525743:** Dónde hay gasolina

[14:21] **+591 74525743:** Ahora

[14:43] **+591 75186906:** Donde don daniel no hay fila vengan clarita

[14:43] **+591 74525743:** No es netanol

[15:23] **+591 77870087:** buenas tardes Alguien sabe en que surtidor hay gasolina especial por favor ...

[16:43] **+591 60255251:**
> _+591 60255251: Imagen_
☝️

[16:51] **+591 71868154:** Surtidor el molle 

Gasolina ⛽ especial

[17:52] **+591 65821266:** Disculpen el comentario, alguien que sepa o tenga una moto boxer en buen estado a la venta

[19:02] **+591 68749557:** Buenas noches alguien sabe en q surtidor puedo conseguir gasolina especial estas horas xfavor...

[19:23] **+591 75186906:** [Imagen]

[19:23] **+591 75186906:** No hay fila

[19:26] **+591 69310319:**
> _+591 75186906: Imagen_
Que gasolina es

[19:27] **+591 68749557:**
> _+591 75186906: Imagen_
Es la especial o la plus

[19:27] **+591 75186906:** Especial

[19:29] **+591 74525743:** En las Vegas igual no hay fila

[19:41] **+591 68717700:** Surtidor del mastil poca fila vengan

[19:50] **+591 65821266:** Tacuarandi 0 filaa

[19:50] **+591 72867582:**
> _+591 65821266: Tacuarandi 0 filaa_
Especial?

[21:29] **+591 71872024:** Alguien sabe sigue hay gasolina en el moto Mendez

[21:59] **+591 71872024:** En el molle aún hay gasolina especial

[23:56] **+591 76174998:** Buenas no saben donde puede haber gasolina especial ahurita?

[23:59] **+591 61861438:** Ah estás horas no creo q pilles casi imposible

---

## 23 de agosto de 2026

[8:43] **+591 70238365:** [Imagen]

[8:58] **+591 71890219:** Buenos días en el surtidor el portillo gasolina especial y etanol

[9:15] **+591 65841415:** [Mensaje de voz]

[9:19] **+591 71195758:** San jorge 2

[9:19] **+591 71195758:** No se si seguira teniendo ayer tenia

[9:50] __[Llamada]__

[11:08] **+591 68707751:** Dónde ay especial

[11:15] **+591 68707751:** En ypfb ay especial alguien sabe?

[11:16] **+591 64695398:** Saben si hay gasolina en las Vegas?

[11:16] **+591 68707751:** [Imagen] Ypfb no ay mucha fila

[11:16] **+591 69310319:** En el agrupa hay solo plus

[11:26] **+591 64695398:** Saben si en la exterminal hay gasolina?

[12:25] **+591 67394082:** Alguien sabe si están vendiendo etanol en la agrupa?

[12:26] **+591 67394082:** O alguna otra

[12:50] **+591 78229658:** Ay etanol en la sointa

[12:50] **+591 78229658:** Y la gasolina plus

[13:07] **+591 64695398:** Alguien sabe dónde hay especial?

[13:08] **+591 64695398:** ???

[13:18] **+591 70238365:** [Imagen]

[14:01] **+591 63774712:** Alguien sabe dónde están cargando gasolina?

[14:02] **+591 68707751:** Ypfb

[15:05] **+591 65841415:** [Mensaje de voz]

[15:06] **+591 78249245:** a qué hora fue eso

[15:06] **+591 78249245:** para poder ir

[15:06] **+591 65841415:** [Mensaje de voz]

[15:42] **+591 78249245:** ya no hay

[15:42] **+591 78249245:** una consulta donde puedo encontrar gasolina q vendan en bidón

[15:42] **+591 78249245:** alguien sabe

[15:44] **+591 77878271:** Agrupa pero es la plus

[15:50] **+591 78249245:** gracias

[15:56] **+591 75124570:** Gasolina especial en YPFB campesino

---

## 24 de agosto de 2026

[10:28] **+591 76837290:** Saben dónde hay gasolina especial

[10:28] **+591 60267962:** Ypfb del campesino

[11:11] **+591 72907123:** Alguien sabe dónde hay súper etanol?

[12:59] __+591 74512890 se unieron mediante el enlace de invitación__

[13:04] **+591 70238365:** [Imagen]

[13:05] **+591 64583312:**
> _+591 76837290: Saben dónde hay gasolina especial_
Cargan en bidón disculpe ahí?

[13:10] **+591 76837290:**
> _+591 64583312: Cargan en bidón disculpe ahí?_
No

[15:41] **+591 63504498:** Buenas tardes

[15:41] **+591 63504498:** Alguien sabe dónde hay gasolina especial

[15:41] **+591 63504498:** ..

[15:56] **+591 71894444:** Están diciendo en Sointa
Final circunvalación
Cargaron a las 2 de la tarde y aun habia

[16:01] **+591 68717700:** Creo q en todos los surtidores hay gasolina eso vi

[16:20] **+591 72957442:** Buenas amigos

[16:20] **+591 77878271:** _Se eliminó este mensaje_

[16:52] **+591 75141556:** Buenas tardes amigos..alguien que sepa  en que taller hacen un buen AFINADO de motor... si alguien me recomienda.. gracias  🙏

[17:01] **+591 76153500:** Busco mecánico de moto que pueda venir asta mi domicilio para cambiar una chapa de moto boxer .

[21:12] **+591 74515367:** _Se eliminó este mensaje_

[21:31] **+591 72969146:** Buenas noches no saben en qué surtidor están vendiendo gasolina a esta hora?

[21:34] **+591 75186906:** Don daniel

[21:35] **+591 72969146:** Gracias

[21:57] **+591 78229658:** Agrupa

[21:57] **+591 78229658:** Están vendiendo

[21:59] **+591 68746056:** No sabes si es la especial

---

## 25 de agosto de 2026

[9:04] **+591 76945645:** En don Daniel especial cero fila

[9:27] **+591 74418754:**
> _+591 76945645: En don Daniel especial cero fila_
Se puede cargar ahí con bidón y fotocopia?

[9:47] __+249 12 875 0091 se unieron mediante el enlace de invitación__

[9:47] **+249 12 875 0091:** _Un admin., +591 67995662, eliminó este mensaje._

[9:47] **+249 12 875 0091:** _Un admin., +591 67995662, eliminó este mensaje._

[9:47] **+249 12 875 0091:** _Un admin., +591 67995662, eliminó este mensaje._

[9:47] **+249 12 875 0091:** _Un admin., +591 67995662, eliminó este mensaje._

[9:47] **+249 12 875 0091:** _Un admin., +591 67995662, eliminó este mensaje._

[9:48] **+249 12 875 0091:** _Un admin., +591 67995662, eliminó este mensaje._

[9:48] **+249 12 875 0091:** [Mensaje de album]

[9:48] **+249 12 875 0091:** [Imagen] Hola, si te interesa invertir 50 Bs y recibir 2000 Bs, envíame un mensaje para empezar y obtener esa increíble ganancia en solo 5 minutos.💯💯💯💯

Juro ante Dios Todopoderoso que, si realmente estoy intentando engañarte o estafarte, que Dios Todopoderoso castigue a toda mi generación; que no viva para recoger los frutos de mi trabajo; que la muerte, la enfermedad, la decepción y el fracaso sean mi destino. Que así sea para mí, en el nombre de Jesús. Amén.🥳

[9:48] **+249 12 875 0091:** [Imagen]

[9:48] **+249 12 875 0091:** [Imagen]

[9:48] **+249 12 875 0091:** [Imagen]

[9:48] **+249 12 875 0091:** [Video]

[9:52] **+591 71894444:** A eliminar y boleqr por favor

[9:53] **+249 12 875 0091:** [Mensaje de album]

[9:53] **+249 12 875 0091:** [Imagen] Hola, si te interesa invertir 50 Bs y recibir 2000 Bs, envíame un mensaje para empezar y obtener esa increíble ganancia en solo 5 minutos.💯💯💯💯

Juro ante Dios Todopoderoso que, si realmente estoy intentando engañarte o estafarte, que Dios Todopoderoso castigue a toda mi generación; que no viva para recoger los frutos de mi trabajo; que la muerte, la enfermedad, la decepción y el fracaso sean mi destino. Que así sea para mí, en el nombre de Jesús. Amén.🥳

[9:53] **+249 12 875 0091:** [Imagen]

[9:53] **+249 12 875 0091:** [Imagen]

[9:53] **+249 12 875 0091:** [Imagen]

[9:53] **+249 12 875 0091:** [Video]

[9:55] **+591 76945645:** QLP volvió la basura

[9:55] **+591 76945645:** El enlace del nuevo grupo xfa

[9:59] **+591 74670785:** Bloquen a ese maleante

[9:59] **+591 71878341:**
> _+249 12 875 0091: [album]_
Dale con lo mismo 🤦🏻‍♂️🤦🏻‍♂️ malditos estafadores

[10:00] **+249 12 875 0091:** [Mensaje de album]

[10:00] **+249 12 875 0091:** [Imagen] Hola, si te interesa invertir 50 Bs y recibir 2000 Bs, envíame un mensaje para empezar y obtener esa increíble ganancia en solo 5 minutos.💯💯💯💯

Juro ante Dios Todopoderoso que, si realmente estoy intentando engañarte o estafarte, que Dios Todopoderoso castigue a toda mi generación; que no viva para recoger los frutos de mi trabajo; que la muerte, la enfermedad, la decepción y el fracaso sean mi destino. Que así sea para mí, en el nombre de Jesús. Amén.🥳

[10:00] **+249 12 875 0091:** [Imagen]

[10:00] **+249 12 875 0091:** _Un admin., +591 67995662, eliminó este mensaje._

[10:00] **+249 12 875 0091:** _Un admin., +591 67995662, eliminó este mensaje._

[10:01] **+591 64301527:** Puta madre porque no botan a ese número

[10:29] **+591 72985600:**
> _+591 64301527: Puta madre porque no botan a ese número_
Correcto

[10:39] **+591 71894444:** Deben bloquear antes de eliminar el numero

[11:26] **+591 72967111:** Saben si hay gasolina en Don daniel

[11:27] **+591 60256352:**
> _+591 72967111: Saben si hay gasolina en Don daniel_
No hay

[11:27] **+591 72967111:**
> _+591 60256352: No hay_
Gracias

[11:35] **+591 73483881:** Buen día ya no hay en don Daniel 🥴 saben dónde hay especial ?

[11:51] **+591 69317750:** X2 alguien puede pasar el dato porfii

[12:11] **+591 60256352:** Buenas tardes dónde puedo conseguir etanol por favor

[12:22] **+591 72967111:** Acaba de llegar el cisterna en el surtidor Y.P.F.B.

[12:22] **+591 72967111:** Hay gasilina

[12:23] **+591 74418754:** Especial o plus

[12:40] **+591 69913636:** En el surtidor Tarija acaban de descargar la Gasolina Especial

[13:04] **+591 74507185:** [Imagen]

[13:05] **+591 74507185:** Gasolina especial en el Tarija

[13:20] **+591 60256352:** Gasolina especial y etanol en sointa recién cargue

[13:34] **+591 76193928:** Buenas tardes especial en el surtidor el Molle

[14:05] **+591 64325441:** Pueden pasar el link del grupo para añadir por favor

[14:20] **+591 67905098:** Buenas tardes

[14:20] **+591 67905098:** Algún grupo d diesel alguien tuviera link ??

[15:09] __+591 73300602 se unieron mediante el enlace de invitación__

[15:09] __Alguien añadió a +591 73300602__

[19:45] **+591 72975761:** Gasolina especial en el surtidor de sointa 
Final circunvalación

[19:57] **+591 65821266:** Alguna moto boxer a la venta

[19:58] **+591 75515740:**
> _+591 72975761: Gasolina especial en el surtidor de sointa 
Final circunvalación_
👍🏻

[21:05] **+591 63504498:** El el surtidor Tarija no saben que gasolina hay alguien sabe

[21:08] **+591 75117506:** En las Vegas hay la plus nunca llega ahí la especial ?

[21:08] **+591 69913636:**
> _+591 63504498: El el surtidor Tarija no saben que gasolina hay alguien sabe_
Esta la especial sin fila ya cargue

[21:26] **+591 79251139:**
> _+591 69913636: Esta la especial sin fila ya cargue_
Buenas noches disculpe no saben si Cargan en bidón en el surtidor tarija

[21:26] **+591 79251139:** ??

[21:28] **+591 72963113:**
> _+591 79251139: Buenas noches disculpe no saben si Cargan en bidón en el surtidor tarija_
Pregunte señor

[21:30] **+591 69913636:**
> _+591 79251139: Buenas noches disculpe no saben si Cargan en bidón en el surtidor tarija_
Con fotocopia de carnet

[21:31] **+591 79251139:**
> _+591 69913636: Con fotocopia de carnet_
Bueno muchas gracias

---

## 26 de agosto de 2026

[9:06] **+591 72966160:** Buenas donde hay  gasolina especial

[9:24] **+591 71866559:** _Se eliminó este mensaje_

[9:28] **+591 71866559:** Gasolina especial en San Jerónimo , sin fila

[9:35] **+591 72999400:** Buen día donde hay gasolina clarita?

[9:36] **+591 72999400:** Gracias

[9:51] **+591 64311645:**
> _+591 71866559: Gasolina especial en San Jerónimo , sin fila_
...

[9:51] **+591 64311645:** Lean

[9:51] **+591 72998577:** [Sticker]

[10:06] **+591 63504498:** Alguien sabe si hay gasolina especial en el surtidor Tarija

[10:26] **+591 77176030:** Alguien sabe cuántos litros cargan en botellón por persona ?

[10:28] **+591 71872723:** Gasolina especial en prointa recien estan por descargar el sisterna

[10:29] **+591 71872723:** Estan descargando diesel

[10:29] **+591 71872723:** [Imagen]

[10:56] **+591 72999358:**
> _+591 63504498: Alguien sabe si hay gasolina especial en el surtidor Tarija_
Algunos 10 litros.

Otros 20

[10:56] **+591 64695398:** Hay gasolina en las Vegas?

[11:02] **+591 75117506:**
> _+591 64695398: Hay gasolina en las Vegas?_
Si de la plus

[11:02] **+591 64695398:** Ok, muchas gracias colega

[11:11] **+591 79251139:**
> _+591 71866559: Gasolina especial en San Jerónimo , sin fila_
Gracias

[11:36] __+234 811 565 2813 se unieron mediante el enlace de invitación__

[11:37] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:38] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:38] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:38] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:38] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:38] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:38] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:38] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:38] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:38] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:38] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:38] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:38] **+591 72998577:** awantaaaa

[11:39] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:39] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:39] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:39] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:39] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[11:40] **+591 72998577:** [Sticker]

[12:01] **+591 74519930:**
> _+234 811 565 2813: [album]_
😀😀

[12:23] __+591 67995662 eliminó a +249 12 875 0091__

[13:59] **+591 75515740:** Buenas tardes Alguien sabe donde hay gasolina especial?

[14:08] **+591 65800835:** En san geronimo gasolina especial

[14:14] **+591 75515740:** Gracias

[14:21] **+591 75515740:** Entre por siacaso a SURTIDOR DON DANIEL 
ENCONTRÉ GASOLINA ESPECIAL 
Sin fila

[14:41] **+591 74525861:** Gracias

[14:50] **+591 74525861:** Alguien sabe si sigue habiendo dnd don daniel??

[15:01] **+591 78709493:** En San Gerónimo gasolina especial acabo de cargar

[15:35] **+591 75515740:**
> _+591 74525861: Alguien sabe si sigue habiendo dnd don daniel??_
Aun hay

[15:36] **+591 74525861:** Gracias

[15:36] **+591 74525861:** Ya cargue

[16:32] **+591 69327934:** Etanol ?

[16:37] **+591 72964737:** por si a caso hay gasolina Clarita en dn Daniel, recién cargue.

[16:42] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[16:42] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[16:42] **+234 811 565 2813:** _Un admin., +591 67995662, eliminó este mensaje._

[16:43] **+591 71894444:** Che bloqueen pues
Esta es la que jura que es verdad sus mensajes

[16:44] **+591 79256415:** Donde está el ADM

[16:46] **+591 60264808:**
> _+234 811 565 2813: Le daré 2000 bs a cualquiera que pueda agregarme a un grupo de WhatsApp._
[Sticker]

[16:49] **+591 72964737:**
> _+234 811 565 2813: Le daré 2000 bs a cualquiera que pueda agregarme a un grupo de WhatsApp._
nadie regala dinero nadie, mejor amigo guarde su platita y no moleste, este es un grupo para informar en dnd hay gasolina.

[17:01] **+591 67905098:** Tanto lío hacen solo ignoren esos mensajes muy dramáticos son

[17:33] **+591 72974985:**
> _+234 811 565 2813: Le daré 2000 bs a cualquiera que pueda agregarme a un grupo de WhatsApp._
Cobrenlen por el echo que pertenece a este grupo si quiere pagar por todo

[18:37] __[Notificación del sistema]__

[18:38] __+591 67995662 eliminó a +234 811 565 2813__

[18:43] **+591 67995662:**
> _+591 79256415: Donde está el ADM_
Ya lo saqué y puse privacidad al grupo para q no entren

[20:21] **+591 75798904:** _Un admin., +591 67995662, eliminó este mensaje._

[21:23] **+591 76837768:** _Un admin., +591 67995662, eliminó este mensaje._

---

## 27 de agosto de 2026

[0:13] **+591 74549616:** Hola alguien sabe donde hay sistema  para cargar gaso??

[0:25] **+591 71873983:**
> _+591 74549616: Hola alguien sabe donde hay sistema  para cargar gaso??_
Hrno

[0:25] **+591 71873983:** Se manejan con el mismo sistema es a nivel nacional el cuelgue de sistema

[0:25] **+591 71873983:** A esperar que se despeje

[3:26] __+591 75173654 se unieron mediante el enlace de invitación__

[7:52] **+591 72947156:** Buen dia alguien sabe donde hay gasolina especial

[7:55] **+591 72947156:** o en que suetidor habra porfavor

[8:05] **+591 75117506:** Anoche cargue a las 23 hrs en el surtidor don Daniel  tienen la especial

[8:34] **+591 68702274:** Aaa bueno

[8:56] **+591 77179760:** Buenos días dónde estarán vendiendo gasolina especial? Si alguien sabe por favor se lo agradecería mucho 🙏

[8:57] **+591 71894444:** Dicen que en el campesino no hay fila

[8:59] **+591 77179760:**
> _+591 71894444: Dicen que en el campesino no hay fila_
Gracias

[9:51] **+591 77179760:** En bidón dónde están vendiendo la especial por favor si alguien puede pasar dato

[10:12] **+591 74670785:** Buenos dias  amigos comuniquen  enque. Surtidor estan  vendiendo  gasolina especial

[10:24] **+591 73483881:**
> _+591 71894444: Dicen que en el campesino no hay fila_
Confirmado

[10:24] **+591 73483881:** Cero fila

[10:26] **+591 74670785:** Que gasolina es especial o plus

[10:38] **+591 73483881:** Especial

[10:43] **+591 72947156:** disculpe donde queda este lugar

[10:49] **+591 72960135:** Buenos días grupo disculpen donde puedo conseguir gasolina especial (clarita) en éste momento

[10:49] **+591 72960135:** Por favor

[10:49] **+591 72960135:** Se los agradeceré mucho

[10:53] **+591 73483881:** https://maps.app.goo.gl/5sPBFxxTNyChdEeY9

[11:21] **+591 72960135:** Muchas gracias

[11:45] **+591 78225036:**
> _+591 73483881: https://maps.app.goo.gl/5sPBFxxTNyChdEeY9_
Buen día saben si se puede pagar por qr

[11:47] **+591 74418754:**
> _+591 78225036: Buen día saben si se puede pagar por qr_
No

[13:18] **+591 73451554:** Donde están vendiendo gasolina especial por favor

[13:21] **+591 69334388:**
> _+591 73451554: Donde están vendiendo gasolina especial por favor_
En Nibol atte. Don Percygatocheve

[13:38] **+591 69330305:**
> _+591 73451554: Donde están vendiendo gasolina especial por favor_
En el YPFB campesino

[14:31] **+591 73494831:**
> _+591 69330305: En el YPFB campesino_
No hay gasolina en ypfb campesino

[14:32] **+591 73494831:** Se acabo..

[14:55] **+591 72950812:** Buenas tardes disculpen estimados  algien q sepa si ay Diesel en algún surtidor por favor

[16:42] **+591 79256927:** Buenas tardes, porfa alguien q me informe en q surtidor están vendiendo gasolina especial??

[18:06] **+591 64315275:**
> _+591 79256927: Buenas tardes, porfa alguien q me informe en q surtidor están vendiendo gasolina especial??_
X2

[20:49] **+591 65821266:** Alguien sabe dónde hay gasolina especial a esta hora

---

## 28 de agosto de 2026

[5:40] **+591 63785960:** Buenos Dias donde puedo aver gasolina especial

[6:55] **+591 73451554:** Buenos días donde hay gasolina especial por favor

[7:49] **+591 72990143:** https://vt.tiktok.com/ZSVGeHe5Y/

[8:08] **+591 74508106:** Surtidor del campesino gasolina especial

[8:12] __+591 73361042 se unieron mediante el enlace de invitación__

[8:12] __+591 75149754 se unieron mediante el enlace de invitación__

[8:16] **+591 78229658:** Buendía saben en qué surtidores hay la especial Pasen el dato por favor

[8:43] **+591 68697122:** Alguien sabe dónde hay etanol perdón

[9:11] **+591 73451554:** Gracias por el dato gasolina especial

[9:50] **+591 60274507:** Buenoa dias gasolina

[9:50] **+591 60274507:** Especial dnd

[9:50] **+591 60274507:** Hay

[9:52] **+591 73451554:** En el campesino pero la cola re larga

[11:33] **+591 72977230:** Buenos días alguien cargó la gasolina plus especial? 
Acabo de consultar en el surtidor de las vegas y me dijeron que ahora solo les llegaría esa gasolina que mezclaron la plus y la especial y así llegaría apartir de ahora, y en sus boletas ya sale con ese nombre plus especial

[11:35] **+591 68680221:**
> _+591 72977230: Buenos días alguien cargó la gasolina plus especial? 
Acabo de consultar en el surtidor de las vegas y me dijeron que ahora solo les llegaría esa gasolina que mezclaron la plus y la especial y así llegaría apartir de ahora, y en sus boletas ya sale con ese nombre plus especial_
Pues mierda de gasolina... Gobierno de mierda

[11:35] **+591 68680221:** 🤬🤬🤬🤬🤬

[11:35] **+591 68707751:** Tenía que ser el Rodrigo Paz

[11:36] **+591 74541389:** Mmmm

[11:36] **+591 74541389:** Que feo

[11:36] **+591 60272671:**
> _+591 72977230: Buenos días alguien cargó la gasolina plus especial? 
Acabo de consultar en el surtidor de las vegas y me dijeron que ahora solo les llegaría esa gasolina que mezclaron la plus y la especial y así llegaría apartir de ahora, y en sus boletas ya sale con ese nombre plus especial_
Que cagada

[11:37] **+591 60272671:** Con razon ahora esta mas amarilla la la gasolina no esta tan blanquita como se cargaba antes no me fije el detalle de la factura

[11:43] **+591 73451554:** Si así dijeron que el lunes posible llegue la especial

[12:24] **+591 79250200:** Buenas tardes! Saben si hay especial en el surtidor Tarija o Sointa?

[14:28] **+591 78249245:** buenas tardes dónde hay gasolina especial

[14:28] **+591 78249245:** a esta hora

[14:39] **+591 78249245:** alguien sabe si en el campesino

[14:39] **+591 78249245:** sigue habiendo especial?

[15:14] **+591 76195199:**
> _+591 78249245: sigue habiendo especial?_
Alguien sabe ?

[15:59] **+591 74537613:** [Mensaje de voz]

[16:08] **+591 73451554:** 👍

[16:30] **+591 79251139:** Buenas tardes compañeros disculpen alguien saben dónde hay gasolina especial por favor

[16:31] **+591 65811282:** En san geranio hay gasolina especial

[16:31] **+591 79251139:**
> _+591 65811282: En san geranio hay gasolina especial_
En san Gerónimo ???

[16:31] **+591 65811282:** Si no había fila hasta hace un rato que cargue

[16:33] **+591 79251139:** Bueno muchas gracias por el dato

[16:34] **+591 78229658:** En el agrupa que gasolina ay alguien sabe

[17:41] **+591 73361042:** Plus

[17:41] **+591 73361042:** En el agrupa

[18:14] **+591 78692302:** Etanol ex terminal

[21:04] **+591 72867582:** Etanol en sointa
Especial en san Gerónimo

[21:05] **+591 60274507:** Hay

[21:05] **+591 60274507:** ??

[21:07] **+591 72867582:** Se

[22:25] __+591 72945180 se unieron mediante el enlace de invitación__

[22:26] __+591 73491313 se unieron mediante el enlace de invitación__

[22:26] __+591 65803033 se unieron mediante el enlace de invitación__

---

## 29 de agosto de 2026

[0:46] **+591 69890833:** Buenas saben si ya están cargando?

[1:02] **+591 72945180:**
> _+591 69890833: Buenas saben si ya están cargando?_
Donde

[5:36] **+591 71195758:** Saben si en el molle tossvia hay gasolina

[8:12] **+591 72997886:** Buen dia en el surtidor las américas del campesino hay gasolina especial

[9:00] **+591 70238365:** [Imagen]

[11:26] **+591 75140034:** Buen día don hay gasolina especial xfa

[12:44] **+591 73494831:** Alguien sabe en que surtidor venden gasolina en bidon

[12:44] **+591 73494831:** ???

[12:54] **+591 61858648:** Buenas alguien sabe que surtidor hay aún gasolina...

[13:03] **+591 72976766:** YPFB Campesino

[13:11] **+591 77178786:** San Jorge sin fila

[13:12] **+591 75132648:**
> _+591 77178786: San Jorge sin fila_
Gasolina especial?

[13:35] **+591 77175043:** Dónde hay gazolina especial??

[13:36] **+591 78249245:**
> _+591 72976766: YPFB Campesino_
.

[13:39] **+591 71872024:**
> _+591 72997886: Buen dia en el surtidor las américas del campesino hay gasolina especial_
Ahí dice que hay especial

[13:39] **+591 71872024:** En el san Gerónimo hay la plus pero clarita párese especial

[13:51] **+591 74637856:** Buenas disculpen... para la venta de bidon... solo es con fotocopia de carnet?

[13:51] **+591 74637856:** O piden otra cosa

[14:50] **+591 67963233:** En que surtidor hay gasolina en este momento

[14:50] **+591 67963233:** Amigoa

[14:54] **+591 68707751:** Pueden pasar el dato porfa

[14:57] **+591 77178786:** San Jorge sigue teniendo la especial y sin mucha fila

[15:16] **+591 71195758:**
> _+591 74637856: Buenas disculpen... para la venta de bidon... solo es con fotocopia de carnet?_
Solo eso algunos que estes en ciscargio

[15:27] **+591 68707751:**
> _+591 77178786: San Jorge sigue teniendo la especial y sin mucha fila_
Negativo

[15:27] **+591 68707751:** Solo plus

[15:28] **+591 69913636:** En el surtidor Tarija acaban de descargar Gasolina Especial

[15:55] **+591 68707751:**
> _+591 69913636: En el surtidor Tarija acaban de descargar Gasolina Especial_
Positivo cero fila

[16:25] **+591 74525861:**
> _+591 69913636: En el surtidor Tarija acaban de descargar Gasolina Especial_
Eso es en la domingo savio

[16:25] **+591 74525861:** No ve???

[16:32] **+591 68698136:**
> _+591 74525861: Eso es en la domingo savio_
Si si

[16:33] **+591 74525861:** Gracias

[16:34] **+591 60251131:** [Imagen]

[16:34] **+591 67378876:**
> _+591 60251131: Imagen_
Hay fila?

[16:35] **+591 60251131:** De 3 autos

[16:35] **+591 60251131:** 😅

[16:35] **+591 68698136:** No saben que piden para cargar en bidón

[16:37] **+591 68700198:** _Se eliminó este mensaje_

[19:48] **+591 72945325:** Buenas noches alguien sabe dónde hay gasolina especial xfa🙏

[19:50] **+591 60251131:** En el surtidor Tarija pero había fila

[20:00] **+591 71894444:** [Imagen] Soy el último de la fila

[20:01] **+591 72945325:** Gracias

[20:02] **+591 72960135:**
> _+591 71894444: Imagen: Soy el último de la fila_
Una pregunta, aquí estan vendiendo la gasolina especial (blanca)??

[20:03] **+591 75132648:** Estan vendiendo en bidón

[20:03] **+591 75132648:** ???

[20:04] **+591 72945325:** [Mensaje de voz]

[20:05] **+591 72945325:** [Imagen]

[20:18] **+591 72960135:** [Imagen]

[20:51] **+591 74637856:** Buenas ai gasolina especial... en surtidor TARIJA... habra toda la nocheb hasta mañana...

[20:51] **+591 74637856:** Tb venden en bidon.. con fotocopia de carnet

---

## 30 de agosto de 2026

[7:18] __+591 78700752 se unieron mediante el enlace de invitación__

[16:33] **+591 77175043:** [Imagen] Me sobró pollito alguien quiere delivery gratis 🥺

[18:13] **+591 75798904:** _Esperando el mensaje… Esto puede demorar un poco._

[18:48] **+591 64311645:**
> _+591 75798904: Imagen_
Donde esta ubicado

[19:56] **+591 63970705:** [Imagen] Disponibles los compresores de aire comprimido la mejor marca de ALTO performance para carga rápida y constante YONG HENG ®
Mas info imbox. 63970705 
PCP🏴‍☠️ AMMUNITION🎯AIR

[20:41] **+591 76185088:** Buenas noches disculpen alguien sabe donde podría cargar gasolina especial a estas horas?

[21:18] **+591 73451069:** Alguien sabe donde hay gasolina buenas noches

[21:58] **+591 74637856:** Surtidor tarija la especial

[22:18] **+591 68742604:** [Mensaje de voz]

---

## 31 de agosto de 2026

[7:04] __+591 68692115 se unieron mediante el enlace de invitación__

[7:20] **+591 78229658:** Buen día grupo

[7:20] **+591 78229658:** Alguien sabe en qué surtidor están vendiendo gasolina especial

[7:20] **+591 74670785:** Buenos dias. Grupo

[7:21] **+591 74670785:** Si por el dato

[8:15] **+591 72975761:** Aquí en sointa 
En aeropuerto

[10:32] __+591 74559070 se unieron mediante el enlace de invitación__

[12:09] __+591 79267094 se unieron mediante el enlace de invitación__

[13:13] **+591 72903627:** Dónde hay gasolina clarita

[13:14] **+591 72903627:** Avisas xfavor grupo

[13:27] **+591 71869861:** Buenas tardes, disculpen alguien sabe  si se puede comprar diésel en bidón? Gracias

[14:17] **+591 75116516:** [Mensaje de voz]

[18:35] **+591 73483881:** Alguien sabe si en el tarija está la gasolina especial o la plus

---

## 1 de septiembre de 2026

[9:32] **+591 72960135:** Buenos días, una pregunta, alguien sabe en que surtidor están vendiendo gasolina especial (clarita) ahora??

[9:33] **+591 75128182:**
> _+591 72960135: Buenos días, una pregunta, alguien sabe en que surtidor están vendiendo gasolina especial (clarita) ahora??_
X2

[9:50] **+591 76822471:** X3

[9:55] **+591 73483881:** X4

[9:58] **+591 75186906:** X5

[9:59] **+591 69315287:** Yo cargue esta mañana en ypfb del campesino

[10:00] **+591 73483881:**
> _+591 69315287: Yo cargue esta mañana en ypfb del campesino_
Especial ?

[10:27] **+591 64311645:** En tacuarandi nose cual hay pero esta muy clarita

[13:16] **+591 70238365:** [Imagen]

[14:49] **+591 75798904:** _Esperando el mensaje… Esto puede demorar un poco._

[19:13] **+591 71199691:** Buenas noches alguien sabe dónde puedo c as

[19:13] **+591 71199691:** Cargas gasolina especial por favor

[19:48] **+591 78229658:** Buenas noches en qué surtidores están cargando gasolina a esta hora

[19:48] **+591 78229658:** Por favor pasen el dato

[19:50] **+591 71199691:** En el moto Mendez del rancho

[19:52] **+591 67697073:** [Mensaje de album]

[19:53] **+591 67697073:** [Imagen] Vendo laptho hp en buen estado funcionando de 10 cargador más maus interesados al interno

[19:53] **+591 67697073:** [Imagen]

[19:53] **+591 67697073:** [Imagen]

[19:53] **+591 67697073:** [Imagen]

---

## 2 de septiembre de 2026

[7:53] **+591 74537707:** Buenas

[7:54] **+591 74537707:** En qué surtidor no piden la tarjeta bsisa

[7:54] **+591 74537707:** Estoy en de las Vegas y no hay aún gasolina

[7:54] **+591 74541389:**
> _+591 74537707: En qué surtidor no piden la tarjeta bsisa_
Con cualquier gasolina?

[7:54] **+591 74541389:** O especial

[7:54] **+591 74541389:** Si es cualquiera en el surtidor Tarija

[7:54] **+591 74541389:** Porque no pregunte que tipo de gasolina hay

[7:55] **+591 74537707:** Cualquiera

[7:56] **+591 74537707:** Don Daniel alguien sabe

[7:56] **+591 74537707:** O soyta

[7:56] **+591 74537707:** Piden tarjeta?

[8:02] **+591 73491313:** Buen día

[8:03] **+591 73491313:** Hay gasolina especial en el surtidor san Jorge y no hay fila

[8:03] **+591 78237038:** Ex terminal piden tarjeta porsicaso

[8:13] **+591 73361042:**
> _+591 74537707: Piden tarjeta?_
En el campesino no piden bsisa

[8:14] **+591 60280229:** En don daniel no piden

[8:16] **+591 74537707:** Ya gracias

[8:42] **+591 72999358:** UPDS , (las veces que fui no me pidieron besisa)

[8:43] **+591 74541389:**
> _+591 72999358: UPDS , (las veces que fui no me pidieron besisa)_
Hasta ahorita no piden

[8:45] **+591 72999358:** Yo que sepa La Ex Terminal es el único que pide 👀 🏍️

[8:47] **+591 74541389:** También

[8:47] **+591 74541389:** Lo de YPFB

[8:47] **+591 74541389:** Creo

[10:06] **+591 69836650:** _Esperando el mensaje… Esto puede demorar un poco._

[10:07] **+591 69836650:** [Imagen]

[10:33] **+591 72999400:** Alguien sabe donde hay gasolina clarita?

[10:33] **+591 72999400:** Por favor

[10:56] **+591 64303109:**
> _+591 75798904: Imagen_
Donde puedo verlo

[10:59] **+591 77179760:** Buenos días a todos alguien sabe dónde están vendiendo gasolina especial ?
Por favor

[12:05] **+591 65838310:** Si por favor informen

[12:06] **+591 77179760:**
> _+591 65838310: Si por favor informen_
Recién cargue en el campesino YPF sin fila la especial

[12:14] **+591 65838310:** Muchas gracias

[13:11] **+591 75147474:**
> _+591 77179760: Buenos días a todos alguien sabe dónde están vendiendo gasolina especial ?
Por favor_
Surtidor tacuarandi 1 cuadra la fila

[13:26] **+591 71894444:**
> _+591 75147474: Surtidor tacuarandi 1 cuadra la fila_
Ahora solo 5 autos 👌

[14:30] __+591 72989789 se unieron mediante el enlace de invitación__

[14:39] __+591 67995662 añadió a +591 71860494__

[14:46] **+591 78229658:** Las vegas gasolina especial, no ay fila

[15:29] **+591 64695398:** Dónde hay gasolina? Me pasan el dato por favor

[16:54] **+591 75111184:** [Imagen] En tacuarandi gasolina especial

[18:47] **+591 72955920:** Agrupa..especial!

[19:40] **+591 78229658:** Siguen cargando en agrupa pasen el dato por favor

[19:55] **+591 78229658:** Hola

[20:12] **+591 72955920:** Hasta las 18.00 había aún

[20:19] **+591 78229658:** Sigue habiendo gasolina especial en agrupa

[20:20] **+591 78229658:** [Imagen]

[22:20] **+591 75141556:** Gasolina especial donde encuentro a estas horas?

[22:20] **+591 75141556:** 🙏

[22:31] **+591 72948229:** En agrupa seguían vendiendo

[23:32] **+591 69315287:** Se puede pagar con qr alli

[23:32] **+591 69315287:** N saben

[23:33] **+591 78229658:** Con tarjeta y QR se puede

[23:48] **+591 62980357:** En el tacuarandi hay gasolina especial recién cargué de ahi

---

## 3 de septiembre de 2026

[6:48] **+591 72989789:** Buen día 
Donde se puede encontrar hoy la G.E ?

[7:32] **+591 71195758:** Buenos dias alguin sabe donde hay gasolina especial

[7:35] **+591 72999358:** Agrupa

[8:43] **+591 72903627:** Tacuarandi me dijo la chica que toda la semana iva a tener la especial ayer cargue yo de ai

[9:17] **+591 72989789:** Mil gracias queridos amigos

[9:27] **+591 75111184:** Tacuarandi hasta el día sábado estarán con gasolina especial

[9:27] **+591 75111184:** Solo están aceptando efectivo por si acaso

[9:40] **+591 72989789:** En Tacuaradi solo efectivo?

[9:43] **+591 74637856:** Gracias por el dato... cumpa

[11:24] **+591 76174998:** Buenos días saben dónde están vendiendo Etanol?

[11:54] **+591 72989789:** En tacuaradi por si acaso no hay especial solo la plus

[11:55] **+591 74544944:** Mañana por la mañana dijeron

[11:56] **+591 78230364:** Donde hay etanol? Buenas

[12:01] **+591 72989789:** Donde hay especial por favor

[12:31] **+591 61861438:** Alguien sabe si en las vegas están vendiendo gasolina?

[12:35] **+591 78225036:**
> _+591 61861438: Alguien sabe si en las vegas están vendiendo gasolina?_
Si pero la plus

[12:36] **+591 61861438:** La especial donde estan vendiendo

[12:36] **+591 78225036:** Especial campeche

[12:36] **+591 78225036:** Cero fila

[12:37] **+591 78225036:** [Imagen]

[12:39] **+591 78225036:** Solo efectivo pero

[13:24] **+591 64583312:**
> _+591 78225036: Solo efectivo pero_
Bidón? No sabe

[13:53] **+591 67378876:**
> _+591 64583312: Bidón? No sabe_
No venden en bidón!

[14:31] **+591 64583312:** Gracias

[16:59] **+591 63807006:** Buenas tardes alguien sabes dónde están vendiendo la especial?

[17:07] **+591 78709493:** Pasando el coliseo Universitario hay la especial+

[17:52] **+591 60280229:** Don daniel hay especial

[17:52] **+591 60280229:** Akavo de comprar

[17:56] **+591 72989789:** _Se eliminó este mensaje_

[18:15] **+591 60255251:**
> _+591 78709493: Pasando el coliseo Universitario hay la especial+_
Acabo de venir a este surtidor, no tiene gasolina especial, tiene gasolina plus

[18:37] **+591 74541389:** Pero así dice

[18:37] **+591 74541389:** Especial +

[18:37] **+591 74541389:** Es la especial plus

[19:13] **+591 78706211:** Hay diferencia entre la plus y la especial?

[19:13] **+591 78706211:** [Sticker]

[19:13] **+591 68707751:**
> _+591 78706211: Hay diferencia entre la plus y la especial?_
El color

[21:47] **+591 68707751:** Alguien sabe dónde hay gasolina especial a esta hora

[21:55] **+591 68707751:** Pasen el dato

[22:35] **+591 65821266:** Ypfb morros blancos creo q hay

---

## 4 de septiembre de 2026

[6:58] **+591 71195758:** Buenos dias alguien sabe dibde hay gasolina especial

[6:58] **+591 71195758:** Les agradeceria el dato gracias

[7:01] **+591 72989789:** Yo también agradecería el dato sobre gasolina especial 
En tacuarandi me confiarían a las 8:30

[7:27] **+591 68695886:**
> _+591 71195758: Buenos dias alguien sabe dibde hay gasolina especial_
Buenos días podrían informar en donde hay la gasolina especial porfavor

[7:58] **+591 68695886:**
> _+591 68695886: Buenos días podrían informar en donde hay la gasolina especial porfavor_
Si ya tendrían información me podrían informar

[8:01] **+591 72999358:** Surtidor Moto Mendez tendrá la especial, capas a de unos 50 minutos llegué la cisterna a descargar

[8:04] **+591 68695886:** Muchas gracias

[9:25] **+591 73483881:**
> _+591 72989789: Yo también agradecería el dato sobre gasolina especial 
En tacuarandi me confiarían a las 8:30_
Que le dijeron

[9:27] **+591 69317750:**
> _+591 72989789: Yo también agradecería el dato sobre gasolina especial 
En tacuarandi me confiarían a las 8:30_
X2 amigo  nos confirma por favor

[9:29] **+591 69307503:** Hay Gasolina especial en el surtidor del campesino

[11:07] **+591 72989789:** Tacusrandi solo la plus confirmado

[11:08] **+591 72989789:** Perdón cuál es el surtidor del campesino?

[11:25] **+591 72977230:**
> _+591 72989789: Perdón cuál es el surtidor del campesino?_
Es el de YPF muchos se confunden por la fila por los micros que están estacionados haciendo fila para el diésel

[13:38] **+591 72989789:** Querido grupo estoy cargando en este momento la GASOLINA ESPECIAL en las vegas 
No hay cola

[13:38] **+591 72989789:** [Imagen]

[14:18] **+591 79251139:** Buenas tardes

[14:18] **+591 79251139:** Disculpen alguien sabe dónde hay gasolina de la clarita por favor

[14:20] **+591 79251139:**
> _+591 72989789: Querido grupo estoy cargando en este momento la GASOLINA ESPECIAL en las vegas 
No hay cola_
No saben si todavía hay  gasolina clarita

[14:20] **+591 79251139:** En las vegas

[14:20] **+591 79251139:** ??

[14:22] **+591 72989789:** Yo cargué en las vegas LA ESPECIAL, ESA 
ES la clarita, NO LA ESPECIAL PLUS

[14:23] **+591 78249245:** especial en las vegas

[14:23] **+591 78249245:** acabo de cargar

[14:23] **+591 78249245:** cero fila

[15:51] **+591 60272671:**
> _+591 78249245: especial en las vegas_
Verda es la especial .?(

[15:51] **+591 60272671:** Confirmen por faa

[15:51] **+591 74637856:** Especial en la vegas

[15:51] **+591 72989789:** Si si yo cargué Especial ‼️

[15:51] **+591 72963113:** Campesino especial

[15:51] **+591 72963113:** 0 fila

[15:51] **+591 72963113:** La vegas se acabo!!!

[17:25] **+591 69312879:** Buenas tardes grupo

[17:25] **+591 69312879:** Alguien sabe donde están cargando gasolina especial o etanol en el campesino se acabó

[17:48] **+591 78229658:** Gasolina especial en agrupa

[17:51] **+591 69312879:** Gracias

[17:54] **+591 75186906:** _Esperando el mensaje… Esto puede demorar un poco._

[20:15] **+591 72989789:** Ya descargaron en Tacuarandi gasolina especial a hrs 18

[21:47] **+591 78700752:**
> _+591 72989789: Ya descargaron en Tacuarandi gasolina especial a hrs 18_
Saben hasta que hora de la noche atienden?

[21:49] **+591 72989789:** No lo sé

[21:57] **+591 74548288:** _Se eliminó este mensaje_

[22:42] **+591 72945325:** La especial en el tacuarandi sin fila

---

## 5 de septiembre de 2026

[8:31] **+591 71192881:** Buen dia hoy saben alguien dnde estan vendiendo gasolina especial

[8:51] **+591 72997886:** Buenos días en el campesino hay especial

[9:17] **+591 72943744:** Buenos días no saben si llego etanol a moto Méndez?

[9:19] **+591 72943744:** Se los agradecería el dato

[10:28] **+591 75134447:** Buenos días gasolina especial dónde están vendiendo en el campesino no hay

[10:32] **+591 78692302:** Saben dónde hay etanol?

[10:42] **+591 75798904:** _Esperando el mensaje… Esto puede demorar un poco._

[10:55] **+591 71198548:** Buenos días

[10:55] **+591 71198548:** Alguien sabe en qué surtidor están vendiendo gasolina especial clarita

[10:56] **+591 71198548:** Pasen el dato por favor

[11:06] **+591 76174998:** Saben si en la ex terminal hay etanol?

[11:20] **+591 72989789:**
> _+591 71198548: Pasen el dato por favor_
Tacuarandi

[11:20] **+591 71198548:** Gracias

[11:38] **+591 60272671:**
> _+591 72989789: Tacuarandi_
Alguien sabe si sigue habiendo especial en el tacuarindi

[11:38] **+591 60272671:** .?

[11:39] **+591 72989789:** Debe haber ayer descargaron a las18:30

[11:47] **+591 75153879:** https://vt.tiktok.com/ZS9Sd382JvYdt-I6Rq0/

[12:53] **+591 68707751:** Alguien sabe dónde ay gasolina especial?

[12:53] **+591 63807006:** Tacuarandi hay especial

[12:54] **+591 68707751:** Gracias

[13:04] **+591 75515740:** Gracias

[14:11] **+591 78707745:** Gasolina especial en Don Daniel

[14:23] **+591 75127881:** Alguien sabe donde hay gasolina etanol?

[14:33] **+591 75515740:** En que surtidor hay gasolina especial?

[14:34] **+591 75515740:** Alguien podría avisarme por favor

[14:47] **+591 65821266:**
> _+591 75515740: En que surtidor hay gasolina especial?_
Tacuarandi

[14:47] **+591 75515740:** Gracias

[15:34] **+591 72964737:** En el surtidor del Portillo hay Etanol

[16:04] **+591 72989789:** Pasando por tacuarandi sin fila

[17:36] **+591 75798904:** _Esperando el mensaje… Esto puede demorar un poco._

---

## 6 de septiembre de 2026

[7:46] __+591 69302330 se unieron mediante el enlace de invitación__

[7:46] __+591 74580863 se unieron mediante el enlace de invitación__

[7:46] __+591 74511868 se unieron mediante el enlace de invitación__

[11:17] **+591 71197917:** Buenos días No saben dónde hay gasolina especial

[11:37] **+591 78250221:** Buen día si por favor donde habrá gasolina especial...?

[13:43] **+591 60275451:** Alguien cargó gasolina especial hoy? Donde?

[15:33] **+591 75127881:** Buenas tardes

[15:33] **+591 75127881:** Alguien sabe si hay etanol  en el surtidor  sointa

[18:57] __+591 71871938 se unieron mediante el enlace de invitación__

[21:23] __+591 73863106 se unieron mediante el enlace de invitación__

[21:31] __+591 64567196 se unieron mediante el enlace de invitación__

[21:31] __+591 78707264 se unieron mediante el enlace de invitación__

[21:39] __+591 68694396 se unieron mediante el enlace de invitación__

---

## 7 de septiembre de 2026

[6:43] **+591 72947156:** Buen dia alguien sabe donde estan vendiendo gasolina especial porfavor

[7:06] **+591 78229658:** X2 pasen el dato por favor

[7:47] **+591 78229658:**
> _+591 72947156: Buen dia alguien sabe donde estan vendiendo gasolina especial porfavor_
Buen día grupo, Pasen el dato

[8:14] __+591 63278877 se unieron mediante el enlace de invitación__

[8:14] __+591 69309375 se unieron mediante el enlace de invitación__

[8:16] **+591 63278877:** Buenos días 
De que trata esté grupo?

[8:34] **+591 68707751:** Información sobre dónde,  cuando y de cual combustible ay en Tarija.

[10:35] **+591 72973019:** Buendia alguien save donde están cargando gasolina especial

[10:43] **+591 72907123:** Buen día alguien sabe donde hay gasolina especial o etanol?

[10:50] **+591 63278877:** Dónde están vendiendo gasolina con hetanol?
Quien sabe porque yo solo cargo en el surtidor moto Mendez con hetanol pero en la cuidad alguien sabe?

[10:58] **+591 68405155:** [Reenviado] [Imagen] San geronimo esta descargando especial

[11:16] **+591 75175156:** [Reenviado] [Imagen]

[13:43] **+591 71894444:** Surtidores con gasolina especial por favor

[13:45] **+591 78707264:** San Gerónimo

[13:47] **+591 67378987:** [Mensaje de album]

[13:47] **+591 67378987:** [Video] Buenas tardes alguien que me pueda dar información de esa vagoneta esos maleantes Me robaron la batería de mi ipsum

[13:47] **+591 67378987:** [Imagen]

[16:21] **+591 72996706:**
> _+591 78707264: San Gerónimo_
Será que venden en bidón solo con fotocopia?

[16:23] **+591 78707264:**
> _+591 72996706: Será que venden en bidón solo con fotocopia?_
Si yo compré así

[16:24] **+591 72996706:** Muchas gracias enseguida voy por ahí... Porq en sointa solo venden si estas registrado en ese siscarguio

[16:25] **+591 76837768:** [Imagen] Están vendiendo con bidón

[16:27] **+591 63278877:** BUSCÓ GASOLINA CON HETANOL ALGUIEN SABE

[16:34] __+591 74524750 se unieron mediante el enlace de invitación__

[17:25] **+591 72966160:** Hay gasolina especial en el surtidor Tarija

[19:51] **+591 69623125:** _Un admin., +591 67995662, eliminó este mensaje._

[19:51] **+591 69623125:** _Un admin., +591 67995662, eliminó este mensaje._

[21:21] __+591 75123017 se unieron mediante el enlace de invitación__

[21:49] **+591 63504498:** Alguien sabe en qué surtidos hay etanol

---

## 8 de septiembre de 2026

[7:59] **+591 75140604:** Buenos  dias donde hay gasolina especial

[8:10] **+591 73451554:** Buenos días en que surtidor habrá gasolina especial por favor si saben

[9:09] **+591 76174998:** Buen día saben donde hay gasolina etanol o especial ahurita ?

[10:03] **+591 69623125:** _Un admin., +591 67995662, eliminó este mensaje._

[10:03] **+591 69623125:** _Un admin., +591 67995662, eliminó este mensaje._

[12:06] **+591 67378876:** [Imagen] Especial en el campesino!

[12:19] **+591 71192881:** Alguien sabe en las velas q gasolina hay ? Xfa

[12:53] **+591 78229658:** Ay gasolina especial en sointa

[12:57] **+591 76194043:** Alguien sabe dónde hay etanol

[13:21] **+591 79256927:**
> _+591 76194043: Alguien sabe dónde hay etanol_
Hace media hora cargue etanol en el agrupa.

[13:46] **+591 72969241:** [Reenviado] [Imagen]

[13:46] **+591 72969241:** Si alguien vive por la zona central San Roque y ve a mi gatita por favor estamos buscandola, perdón por publicar

[13:58] **+591 69623125:** _Un admin., +591 67995662, eliminó este mensaje._

[13:58] **+591 69623125:** _Un admin., +591 67995662, eliminó este mensaje._

[14:08] **+591 60261840:** Buenas tardes grupo

[14:08] **+591 60261840:** En qué lugar hay gasolina especial?

[14:08] **+591 60261840:** Para poder cargar

[14:11] **+591 72947156:** Buenas tardes hoy hay gasolina especial en el surtidor del puente san martin

[14:14] **+591 60261840:** Solo ese

[14:14] **+591 60261840:** ?

[15:20] **+591 73451554:** Gracias

[15:26] **+591 72985600:** Donde hay especial

[15:35] **+591 76836904:** Etanol  llegó?

[15:35] **+591 78692302:**
> _+591 76836904: Etanol  llegó?_
en agrupa dijeron en otro grupo que hay

[15:58] **+591 64695398:** Gasolina especial o plus, dónde hay?

[15:59] **+591 69312879:**
> _+591 69623125: Video_
Saquen a ese depravado

[16:04] **+591 73361042:** En el surtidor Tarija hay especial

[16:06] **+591 75515740:** [Mensaje de album]

[16:06] **+591 75515740:** [Imagen]

[16:06] **+591 75515740:** [Video]

[16:59] **+591 64695398:** Saben si hay gasolina en las Vegas?

[17:25] **+591 63278877:** Alguien sabe si es recomendable comprar en estos momentos dólares porque hacé tiempo ya dejé de comprar 
Que opinan?

[17:40] **+591 64695398:** Dónde están cargando gasolina en bidón disculpen

[17:41] **+591 78230364:** Surtidor de san Geronimo hay especial

[17:42] **+591 64695398:** Cuál es ese surtidor, el que está cerca de la plaza de San Gerónimo?

[17:43] **+591 64695398:** Ese es el panamericano?

[17:44] **+591 64695398:** Me avisan por fa

[17:46] **+591 67378876:**
> _+591 64695398: Ese es el panamericano?_
Más conocido como: surtidor san Gerónimo

[17:47] **+591 64695398:** Ahh listo colega gracias

[19:34] **+591 69623125:** _Un admin., +591 67995662, eliminó este mensaje._

[19:34] **+591 69623125:** _Un admin., +591 67995662, eliminó este mensaje._

[20:27] **+591 63794699:**
> _+591 69623125: Imagen_
Voten a esa gente

[20:33] **+591 78707264:**
> _+591 69623125: Imagen_
X2

[20:36] **+591 71894444:** Si che webadas mandan saquenlo

[20:39] **+591 63278877:**
> _+591 69623125: Imagen_
Si saquen lo

[20:41] **+591 73361042:** Saquenlo

---

## 9 de septiembre de 2026

[3:05] **+591 74543036:** [Mensaje de voz]

[6:44] **+591 60261840:** Alguien sabe dónde están vendiendo gasolina especial hoy??

[6:48] __+591 75116794 se unieron mediante el enlace de invitación__

[6:48] __+591 73499430 se unieron mediante el enlace de invitación__

[6:49] __+591 67995662 eliminó a +591 69623125__

[7:21] **+591 68686988:** Si saquen lo no cambia sus videos

[7:38] **+591 75141556:** Buenos dias

[7:39] **+591 75141556:** Gasolina especial alguien save?? Enque surtidor hay?

[7:51] **+591 72945844:**
> _+591 75141556: Gasolina especial alguien save?? Enque surtidor hay?_
X 2

[8:00] **+591 75141556:** Especial en ypfb de morros blancos

[8:00] **+591 72997886:** En el campesino hay especial

[8:00] **+591 75141556:** [Imagen]

[8:29] **+591 76181373:** Buenos días a todos otra surtidor con gasolina especial

[8:40] **+591 60251309:** @~😀LUIS ANGEL😊 buen día, pueden agregar al grupo a  este número por favor 62854984

[8:50] **+591 68707751:**
> _+591 76181373: Buenos días a todos otra surtidor con gasolina especial_
Campesino y ypfb dijeron

[9:26] **+591 75175156:** Buenos días 
Por favor ETANOL DONDE ESTAN VENDIENDO?

[9:27] **+591 61989107:** _Se eliminó este mensaje_

[9:27] **+591 61989107:** _Se eliminó este mensaje_

[9:27] **+591 61989107:** _Se eliminó este mensaje_

[9:27] **+591 61989107:** _Se eliminó este mensaje_

[9:38] **+591 63278877:**
> _+591 75175156: Buenos días 
Por favor ETANOL DONDE ESTAN VENDIENDO?_
Ese hetanol busco pero no encuentro

[9:43] **+591 72999358:**
> _+591 63278877: Ese hetanol busco pero no encuentro_
Viernes  - Sábado - Domingo entre esos días nomás venden

[9:48] **+591 75175156:**
> _+591 72999358: Viernes  - Sábado - Domingo entre esos días nomás venden_
Gracias por el dato

[10:40] **+591 63278877:** CONFIRMO QUE EN EL SURTIDOR YPFB HAY GASOLINA ESPECIAL PORQUE RECIÉN CARGUE.

[10:40] **+591 78225036:** Gasolina especial en el campesino

[11:12] **+591 72990143:** https://www.pistacho.app/ca-rimh

[12:01] **+591 77170522:** Buen dia,  gasolina especial en el Tarija

[13:44] **+591 75132648:**
> _+591 75141556: Especial en ypfb de morros blancos_
Buenas tardes estan vendiendo en bidón

[13:44] **+591 75132648:** ???

[13:52] **+591 69330305:** Dónde hay gasolina especial ? Aparte de morros blancos

[13:57] **+591 78249245:** Buenas tardes donde encuentro gasolina especial

[14:12] **+591 73483881:**
> _+591 78249245: Buenas tardes donde encuentro gasolina especial_
Sigue habiendo en el Tarija

[14:56] **+591 75144558:** buenas tardes donde se consigue diesel

[14:57] **+591 75144558:** en que surtidor ?

[15:32] **+591 78232702:** Etanol sin fila....don daniel

[18:27] __+591 71874955 se unieron mediante el enlace de invitación__

[18:27] __+591 72978253 se unieron mediante el enlace de invitación__

[18:37] **+591 75515740:** Buenas tardes 
Alguien podría avisarme donde hay gasolina especial?

[18:38] **+591 60261840:** Si alguien sabe

[18:38] **+591 60261840:** ?

[18:38] **+591 60261840:** Gasolina especial

[18:47] **+591 71872723:**
> _+591 60261840: Gasolina especial_
X2

[18:55] **+591 75515740:** Gasolina especial en Surtidor De la Domingo Savio hay fila, no mucha

[19:02] **+591 69694946:** _Un admin., +591 67995662, eliminó este mensaje._

[19:33] **+591 79284222:** Alguien sabe dónde están cargando gasolina

[19:34] **+591 79284222:** Cualquiera especial o no especial

[19:35] **+591 72947156:** hay gasolina especial surtidor del puente San Martin

[20:18] **+591 72860656:** Dónde me cargan gasolina sin tarjeta de moto ?

[20:19] **+591 72942858:** San geronimo recién cargue la especial

[20:19] **+591 72942858:** Las vegas la plus

[20:24] __+591 75051616 se unieron mediante el enlace de invitación__

[20:24] **+591 60262808:** _Un admin., +591 67995662, eliminó este mensaje._

---

## 10 de septiembre de 2026

[4:24] __+591 65819641 se unieron mediante el enlace de invitación__

[4:55] __+591 70212667 se unieron mediante el enlace de invitación__

[7:33] **+591 78229658:** Buen día grupo

[7:33] **+591 78229658:** Alguien sabe dónde están vendiendo gasolina especial, por favor pasen el dato

[8:28] **+591 73491313:** Buen día

[8:29] **+591 73491313:** Disculpen no saben dónde hay gasolina especial

[8:41] **+591 64311645:** Parada del chaco sin fila

[8:41] **+591 64311645:** Cargan bidon

[8:41] **+591 64311645:** Hasta 20L

[8:47] **+591 71894444:** Ñerda esa información.....
Gracias 👌

[8:48] **+591 75116794:** Disculpen que piden para cargan en bidón ?

[8:49] **+591 60251131:** En el Tarija estan con la plus

[8:51] **+591 71872723:**
> _+591 75116794: Disculpen que piden para cargan en bidón ?_
Fotocopia del CI

[9:45] **+591 72989789:** Favor incluir al 72978968

[9:53] **+591 63970705:** _Un admin., +591 67995662, eliminó este mensaje._

[9:55] **+591 76194043:** Buen día

[9:56] **+591 76194043:** En qué surtidor hay etanol me podrían decir porfavor

[10:24] **+591 79251139:** Buen día

[10:25] **+591 79251139:** Disculpen alguien sabe dónde hay gasolina especial de la clarita

[10:25] **+591 79251139:** Me pasa el dato por favor

[11:01] **+591 70216466:** En la parada del Chaco, y no hay fila

[11:16] **+591 79251139:** Bueno muchas gracias

[12:58] __+591 69314968 se unieron mediante el enlace de invitación__

[12:58] __+591 70229624 se unieron mediante el enlace de invitación__

[12:58] __+591 60274374 se unieron mediante el enlace de invitación__

[12:59] __+591 78230354 se unieron mediante el enlace de invitación__

[12:59] __+591 75121882 se unieron mediante el enlace de invitación__

[12:59] __+591 71167615 se unieron mediante el enlace de invitación__

[12:59] __+591 75133914 se unieron mediante el enlace de invitación__

[12:59] __+591 68690929 se unieron mediante el enlace de invitación__

[12:59] __+591 64344810 se unieron mediante el enlace de invitación__

[12:59] __+591 68717358 se unieron mediante el enlace de invitación__

[13:11] **+591 65811053:** Buenas tardes, alguien sabe si en el YPFB del campesino tienen gasolina especial?

[13:19] **+591 69330305:**
> _+591 65811053: Buenas tardes, alguien sabe si en el YPFB del campesino tienen gasolina especial?_
Si acabo de cargar ahi

[13:34] **+591 65811053:** Gracias

[18:02] **+591 69836650:** _Un admin., +591 67995662, eliminó este mensaje._

[18:02] **+591 69836650:** _Un admin., +591 67995662, eliminó este mensaje._

[18:48] **+54 9 3875 03-0038:** _Un admin., +591 67995662, eliminó este mensaje._

[19:13] **+591 71897189:** Buenas tardes donde están vendiendo gasolina  es este momento

[19:13] **+591 71897189:** Alguien me podría decir

[19:14] **+591 71897189:** X favor

[20:03] **+591 67378876:**
> _+54 9 3875 03-0038: Hermosa guitarriada_
Jajajaja

[20:25] **+591 73361042:**
> _+591 71897189: X favor_
En el agrupa están vendiendo

[20:29] **+591 71897189:** Ok gracias

[21:27] **+591 71872723:** Especial en el surtidor YPFB de la carcel sin fila

[21:28] **+591 65821266:** A las motos piden carnet del bsisa?

[21:32] **+591 71873983:** Buenas noches

[21:33] **+591 71873983:** Me pasarían el link del grupo porfa

[21:46] **+591 71872723:**
> _+591 65821266: A las motos piden carnet del bsisa?_
No se pero venden en bidon

[21:56] **+591 65819641:** Surtidor de portillo hay especial

[22:08] **+591 69836650:** _Un admin., +591 67995662, eliminó este mensaje._

---

## 11 de septiembre de 2026

[1:28] __+591 74558462 se unieron mediante el enlace de invitación__

[1:35] __+591 67995662 eliminó a +591 69836650__

[1:37] __+591 67995662 eliminó a +591 72989789__

[6:12] **+591 78236766:** Buenos días

[6:12] **+591 78236766:** Alguien sabe dónde hay gasolina especial

[6:12] **+591 78236766:** ??

[6:54] **+591 65819641:**
> _+591 78236766: Alguien sabe dónde hay gasolina especial_
Portillo

[6:54] **+591 65819641:** Tiene

[7:29] **+591 71873983:**
> _+591 65819641: Portillo_
Cuál es ese disculpe?

[7:33] **+591 65819641:** En la extranca carretera hacia el valle y hacia entre ríos

[7:37] **+591 71873983:**
> _+591 65819641: En la extranca carretera hacia el valle y hacia entre ríos_
Muchas gracias

[7:39] **+591 69312879:**
> _+591 65819641: En la extranca carretera hacia el valle y hacia entre ríos_
Buen día a todos aparte de este surtidor no saben en que otro surtidor están vendiendo gasolina especial

[7:44] **+591 68694396:**
> _+591 69312879: Buen día a todos aparte de este surtidor no saben en que otro surtidor están vendiendo gasolina especial_
Sointa están vendiendo gasolina especial

[7:48] **+591 75133007:** Ayer noche cargue del surtidor de Astra atrás y estaba bien

[7:58] **+591 71866559:**
> _+591 68694396: Sointa están vendiendo gasolina especial_
Ahorita están vendiendo ahí?

[8:01] **+591 64018978:**
> _+591 68694396: Sointa están vendiendo gasolina especial_
Saben si venden en vidon con fotocopia C.I

[8:02] **+591 60274374:**
> _+591 64018978: Saben si venden en vidon con fotocopia C.I_
Si, es con fotocopia de carnet

[8:03] **+591 61861438:**
> _+591 64018978: Saben si venden en vidon con fotocopia C.I_
En soita ya no venden en bidón creo yo fui antes de ayer y no me quisieron cargar

[8:05] **+591 69330305:**
> _+591 69312879: Buen día a todos aparte de este surtidor no saben en que otro surtidor están vendiendo gasolina especial_
Campesino YPFB

[8:06] **+591 64018978:**
> _+591 61861438: En soita ya no venden en bidón creo yo fui antes de ayer y no me quisieron cargar_
Gracias

[8:06] **+591 68694396:**
> _+591 64018978: Saben si venden en vidon con fotocopia C.I_
Venden con fotocopia nada mas

[8:07] **+591 64018978:**
> _+591 68694396: Venden con fotocopia nada mas_
Gracias

[8:07] **+591 68694396:**
> _+591 61861438: En soita ya no venden en bidón creo yo fui antes de ayer y no me quisieron cargar_
Ayer compré en bidón solo fotocopia nada mas

[8:08] **+591 69312879:**
> _+591 69330305: Campesino YPFB_
Gracias mi estimado

[8:32] **+591 63970705:** [Imagen] Disponibles los compresores de aire comprimido la mejor marca de ALTO performance para carga rápida y constante YONG HENG ®
Mas info imbox. 63970705 
PCP🏴‍☠️ AMMUNITION🎯AIR

[8:52] **+591 71894444:** En sointa nada de fila prácticamente

[8:52] **+591 71894444:** Gasolina especial

[8:57] **+591 71871938:** Disculpen adonde es surtidor sointa

[8:57] **+591 71871938:** Por favor

[8:59] **+591 73451554:** Al lado de luzam comienzo circunvalacion

[9:00] **+591 71871938:** 👍muchas gracias

[10:19] **+591 68697122:** Buenos días ,alguien sabe dónde puedo conseguir etanol

[11:36] **+591 74540793:** Buenos días, en dónde pillo gasolina especial?

[11:37] **+591 72960135:** Buenos días grupo, alguien sabe en que surtidor están vendiendo la gasolina especial (la blanquita)??

[11:43] **+591 72945325:** En sointa la especial

[11:52] **+591 72960135:** Se acabó la gasolina especial en Sointa

[11:52] **+591 72960135:** No saben de otro surtidor qué esté vendiendo?

[11:56] **+591 74540793:** Saben de otro surtidor?

[12:42] **+591 75515740:** Surtidor  Domingo savio 
Hay gasolina especial

[13:08] __+591 67995662 añadió a +591 72989789__

[14:13] **+591 75117506:** _Esperando el mensaje… Esto puede demorar un poco._

[14:13] **+591 75117506:** 🤔

[14:22] **+591 72973019:** Buenas tardes, saben  en que surtidor  vendiendo gasolina especial

[14:42] **+591 69312879:** En el ypf del campesino

[14:48] **+591 72973019:** OK gracias

[14:51] **+591 61862568:** En el Surtidor Tarija hay especial...

[14:52] **+591 72989789:** Perdón cuál es el surtidor Tarija ?

[14:57] **+591 71894444:** De la Domingo Sabio

[15:29] **+591 72974985:** Buenas tarde por avisar si en algún surtidor están cargando enanos por favor

[16:17] **+591 75111184:** Sigue habiendo gasolina especial en el surtidor el Portillo, acabo de cargar

[16:31] **+591 73483881:** Sigue habiendo en el campe

[16:31] **+591 73483881:** ?

[17:02] **+591 70217778:**
> _+591 72974985: Buenas tarde por avisar si en algún surtidor están cargando enanos por favor_
Enanos no creo, debe ser ilegal!

[17:29] **+591 72964737:** para los q buscan etanol hay en la ex terminal.

[18:04] **+591 75175156:**
> _+591 72964737: para los q buscan etanol hay en la ex terminal._
Gracias!!!

[18:15] **+591 63807006:** Buenas noches alguien sabe donde hay especial?

[18:17] **+591 63807006:** Gracias!!

[18:17] **+591 75121882:** Buenas...hay en la Domingo Savio

[19:20] **+591 71872723:** Gasolina especial surtidor Domingo Sabio poca fila

[19:58] **+591 65821266:** Alguien sabe si en el sointa o agrupa hay gasolina especial

[19:59] **+591 65819641:** Sointa tiene especial

[19:59] **+591 65819641:** Agrupa tiene plus

[22:01] **+591 78249245:** Algun surtidpr q temga especial a esta hora?

[22:23] **+591 65821266:** Surtidor de ypfb pasando el agrupa tiene la especial

[22:23] **+591 65821266:** Recién cargue y 0 fila

[22:35] **+591 65819641:** Agrupa tiene plus

[22:35] **+591 65819641:**
> _+591 78249245: Algun surtidpr q temga especial a esta hora?_
Portillo

---

## 12 de septiembre de 2026

[7:13] **+54 9 3886 41-3903:** [Mensaje de voz]

[7:42] **+591 73361042:** Buendía hoy día no saben dónde hay gasolina especial

[7:50] **+591 65819641:** Portillo tiene etanol y especial

[9:19] **+591 76185088:** Buen dia saben si en el sointa hay gasolina especial?

[9:52] **+591 74637856:** Donde estan cargando especial xfa...

[10:18] **+591 69329302:**
> _+591 74637856: Donde estan cargando especial xfa..._
?

[10:26] **+591 76547557:** _Se eliminó este mensaje_

[10:45] **+591 74637856:** Avisen xfa...

[10:48] **+591 69327934:** Etanol ?

[10:48] **+591 69327934:** Alguien n sabe

[11:39] **+591 65819641:**
> _+591 69327934: Etanol ?_
Portillo Agrupa y sointa tienen

[11:40] **+591 65819641:** Hoy tenían programado etanol esas estaciones

[11:51] **+591 64695398:** Alguien sabe dónde hay gasolina plus o especial?

[12:58] **+591 73491313:** Buen día disculpen ,alguien sabe dónde están vendiendo gasolina especial ?

[13:02] **+591 78692302:** Buenas tardes, saben si hay etanol en agrupa? O don Daniel?

[13:18] **+591 73491313:** Si sabe alguien donde hay gasolina especial se le agradece x su información x favor

[14:19] **+591 64695398:** ???

[14:19] **+591 64695398:** Saben dónde puedo conseguir gasolina?

[14:23] **+591 73361042:** Surtidor ypfb del campesino

[14:23] **+591 64695398:** Para cargar en bidón, especial o plus

[14:23] **+591 73361042:** Hay especial pero no venden en bidón

[16:39] **+591 72973019:** Buenas tardes, alguien sabe si están vendiendo gasolina especial, so into San Jorge o más abajo

[17:19] **+591 71197917:** Portillo hay especial

[18:21] **+591 63278877:** Alguien sabe dónde están vendiendo gasolina especial o con hetanol ahora?

[18:21] **+591 69327934:** Moto Méndez

[18:21] **+591 69327934:** Etanol

[18:22] **+591 72949929:** Buenas tardes en agrupa me dijo tendrán Etanol hasta mañana

[18:23] **+591 63278877:**
> _+591 72949929: Buenas tardes en agrupa me dijo tendrán Etanol hasta mañana_
Bueno gracias por la información

[18:24] **+591 63278877:**
> _+591 72949929: Buenas tardes en agrupa me dijo tendrán Etanol hasta mañana_
Tienen o tendrá mañana?

[18:29] **+591 63278877:**
> _+591 63278877: Tienen o tendrá mañana?_
Alguien sabe

[18:38] **+591 78692302:**
> _+591 63278877: Alguien sabe dónde están vendiendo gasolina especial o con hetanol ahora?_
Etanol sointa aeropuerto

[18:41] **+591 72949929:**
> _+591 63278877: Tienen o tendrá mañana?_
Hoy compré y eso me dijeron

---

## 13 de septiembre de 2026

[15:17] **+591 68707751:** No saben dónde ay gasolina especial

[15:23] **+591 71199691:** En el molle

[15:52] **+591 69310319:** Avia en el surtido del. Campesino

[15:52] **+591 69310319:** Yo cargue ahi

[16:27] **+591 72990143:** Alguien sabe a qué altura está San Roquito???

[16:51] **+591 72942824:** Que tal es la gasolina de tacuarandi

[18:42] **+591 78236766:** Alguien sabe dónde hay gasolina especial??

[18:47] **+591 63278877:** En sointa había a las 12 y la hetanol también

[19:17] **+591 72942824:** Que diferencia hay entre la gasolina plus y la especial ???

[19:28] **+591 71895290:** Saben si hay gasolina en las vegas

[19:32] __+591 72978968 se unieron mediante el enlace de invitación__

[19:32] __+591 62342849 se unieron mediante el enlace de invitación__

[19:50] **+591 61861438:** Buenas

[19:50] **+591 61861438:** Alguien sabe si están cargando gasolina por la ex terminal en bidon

[20:15] **+591 63278877:**
> _+591 72942824: Que diferencia hay entre la gasolina plus y la especial ???_
La plus genera carbonilla más rápido que la especial es más lenta pero con ahora casi son lo mismo combustible pero para el bien de cada uno se recomienda más la gasolina blanca que es la Gasolina especial o la Hetanol.

[20:21] **+591 68707751:** Y dónde ay la especial saben?

[20:42] **+591 61861438:** Alguien sabe si en ypfb están cargando gasolina

[21:19] **+591 68707751:** No

[21:19] **+591 68707751:** Etanol ay en sointa

[21:23] __+591 73498913 se unieron mediante el enlace de invitación__

[21:59] **+591 61861438:** En agrupa estan cargando

[23:43] **+591 72945180:**
> _+591 61861438: En agrupa estan cargando_
Si están cargando

---

## 14 de septiembre de 2026

[9:48] **+591 64326376:** Buenas

[9:48] **+591 64326376:** Donde hay gasolina especial

[9:48] **+591 64326376:** ?

[9:59] **+591 72999400:** Alguien sabe donde hay especial?

[10:46] **+591 72960135:** Buenos días grupo, alguien sabe en que surtidor están vendiendo la gasolina especial (la blanca)??

[10:46] **+591 64695398:** Saben si están dando gasolina en las Vegas?

[10:52] **+591 72999400:** En tacuarandi

[10:52] **+591 72999400:** Me dijeron que era especial la gasolina que estaban vendiendo

[11:04] **+591 72960135:** Hay Gasolina Especial en la estación Tacuarandi, no hay mucha fila

[13:04] **+591 64315170:** Buenas tardes disculpen alguien q sepa donde hay diesel

[13:28] **+591 68698136:** Confirmo

[13:28] **+591 68698136:** En tacuarandi especial

[13:28] **+591 68698136:** Cerooo fila

[14:01] **+591 78249245:**
> _+591 68698136: Cerooo fila_
Gracias

[15:47] **+591 75175156:** Hola buenas tardes 
Por favor alguien sabe donde estan vendiendo ETANOL??

[15:56] __+591 73368005 se unieron mediante el enlace de invitación__

[18:56] **+591 71195758:** Donde hay gasolina especial a esta hora alguien sabe si tacuarandi sigue teniego gasolina

[18:56] **+591 71195758:** Me ayudan con el dato  por favor

[19:08] **+591 76836904:**
> _+591 71195758: Donde hay gasolina especial a esta hora alguien sabe si tacuarandi sigue teniego gasolina_
Estaba con conos cuando pase

[19:09] **+591 75149463:** [Imagen]

[19:15] **+591 71195758:**
> _+591 76836904: Estaba con conos cuando pase_
Uy gracias

---

## 15 de septiembre de 2026

[8:13] **+591 71195758:** Buen dia alguien sabe donde hay gasolina especial  hoy

[8:38] **+591 71894444:** Por si acaso pase por el Tarija y están con la plus

Si alguien sabe de la especial avisan por favor.

[8:54] **+591 62342849:** Buenos días compañeros aquí pregunté en surtidor Daniel

[8:54] **+591 62342849:** Y habrá la especial a medio día

[9:19] **+591 78229658:** Alguien sabe que gasolina están cargando en las vegas

[9:35] **+591 62342849:** Especial en el campesino

[14:27] **+591 69327934:** [Imagen]

[14:27] **+591 69327934:** Tacuarandi

[14:27] **+591 69327934:** Etanol

[14:30] **+591 72960135:** Buenas tardes, alguien sabe en que surtidor están vendiendo la gasolina especial (la blanca)??

[14:34] **+591 65819641:**
> _+591 72960135: Buenas tardes, alguien sabe en que surtidor están vendiendo la gasolina especial (la blanca)??_
Agrupa

[14:45] **+591 72989789:** En tacuarandi o parada  al chaco alguien sabe si hay especial?

[15:21] **+591 75117506:** Acabo de cargar en YPFB del campesino la especial no hay fila

[15:21] **+591 75117506:** Ni un alma vayan aprovechen

[15:47] **+591 68707751:** Gracias

[16:47] **+591 72989789:** En tacuarandi llegó Especial toda la semana, fuente de primera mano

[16:49] **+591 72989789:** Perdón rectifico llegará mañana tipo 10 me acaban de confirmar

[16:51] **+591 72989789:** Yo confirmo mañana para mayo seguridad 
Saludos

[17:47] __+591 71832713 se unieron mediante el enlace de invitación__

[17:47] __+591 75132668 se unieron mediante el enlace de invitación__

---

## 16 de septiembre de 2026

[7:37] **+591 71894444:** Buen día
A esta hora ¿donde puedo encontrar gasolina especial?

[8:04] **+591 69315287:** Campesino ypfb

[8:05] **+591 71894444:** Gracias

[8:08] **+591 72942824:** Buenos dias, una preguntita a cuanto esta el cambio del dolar

[8:14] **+591 69315287:** 11 creo

[8:18] **+591 74670785:** Que gasolina hay en el campesino la especial o la plus

[8:30] **+591 69315287:** Especial

[8:34] **+591 71894444:** Están con la especial y sin fila
Acabo de salir

[9:08] **+591 74541392:** _Se eliminó este mensaje_

[11:28] **+591 72989789:** Tacuarandi llegó gasolina especial 
Me confirmaron

[11:31] **+591 64695398:** Saben si hay gasolina en las Vegas?

[11:39] **+591 64695398:** ??

[12:56] **+591 60251309:** Buenas tardes, alguien sabe dónde hay gasolina especial?

[13:05] **+591 65838310:** _Esperando el mensaje… Esto puede demorar un poco._

[13:17] **+591 76174998:** Buenas tardes saben si en el ypf del campesino hay especial ?

[14:02] **+591 74558462:** Agrupa especial. Por si a alguien lo interesa

[14:36] **+591 69307503:**
> _+591 76174998: Buenas tardes saben si en el ypf del campesino hay especial ?_
Si hay especial

[14:38] **+591 72989789:** Cargando en este momento en tacuarandi gasolina especial muy poca fila

[14:39] **+591 72989789:** [Imagen]

[14:39] **+591 72989789:** [Imagen]

[14:39] **+591 72989789:** Toy en la vagoneta roja

[15:19] **+591 73456683:** [Imagen] Buenas tardes, se está vendiendo flores con chocolates para el 21 de septiembre

[19:41] **+591 71894444:** [Imagen] Buenas noches
Alguien conoce número de algún refugio o sonosis qué pueda atender a un perrito en la cancha de moto mendez qué lo pisaron y su patita está lastimada y creo q esta rota, si tubiera un número por favor se les agradece.

---

## 17 de septiembre de 2026

[0:22] **+591 73483881:**
> _+591 71894444: Imagen: Buenas noches
Alguien conoce número de algún refugio o sonosis qué pueda atender a un perrito en la cancha de moto mendez qué lo pisaron y su patita está lastimada y creo q esta rota, si tubiera un número por favor se les agradece._
+591 79294602

[6:20] **+591 75132668:** _Se eliminó este mensaje_

[8:34] **+591 68694846:** Buenos días saben don de hay gasolina clarita??

[8:42] **+591 72945905:** Surtidor don Daniel

[8:51] **+591 75186906:** Gracias

[9:45] **+591 78225036:** Tacuarandi abra especial hasta el sábado

[9:47] **+591 71752809:** Buenas alguien sabe si Ai gasolina en las vegas
